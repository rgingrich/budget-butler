package com.ryanwgingrich.budgetButler.parser;


import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.ryanwgingrich.budgetButler.parser.SchwabParser;
import com.ryanwgingrich.budgetButler.dto.csv.AmexTransaction;
import com.ryanwgingrich.budgetButler.dto.csv.SchwabTransaction;

public class AmexParserTest {

	private Logger logger = LogManager.getLogger(AmexParserTest.class.getName());

	private SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	private Session session;

	private AmexParser amexParser = new AmexParser();
	private String testFile;

	private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

	@Before
	public void setUp() throws Exception {

		session = sessionFactory.openSession();
		testFile = "/home/rgingrich/BudgetButler Transactions/test/Transactions.csv";
		
	}

	@After
	public void tearDown() throws Exception {

		session.close();
	}

	@Test
	public void testGetTransactionList() throws FileNotFoundException, ParseException {

		List<AmexTransaction> transactionList = (List<AmexTransaction>) amexParser.getTransactionList(testFile);

		Assert.assertEquals(10, transactionList.size());

		Calendar maxDate = Calendar.getInstance();
		maxDate.set(Calendar.YEAR, 1900);

		Calendar transactionDate;

		for (AmexTransaction amexTransaction : transactionList) {

			if (maxDate.getTime().before(sdf.parse(amexTransaction.getDate()))) {
				maxDate.setTime(sdf.parse(amexTransaction.getDate()));
			}
		}
		Assert.assertEquals(sdf.parse("01/08/2018"), maxDate.getTime());
	}

	@Test
	public void testParseToDB() throws FileNotFoundException, ParseException {

		amexParser.parseToDB(testFile, session);

		Long rowCount = 0L;

		String ROW_COUNT_QUERY = "select count(1) FROM BBTransaction";
		Query<Long> rowCountQuery = session.createQuery(ROW_COUNT_QUERY);

		rowCount = rowCountQuery.getSingleResult();
		Assert.assertEquals(10L, rowCount.intValue());

		Calendar maxDate = Calendar.getInstance();
		
		String MAX_DATE_QUERY = "select max(date) FROM BBTransaction";
		Query<Date> maxDateQuery = session.createQuery(MAX_DATE_QUERY);

		maxDate.setTime(maxDateQuery.getSingleResult());

		Assert.assertEquals(sdf.parse("01/08/2018"), maxDate.getTime());

	}

}
