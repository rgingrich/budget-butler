package com.ryanwgingrich.budgetButler.processor;

import org.junit.Assert;

import static org.junit.Assert.fail;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ryanwgingrich.budgetButler.dto.db.BBTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.db.TransactionDescriptor;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.parser.SchwabParser;

public class IncomeProcessorTest {

	private String newLine = System.getProperty("line.separator");// This will retrieve line separator dependent

	private IncomeProcessor processor = new IncomeProcessor();

	private Logger logger = LogManager.getLogger(ProcessorFactoryTest.class.getName());
	private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

	private SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	private Session session;
	private String testFile;

	private BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

	private SchwabParser parser;

	@Before
	public void setUp() throws Exception {
		session = sessionFactory.openSession();

	}

	@After
	public void tearDown() throws Exception {
		session.close();

	}

	@Test
	public void testGetMonthTtl() throws IOException {

		BudgetBucket incomeBucket = new BudgetBucket(BucketCategory.INCOME, BigDecimal.valueOf(0));
		Calendar date = Calendar.getInstance();

		Assert.assertTrue(
				BigDecimal.valueOf(0).compareTo(processor.getMonthTtl(session, incomeBucket.getCategory(), date)) < 0);

	}

	@Test
	public void testGetYearTtl() {
		BudgetBucket incomeBucket = new BudgetBucket(BucketCategory.INCOME, BigDecimal.valueOf(0));
		Calendar date = Calendar.getInstance();

		Assert.assertTrue(
				BigDecimal.valueOf(0).compareTo(processor.getYearTtl(session, incomeBucket.getCategory(), date)) < 0);

	}

	@Test
	public void testUpdateBucket() {
		BudgetBucket incomeBucket = new BudgetBucket(BucketCategory.INCOME, BigDecimal.valueOf(10000));
		Calendar date = Calendar.getInstance();

		processor.updateBucket(session, incomeBucket, date);

		Assert.assertTrue(incomeBucket.getRemainingAmt().compareTo(incomeBucket.getAppropAmt()) < 0);

	}

	private static List<BBTransaction> getTransactions(Session session) {

		Query<BBTransaction> allTransactionsQuery = session
				.createQuery("FROM BBTransaction WHERE CATEGORY IS NULL order by date desc");

		List<BBTransaction> transactionList = (List<BBTransaction>) allTransactionsQuery.getResultList();
		return transactionList;

	}

	private static List<TransactionDescriptor> getTransactionDescriptions(Session session) {

		Query<TransactionDescriptor> transactionDescriptionsQuery = session.createQuery(
				"FROM TransactionDescriptor WHERE SUBSTR(transactionDescription, 1, 10) IN (SELECT SUBSTR(transactionDescription, 1, 10) FROM TransactionDescriptor GROUP BY SUBSTR(transactionDescription, 1, 10))");

		List<TransactionDescriptor> transactionDescriptionList = (List<TransactionDescriptor>) transactionDescriptionsQuery
				.getResultList();
		return transactionDescriptionList;

	}

	private static boolean doestransactionDescriptionExist(Session session, BBTransaction transaction) {

		transaction.getDescription().replaceAll("\'", "\\\\\"");
		String queryDesc = transaction.getDescription().replaceAll("\'", "\\\''");
		Query<Long> query = session
				.createQuery("select count(*) FROM TransactionDescriptor where transactionDescription = '" + queryDesc
						+ transaction.getType() + "'");

		long result = (long) query.getSingleResult();

		if (result > 0)
			return true;
		else
			return false;

	}

}
