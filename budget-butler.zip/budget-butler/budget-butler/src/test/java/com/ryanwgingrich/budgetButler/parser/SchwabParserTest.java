package com.ryanwgingrich.budgetButler.parser;


import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.ryanwgingrich.budgetButler.parser.SchwabParser;
import com.ryanwgingrich.budgetButler.dto.csv.SchwabTransaction;

public class SchwabParserTest {

	private Logger logger = LogManager.getLogger(SchwabParserTest.class.getName());

	private SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	private Session session;

	private SchwabParser schwabParser = new SchwabParser();
	private String testFile;

	private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

	@Before
	public void setUp() throws Exception {

		session = sessionFactory.openSession();
		testFile = "/home/rgingrich/BudgetButler Transactions/test/schwab_checking_test.CSV";
		
	}

	@After
	public void tearDown() throws Exception {

		session.close();
	}

	@Test
	public void testGetTransactionList() throws FileNotFoundException, ParseException {

		List<SchwabTransaction> transactionList = (List<SchwabTransaction>) schwabParser.getTransactionList(testFile);

		Assert.assertEquals(10, transactionList.size());

		Calendar maxDate = Calendar.getInstance();
		maxDate.set(Calendar.YEAR, 1900);

		Calendar transactionDate;

		for (SchwabTransaction schwabTransaction : transactionList) {

			if (maxDate.getTime().before(sdf.parse(schwabTransaction.getDate()))) {
				maxDate.setTime(sdf.parse(schwabTransaction.getDate()));
			}
		}
		Assert.assertEquals(sdf.parse("12/29/2017"), maxDate.getTime());
	}

	@Test
	public void testParseToDB() throws FileNotFoundException, ParseException {

		schwabParser.parseToDB(testFile, session);

		Long rowCount = 0L;

		String ROW_COUNT_QUERY = "select count(1) FROM BBTransaction";
		Query<Long> rowCountQuery = session.createQuery(ROW_COUNT_QUERY);

		rowCount = rowCountQuery.getSingleResult();
		Assert.assertEquals(10L, rowCount.intValue());

		Calendar maxDate = Calendar.getInstance();
		
		String MAX_DATE_QUERY = "select max(date) FROM BBTransaction";
		Query<Date> maxDateQuery = session.createQuery(MAX_DATE_QUERY);

		maxDate.setTime(maxDateQuery.getSingleResult());

		Assert.assertEquals(sdf.parse("12/29/2017"), maxDate.getTime());

	}

}
