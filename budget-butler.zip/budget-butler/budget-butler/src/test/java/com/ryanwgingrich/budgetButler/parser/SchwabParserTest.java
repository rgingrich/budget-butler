package com.ryanwgingrich.budgetButler.parser;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.ryanwgingrich.budgetButler.parser.SchwabParser;
import com.ryanwgingrich.budgetButler.dto.csv.SchwabTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BBTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;

public class SchwabParserTest {

	private Logger logger = LogManager.getLogger(SchwabParserTest.class.getName());

	private SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	private Session session;

	private SchwabParser schwabParser = new SchwabParser();

	@Before
	public void setUp() throws Exception {

		session = sessionFactory.openSession();

		BudgetBucket rentBucket = new BudgetBucket(BucketCategory.RENT, BigDecimal.valueOf(995));
		BudgetBucket foodBucket = new BudgetBucket(BucketCategory.FOOD, BigDecimal.valueOf(400));

		session.beginTransaction();
		session.save(rentBucket);
		session.save(foodBucket);
		session.getTransaction().commit();

		// );

	}

	@After
	public void tearDown() throws Exception {

		session.close();
	}

	@Test
	public void testGetTransactionList() throws FileNotFoundException, ParseException {
		// fail("Not yet implemented");
		List<SchwabTransaction> transactionList = (List<SchwabTransaction>) schwabParser
				.getTransactionList("/home/rgingrich/BudgetButler Transactions/test/schwab_checking_test.CSV");

		// assertEquals(expected, actual,
		// delta);System.out.println(transactionList.size());

		Assert.assertEquals("Incorrect Number Of Records", 10, transactionList.size());

		// Assert.assertEquals(transactionList.get(0).get, transactionList);
		Calendar maxDate = Calendar.getInstance();
		maxDate.set(Calendar.YEAR, 1900);

		Calendar transactionDate;// = Calendar.getInstance();
		// Date transactionDate = new Date();
		// Date maxDate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

		for (SchwabTransaction schwabTransaction : transactionList) {
			
			
			
			if (maxDate.getTime().before(sdf.parse(schwabTransaction.getDate()))) {
				maxDate.setTime(sdf.parse(schwabTransaction.getDate()));
			}
		}
		Assert.assertEquals(sdf.parse("12/29/2017"), maxDate.getTime());
	}

}
