package com.ryanwgingrich.budgetButler.parser;


import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.ryanwgingrich.budgetButler.parser.SchwabParser;
import com.ryanwgingrich.budgetButler.dto.csv.AmexTransaction;
import com.ryanwgingrich.budgetButler.dto.csv.SchwabTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BBTransaction;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

public class SchwabParserTest {

	private Logger logger = LogManager.getLogger(SchwabParserTest.class.getName());
	private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

	private SessionFactory sessionFactory;
	private Session session;
	
	private SchwabParser schwabParser = new SchwabParser();
	private String testFile;

	
	@Before
	public void setUp() throws Exception {
		sessionFactory = new Configuration().configure().buildSessionFactory();
		session = sessionFactory.openSession();
		testFile = "/home/rgingrich/BudgetButler Transactions/test/schwab_checking_test.CSV";
		
	}

	@After
	public void tearDown() throws Exception {

		session.close();
	}

	@Test
	public void testGetTransactionList() throws FileNotFoundException, ParseException {

		List<SchwabTransaction> transactionList = null;
		try {
			transactionList = (List<SchwabTransaction>) schwabParser.getRecordList(testFile);
		} catch (FileNotFoundException e) {

			logger.error(e.getMessage());
		}

		Assert.assertEquals(SchwabTransaction.class, transactionList.get(0).getClass());
	}


	@Test
	public void testParseToDB() throws FileNotFoundException, ParseException {

		try {
			schwabParser.parseToDB(testFile, session);
		} catch (FileNotFoundException e) {

			logger.error(e.getMessage());
		}

		BBTransaction transaction = (BBTransaction) session.get(BBTransaction.class, 1);
		Assert.assertEquals(BBTransaction.class, transaction.getClass());
		Assert.assertNotEquals(TransactionType.AMEX, transaction.getType());

	}

}
