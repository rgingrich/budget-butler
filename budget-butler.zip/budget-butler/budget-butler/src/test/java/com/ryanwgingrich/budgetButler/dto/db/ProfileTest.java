package com.ryanwgingrich.budgetButler.dto.db;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import org.junit.Assert;

public class ProfileTest {

	SessionFactory sessionFactory;
	Session session;
	String testNameString = "Ryan";
	String testNameString2 = "Kelly";
	// String testCsvString = "Transactions";

	@Before
	public void setUp() throws Exception {
		sessionFactory = new Configuration().configure().buildSessionFactory();
		session = (Session) sessionFactory.openSession();

		Profile profile = new Profile(testNameString);

		session.beginTransaction();
		session.save(profile);
		session.getTransaction().commit();
	}

	@After
	public void tearDown() throws Exception {

		session.close();
	}

	@Test
	public void testGetName() {

		boolean isRecordFound = false;
		int id = 0;

		Profile profile = null;
		while (!isRecordFound) {

			profile = session.get(Profile.class, id);
			if (profile == null) {
				id++;
			} else {
				isRecordFound = true;
				profile = null;

			}

		}
		Assert.assertEquals(testNameString, session.get(Profile.class, id).getName());

	}

	@Test
	public void testSetName() {

		boolean isRecordFound = false;
		int id = 0;

		Profile profile = null;
		while (!isRecordFound) {

			profile = session.get(Profile.class, id);
			if (profile == null) {
				id++;
			} else {
				isRecordFound = true;
				// profile = null;

				session.beginTransaction();
				profile.setName(testNameString2);
				session.getTransaction().commit();

			}

		}
		Assert.assertEquals(testNameString2, session.get(Profile.class, id).getName());

	}

	@Test
	public void testGetId() {
		Profile profile = null;

		boolean isRecordFound = false;
		int id = 0;
		while (!isRecordFound) {

			profile = session.get(Profile.class, id);
			if (profile == null) {
				id++;
			} else {
				isRecordFound = true;
				profile = null;

			}
		}
		Assert.assertEquals(id, session.get(Profile.class, id).getId());

	}

	@Test
	public void testSetId() {
		Profile profile = null;

		boolean isRecordFound = false;
		int id = 0;
		int changeIdValue = 10;
		while (!isRecordFound) {

			profile = session.get(Profile.class, id);
			if (profile == null) {
				id++;
			} else {
				isRecordFound = true;
				profile.setId(id + changeIdValue);

			}
		}
		Assert.assertEquals(id + changeIdValue, profile.getId());

	}

}
