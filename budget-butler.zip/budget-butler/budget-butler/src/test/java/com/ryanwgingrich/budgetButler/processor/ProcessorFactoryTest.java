package com.ryanwgingrich.budgetButler.processor;

import java.math.BigDecimal;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

//import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.parser.SchwabParser;

public class ProcessorFactoryTest {
	
	private SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	private Session session;
	
	private String testFile;

	@Before
	public void setUp() throws Exception {
		
		session = sessionFactory.openSession();
		testFile = "/home/rgingrich/BudgetButler Transactions/test/schwab_checking_test.CSV";
		
		
		
	}

	@After
	public void tearDown() throws Exception {
		session.close();
	}

	@Test
	public void test() {
		
		BudgetBucket rentBucket = new BudgetBucket(BucketCategory.RENT, BigDecimal.valueOf(995));
		BudgetBucket foodBucket = new BudgetBucket(BucketCategory.FOOD, BigDecimal.valueOf(400));
		
		Processor myProcessor = new ProcessorFactory().getProcessor(rentBucket);
		Assert.assertEquals(RentProcessor.class, myProcessor.getClass());
		
		myProcessor = new ProcessorFactory().getProcessor(foodBucket);
		Assert.assertEquals(FoodProcessor.class, myProcessor.getClass());


		
	}

}
