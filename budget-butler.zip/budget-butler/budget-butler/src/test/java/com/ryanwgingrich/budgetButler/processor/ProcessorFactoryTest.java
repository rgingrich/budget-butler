package com.ryanwgingrich.budgetButler.processor;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

//import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;

public class ProcessorFactoryTest {

	private Logger logger = LogManager.getLogger(ProcessorFactoryTest.class.getName());
	private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

	private SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	private Session session;

	// private String testFile;

	@Before
	public void setUp() throws Exception {

		session = sessionFactory.openSession();
		// testFile = "/home/rgingrich/BudgetButler
		// Transactions/test/schwab_checking_test.CSV";
	}

	@After
	public void tearDown() throws Exception {
		session.close();
	}

	@Test
	public void tesGetProcessort() {

		BudgetBucket incomeBucket = new BudgetBucket(BucketCategory.INCOME, BigDecimal.valueOf(0));

		Processor myProcessor = new ProcessorFactory().getProcessor(incomeBucket);
		Assert.assertEquals(IncomeProcessor.class, myProcessor.getClass());

	}

}
