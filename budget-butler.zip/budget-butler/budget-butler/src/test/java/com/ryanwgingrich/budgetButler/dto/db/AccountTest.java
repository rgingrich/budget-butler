package com.ryanwgingrich.budgetButler.dto.db;

//import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import org.junit.Assert;

public class AccountTest {

	SessionFactory sessionFactory;
	Session session;
	String testNameString = "Ryan";
	String testNameString2 = "Kelly";
	String testCsvString = "Transactions";
	String testAcctName = "AccountTestName";
	String testAcctName2 = "AccountTestName2";

	@Before
	public void setUp() throws Exception {
		sessionFactory = new Configuration().configure().buildSessionFactory();
		session = (Session) sessionFactory.openSession();

		Profile profile = new Profile(testNameString);

		Account testAcct = new Account(testAcctName, testCsvString);

		session.beginTransaction();
		session.save(profile);
		session.save(testAcct);
		session.getTransaction().commit();
	}

	@After
	public void tearDown() throws Exception {

		session.close();
	}

	@Test
	public void testGetId() throws Exception {

		Account account = null;

		boolean isRecordFound = false;
		int id = 0;
		while (!isRecordFound) {

			account = session.get(Account.class, id);
			if (account == null) {
				id++;
			} else {
				isRecordFound = true;
				account = null;

			}
		}
		Assert.assertEquals(id, session.get(Account.class, id).getId());

	}

	@Test
	public void testSetId() throws Exception {

		Account account = null;

		boolean isRecordFound = false;
		int id = 0;
		int changeIdValue = 10;
		while (!isRecordFound) {

			account = session.get(Account.class, id);

			if (account == null) {
				id++;
			} else {
				isRecordFound = true;

				account.setId(id + changeIdValue);

			}

		}
		Assert.assertEquals(id + changeIdValue, account.getId());

	}

	@Test
	public void testGetAcctName() throws Exception {

		Account account = null;

		boolean isRecordFound = false;
		int id = 0;
		while (!isRecordFound) {

			account = session.get(Account.class, id);
			if (account == null) {
				id++;
			} else {
				isRecordFound = true;
				account = null;
			}

		}
		Assert.assertEquals(testAcctName, session.get(Account.class, id).getAcctName());

	}

	@Test
	public void testGetCsvFile() throws Exception {

		Account account = null;

		boolean isRecordFound = false;
		int id = 0;
		while (!isRecordFound) {

			account = session.get(Account.class, id);
			if (account == null) {
				id++;
			} else {
				isRecordFound = true;
				account = null;

			}

		}
		Assert.assertEquals(testCsvString, session.get(Account.class, id).getCsvFile());

	}

	@Test
	public void testSetAcctName() throws Exception {

		Account account = null;

		boolean isRecordFound = false;
		int id = 0;
		while (!isRecordFound) {

			account = session.get(Account.class, id);

			if (account == null) {
				id++;
			} else {
				isRecordFound = true;


			}
			

		}
		

		//List<Profile> acctOwnerList = (List<Profile>) account.getAcctOwnerList();

		//Profile profile = new Profile(testNameString2);
		//acctOwnerList.add(profile);
		
		//profile.

		session.beginTransaction();
		
		account.setAcctName(testAcctName2);
		session.save(account);
		session.getTransaction().commit();

		//account = session.get(Account.class, id);
		
		
		Assert.assertEquals(testAcctName2, session.get(Account.class, id).getAcctName());

	}

	@Test
	public void testSetCsvFile() throws Exception {

		Account account = null;
		boolean isRecordFound = false;
		int id = 0;

		while (!isRecordFound) {

			account = session.get(Account.class, id);

			if (account == null) {
				id++;
			} else {
				isRecordFound = true;

				testCsvString = "TESTtestTESTtestTEST";

				session.beginTransaction();
				account.setCsvFile(testCsvString);
				session.getTransaction().commit();

			}

		}
		Assert.assertEquals(testCsvString, session.get(Account.class, id).getCsvFile());

	}
}
