package com.ryanwgingrich.budgetButler.parser;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.ryanwgingrich.budgetButler.dto.db.TransactionDescriptor;
import com.ryanwgingrich.budgetButler.enums.AccountType;

public class ParseFactoryTest {

	private Logger logger = LogManager.getLogger(SchwabParserTest.class.getName());

	private ParseFactory parseFactory;

	@Before
	public void setUp() throws Exception {

	}

	@After
	public void tearDown() throws Exception {

	}

	@Test
	public void testGetParser() {

		Parser myParser = new ParseFactory().getFileParser(AccountType.SCHWAB_BANK);
		Assert.assertEquals(SchwabCsvFileParser.class, myParser.getClass());

		myParser = new ParseFactory().getFileParser(AccountType.CHASE_CREDIT);
		Assert.assertEquals(ChaseParser.class, myParser.getClass());

		myParser = new ParseFactory().getFileParser(AccountType.AMEX_CREDIT);
		Assert.assertEquals(AmexParser.class, myParser.getClass());
		
		myParser = new ParseFactory().getFileParser(AccountType.DESCRIPTOR);
		Assert.assertEquals(TransactionDescriptor.class, myParser.getClass());

	}
}
