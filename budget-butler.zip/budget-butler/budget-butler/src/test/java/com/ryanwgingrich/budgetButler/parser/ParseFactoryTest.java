package com.ryanwgingrich.budgetButler.parser;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.ryanwgingrich.budgetButler.dto.db.TransactionDescriptor;
import com.ryanwgingrich.budgetButler.enums.ParserType;

public class ParseFactoryTest {

	private Logger logger = LogManager.getLogger(SchwabParserTest.class.getName());

	private ParseFactory parseFactory;

	@Before
	public void setUp() throws Exception {

	}

	@After
	public void tearDown() throws Exception {

	}

	@Test
	public void testGetParser() {

		Parser myParser = new ParseFactory().getParser(ParserType.SCHWAB_BANK);
		Assert.assertEquals(SchwabParser.class, myParser.getClass());

		myParser = new ParseFactory().getParser(ParserType.CHASE_BANK);
		Assert.assertEquals(ChaseParser.class, myParser.getClass());

		myParser = new ParseFactory().getParser(ParserType.AMEX_CREDIT);
		Assert.assertEquals(AmexParser.class, myParser.getClass());
		
		myParser = new ParseFactory().getParser(ParserType.DESCRIPTOR);
		Assert.assertEquals(TransactionDescriptor.class, myParser.getClass());

	}
}
