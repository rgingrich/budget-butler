package com.ryanwgingrich.budgetButler.parser;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.FinancialInstitutionCode;

//import junit.framework.Assert;

public class ParseFactoryTest {

	private Logger logger = LogManager.getLogger(SchwabParserTest.class.getName());

	private SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	private Session session;

	private ParseFactory parseFactory = new ParseFactory();

	@Before
	public void setUp() throws Exception {

		session = sessionFactory.openSession();

	}

	@After
	public void tearDown() throws Exception {
		session.close();
	}

	@Test
	public void testGetParser() {

		Parser myParser = new ParseFactory().getParser(FinancialInstitutionCode.SCHWAB_BANK);
		Assert.assertEquals(SchwabParser.class, myParser.getClass());

		myParser = new ParseFactory().getParser(FinancialInstitutionCode.CHASE_BANK);
		Assert.assertEquals(ChaseParser.class, myParser.getClass());

		myParser = new ParseFactory().getParser(FinancialInstitutionCode.AMEX_CREDIT);
		Assert.assertEquals(AmexParser.class, myParser.getClass());

	}
}
