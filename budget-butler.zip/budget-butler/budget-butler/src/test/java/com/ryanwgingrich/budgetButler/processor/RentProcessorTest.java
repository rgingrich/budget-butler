package com.ryanwgingrich.budgetButler.processor;


import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.ryanwgingrich.budgetButler.parser.SchwabParser;
import com.ryanwgingrich.budgetButler.dto.csv.SchwabTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BBTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

public class RentProcessorTest {

	private Logger logger = LogManager.getLogger(RentProcessorTest.class.getName());
	private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	private String newLine = System.getProperty("line.separator");// This will retrieve line separator dependent

	

	private SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	private Session session;

	private SchwabParser mySchwabParser = new SchwabParser();
	private RentProcessor myRentProcessor = new RentProcessor();
	private String testFile;

	//private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

	@Before
	public void setUp() throws Exception {

		session = sessionFactory.openSession();
		testFile = "/home/rgingrich/BudgetButler Transactions/test/schwab_checking_test.CSV";
		
	}

	@After
	public void tearDown() throws Exception {

		session.close();
	}

	@Test
	public void processTransactions() throws FileNotFoundException {

		BudgetBucket rentBucket = new BudgetBucket(BucketCategory.RENT, BigDecimal.valueOf(995));
		session.beginTransaction();
		session.save(rentBucket);
		session.getTransaction().commit();
		
		mySchwabParser.parseToDB(testFile, session);
		
		myRentProcessor.processTransactions(rentBucket, session);
		
		Assert.assertEquals(new BigDecimal("995"), rentBucket.getRemainingAmt());
		
		
		
		
		
		String RENT_QUERY = "FROM BudgetBucket where category = " + BucketCategory.RENT.ordinal();
		
		Query<BudgetBucket> rentBucketQuery = session.createQuery(RENT_QUERY);

		BudgetBucket DBrentBucket = rentBucketQuery.getSingleResult();
		
		
		
		
		System.out.println(
				"**********************************************************************************" + newLine);
		//for (SchwabTransaction rentTransaction : (List<SchwabTransaction>)mySchwabParser.getTransactionList(testFile)) {
//
			String billPaidMsg = null;// " " + rentBucket.getCategory() + " BILL DUE ";
	        if(DBrentBucket.isBillPaid()) {
	        	
	        	billPaidMsg = DBrentBucket.getCategory()+" Bill Paid";//sdf.format(rentTransaction.getDate()) + " " + rentTransaction.getDescription() + " " + "$"
	        }
	        else {

	        	billPaidMsg = DBrentBucket.getCategory()+" Bill Due: $"+DBrentBucket.getRemainingAmt();//sdf.format(rentTransaction.getDate()) + " " + rentTransaction.getDescription() + " " + "$"
	        }
	        	
//					+ rentTransaction.getWithdrawal();
			System.out.println(billPaidMsg);

	//	}
	//	System.out.println(newLine + DBrentBucket.getCategory() + " Amt Due: $" + DBrentBucket.getRemainingAmt());
		System.out.println(newLine
				+ "**********************************************************************************" + newLine);
		
		
		
		
		
		
		
	}

	
}
