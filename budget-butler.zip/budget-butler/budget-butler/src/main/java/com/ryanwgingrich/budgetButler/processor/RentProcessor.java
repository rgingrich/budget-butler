package com.ryanwgingrich.budgetButler.processor;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.ryanwgingrich.budgetButler.dto.db.BBTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

public class RentProcessor implements Processor {

	@Override
	public void processTransactions(BudgetBucket rentBucket, Session session) {

		
		session.beginTransaction();
		
		Calendar cal = Calendar.getInstance();
		Calendar maxDate = Calendar.getInstance();

		List<BBTransaction> rentTransactions = null;

		String MAX_DATE_QUERY = "select max(date) FROM BBTransaction";
		Query<Date> currentDateQuery = session.createQuery(MAX_DATE_QUERY);

		maxDate.setTime(currentDateQuery.getSingleResult());

		Integer month = maxDate.get(Calendar.MONTH);
		Integer transferMonth = month;
		if (transferMonth == 0) {
			transferMonth = 12;
		}

		Integer year = maxDate.get(Calendar.YEAR);
		Integer transferYear = year;
		if (maxDate.get(Calendar.MONTH) == 0) {
			transferYear = transferYear - 1;
		}
		// process rent bucket//////////////////////////////////////////////////////////

		String RENT_QUERY = "FROM BBTransaction bbT where " + "(" + "  (" + "    YEAR(date) = " + transferYear
				+ "    AND MONTH(date) = " + transferMonth + "    AND TYPE = " + TransactionType.TRANSFER.ordinal()
				+ "  )" + "  OR" + "  (" + "    YEAR(date) = " + year + "    AND MONTH(date) = " + (month + 1)
				+ "    AND TYPE = " + TransactionType.CHECK.ordinal() + "  )" + ")" + " AND withdrawal = "
				+ rentBucket.getAppropAmt();// + " and type = " + TransactionType.CHECK.ordinal();

		Query<BBTransaction> rentTransactionQuery = session.createQuery(RENT_QUERY);

		rentTransactions = rentTransactionQuery.list();
		for (BBTransaction rentTransaction : rentTransactions) {

			Calendar cal2 = Calendar.getInstance();
			cal2.setTime(rentTransaction.getDate());

			if (rentTransaction.getType() == TransactionType.CHECK) {
				rentBucket.setRemainingAmt(rentBucket.getAppropAmt().subtract(rentTransaction.getWithdrawal()));
				if (rentBucket.getRemainingAmt()
						.equals(rentBucket.getAppropAmt().subtract(rentTransaction.getWithdrawal()))) {
					rentBucket.setBillPaid(true);
				}
			}

		}

		session.update(rentBucket);
		session.getTransaction().commit();
		//session.close();


		

	}

}
