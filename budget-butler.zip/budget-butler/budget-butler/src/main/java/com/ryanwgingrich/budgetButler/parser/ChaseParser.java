package com.ryanwgingrich.budgetButler.parser;

import java.io.FileNotFoundException;
import java.util.List;

import org.hibernate.Session;

public class ChaseParser implements Parser {

	@Override
	public List<?> getRecordList(String fileName) throws FileNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void parseToDB(String fileName, Session session) throws FileNotFoundException {
		// TODO Auto-generated method stub
		
	}

}
