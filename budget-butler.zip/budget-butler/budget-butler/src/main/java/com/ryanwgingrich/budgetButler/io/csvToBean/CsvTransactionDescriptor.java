package com.ryanwgingrich.budgetButler.io.csvToBean;

import com.opencsv.bean.CsvBindByPosition;

public class CsvTransactionDescriptor {

	@CsvBindByPosition(position = 0, required = true)
	private String descriptor;
	@CsvBindByPosition(position = 1, required = true)
	private String budgetBucket;

	public CsvTransactionDescriptor(String descriptor, String budgetBucket) {

		//this.descriptor = descriptor;
		//this.budgetBucket = budgetBucket;

	}
	
	public CsvTransactionDescriptor() {

		//this.descriptor = descriptor;
		//this.budgetBucket = budgetBucket;

	}

	public String getDescriptor() {
		return descriptor;
	}

	public String getBudgetBucket() {
		return budgetBucket;
	}

	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}

	public void setBudgetBucket(String BudgetBucket) {

		this.budgetBucket = BudgetBucket;
	}

}
