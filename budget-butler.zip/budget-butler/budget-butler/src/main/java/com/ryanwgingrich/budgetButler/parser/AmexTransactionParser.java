package com.ryanwgingrich.budgetButler.parser;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.List;

import com.opencsv.bean.CsvToBeanBuilder;
import com.ryanwgingrich.budgetButler.io.csvToBean.AmexTransaction;

public class AmexTransactionParser extends CsvFileParser {

	@Override
	public List<?> getItems(String fileName, Class itemClass) throws FileNotFoundException {
		FileReader fileReader = new FileReader(fileName);

		CsvToBeanBuilder<?> csvToBeanBuilder = new CsvToBeanBuilder<AmexTransaction>(fileReader)
				.withType(AmexTransaction.class);

		@SuppressWarnings("unchecked")
		List<AmexTransaction> amexTransactions = (List<AmexTransaction>) csvToBeanBuilder.build().parse();

		return amexTransactions;
	}

	

}
