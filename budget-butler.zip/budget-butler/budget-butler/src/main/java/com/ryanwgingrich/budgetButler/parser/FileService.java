package com.ryanwgingrich.budgetButler.parser;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.dto.db.Account;
import com.ryanwgingrich.budgetButler.enums.AccountType;
import com.ryanwgingrich.budgetButler.enums.EnumLookupUtil;
import com.ryanwgingrich.budgetButler.enums.TransactionType;
import com.ryanwgingrich.budgetButler.io.TransactionController;
import com.ryanwgingrich.budgetButler.io.csvToBean.AmexTransaction;
import com.ryanwgingrich.budgetButler.io.csvToBean.ChaseTransaction;
import com.ryanwgingrich.budgetButler.io.csvToBean.SchwabTransaction;
import com.ryanwgingrich.budgetButler.service.DBService;
import com.ryanwgingrich.budgetButler.view.BudgetButler;

public class FileService {

	private static String DATE_FORMAT = "MM/dd/yyyy";
	private static SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);

	private static Logger logger = LogManager.getLogger(BudgetButler.class.getName());

	private String transactionFileDir;

	public FileService() {
	}

	public FileService(String transactionFileDir) {
		this.transactionFileDir = transactionFileDir;

	}

	@SuppressWarnings("unchecked")
	public void parseFile(String fileName) throws IOException {
		TransactionController transactionController = new TransactionController();

		CsvFileParser csvFileParser = new CsvFileParserFactory().getFileParser(fileName);

		if (csvFileParser != null) {

			/*****************************************************************************************
			 * CHASE TRANSACTION FILE
			 *****************************************************************************************/
			if (csvFileParser.getClass().equals(ChaseTransactionParser.class)) {
				logger.info("Detected a CHASE  file: " + fileName);

				List<ChaseTransaction> itemList = (List<ChaseTransaction>) csvFileParser.getItems(fileName,
						ChaseTransaction.class);

				List<Transaction> transactionList = new ArrayList<Transaction>();

				for (ChaseTransaction csvTransaction : itemList) {

					Transaction transaction = new Transaction(csvTransaction.getDate(), csvTransaction.getType(),
							csvTransaction.getDescription(), csvTransaction.getTransactionAmount(),
							AccountType.CHASE_CREDIT);

					transactionController.categorize(transaction);

					transactionList.add(transaction);
					DBService.getInstance().save(transaction);

				}

				DBService.getInstance().save(new Account(AccountType.CHASE_CREDIT, fileName, transactionList));

			}
			/*****************************************************************************************
			 * SCHWAB TRANSACTION FILE
			 *****************************************************************************************/
			else if (csvFileParser.getClass().equals(SchwabTransactionParser.class)) {
				logger.info("Detected a SCHWAB  file: " + fileName);

				List<SchwabTransaction> itemList = (List<SchwabTransaction>) csvFileParser.getItems(fileName,
						SchwabTransaction.class);

				List<Transaction> transactionList = new ArrayList<Transaction>();
				for (SchwabTransaction t : itemList) {

					String transactionAmt = t.getDeposit() == null ? t.getWithdrawal() : t.getDeposit();

					Transaction transaction = new Transaction(t.getDate(), t.getType(), t.getCheckNum(),
							t.getDescription(), t.getRunningBalance(), transactionAmt, AccountType.SCHWAB_CASH);

					transactionController.categorize(transaction);

					transactionList.add(transaction);
					DBService.getInstance().save(transaction);

				}

				DBService.getInstance().save(new Account(AccountType.SCHWAB_CASH, fileName, transactionList));

			}

			/*****************************************************************************************
			 * AMEX TRANSACTION FILE
			 *****************************************************************************************/
			else if (csvFileParser.getClass().equals(AmexTransactionParser.class)) {
				logger.info("Detected a AMEX  file: " + fileName);

				List<AmexTransaction> itemList = (List<AmexTransaction>) csvFileParser.getItems(fileName,
						AmexTransaction.class);

				List<Transaction> transactionList = new ArrayList<Transaction>();
				for (AmexTransaction t : itemList) {

					Transaction transaction = new Transaction(t.getDate(), TransactionType.AMEX, t.getDescription(),
							t.getCardHolder(), t.getTransactionAmount(), AccountType.AMEX_CREDIT);

					transactionController.categorize(transaction);
					transactionList.add(transaction);
					DBService.getInstance().save(transaction);

				}
				Account account = new Account(AccountType.AMEX_CREDIT, fileName, transactionList);
				DBService.getInstance().save(account);

			}
		}

	}

	@SuppressWarnings("unchecked")
	public void parseFileCurrent(String fileName) throws IOException, ParseException {

		CsvFileParser csvFileParser = new CsvFileParserFactory().getFileParser(fileName);

		if (csvFileParser != null) {

			/*****************************************************************************************
			 * CHASE TRANSACTION FILE
			 *****************************************************************************************/
			if (csvFileParser.getClass().equals(ChaseTransactionParser.class)) {
				logger.info("Detected a CHASE  file: " + fileName);

				List<ChaseTransaction> itemList = (List<ChaseTransaction>) csvFileParser.getItems(fileName,
						ChaseTransaction.class);

				List<Transaction> transactionList = new ArrayList<Transaction>();

				for (ChaseTransaction t : itemList) {

					Calendar tDate = Calendar.getInstance();
					tDate.setTime(sdf.parse(t.getDate()));

					int tMonth = tDate.get(Calendar.MONTH);
					int tYear = tDate.get(Calendar.YEAR);

					if (tMonth == Calendar.getInstance().get(Calendar.MONTH)
							&& tYear == Calendar.getInstance().get(Calendar.YEAR)) {
						Transaction transaction = new Transaction(t.getDate(), t.getType(), t.getDescription(),
								t.getTransactionAmount(), AccountType.CHASE_CREDIT);

						transaction.setCategory(TransactionService.categorize(transaction));

						transactionList.add(transaction);
						DBService.save(transaction);

					}

				}

				DBService.save(new Account(AccountType.CHASE_CREDIT, fileName, transactionList));

			}
			/*****************************************************************************************
			 * SCHWAB TRANSACTION FILE
			 *****************************************************************************************/
			else if (csvFileParser.getClass().equals(SchwabTransactionParser.class)) {
				logger.info("Detected a SCHWAB  file: " + fileName);

				List<SchwabTransaction> itemList = (List<SchwabTransaction>) csvFileParser.getItems(fileName,
						SchwabTransaction.class);

				List<Transaction> transactionList = new ArrayList<Transaction>();
				for (SchwabTransaction t : itemList) {

					Calendar tDate = Calendar.getInstance();
					tDate.setTime(sdf.parse(t.getDate()));

					int tMonth = tDate.get(Calendar.MONTH);
					int tYear = tDate.get(Calendar.YEAR);

					if (tMonth == Calendar.getInstance().get(Calendar.MONTH)
							&& tYear == Calendar.getInstance().get(Calendar.YEAR)) {

						String transactionAmt = t.getDeposit() == null ? t.getWithdrawal() : t.getDeposit();

						Transaction transaction = new Transaction(t.getDate(), t.getType(), t.getCheckNum(),
								t.getDescription(), t.getRunningBalance(), transactionAmt, AccountType.SCHWAB_CASH);

						transaction.setCategory(TransactionService.categorize(transaction));

						transactionList.add(transaction);
						DBService.save(transaction);

					}

				}

				DBService.save(new Account(AccountType.SCHWAB_CASH, fileName, transactionList));

			}

			/*****************************************************************************************
			 * AMEX TRANSACTION FILE
			 *****************************************************************************************/
			else if (csvFileParser.getClass().equals(AmexTransactionParser.class)) {

				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				logger.info("Detected a AMEX  file: " + fileName);

				List<AmexTransaction> itemList = (List<AmexTransaction>) csvFileParser.getItems(fileName,
						AmexTransaction.class);

				List<Transaction> transactionList = new ArrayList<Transaction>();
				for (AmexTransaction t : itemList) {

					Calendar tDate = Calendar.getInstance();
					tDate.setTime(sdf.parse(t.getDate()));

					int tMonth = tDate.get(Calendar.MONTH);
					int tYear = tDate.get(Calendar.YEAR);

					if (tMonth == Calendar.getInstance().get(Calendar.MONTH)
							&& tYear == Calendar.getInstance().get(Calendar.YEAR)) {

						Transaction transaction = new Transaction(t.getDate(), "AMEX", t.getDescription(),
								t.getCardHolder(), t.getTransactionAmount(), AccountType.AMEX_CREDIT);

						transaction.setCategory(TransactionService.categorize(transaction));

						transactionList.add(transaction);
						DBService.save(transaction);

					}

				}

				DBService.save(new Account(AccountType.AMEX_CREDIT, fileName, transactionList));
			}
		}

	}

	public void removeFile(String fileName) {
		File[] directoryListing = new File(transactionFileDir).listFiles();

		for (File file : directoryListing) {

			if (file.getName().equals(fileName)) {
				file.delete();

			}
		}
	}

}
