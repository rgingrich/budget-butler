package com.ryanwgingrich.budgetButler.service;

import java.math.BigDecimal;
import java.util.List;

import com.ryanwgingrich.budgetButler.dto.db.Budget;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;

public class BudgetBucketService {

	public BudgetBucketService() {

	}

	

}
