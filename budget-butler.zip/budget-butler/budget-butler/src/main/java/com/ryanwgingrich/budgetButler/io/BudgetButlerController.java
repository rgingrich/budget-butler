package com.ryanwgingrich.budgetButler.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

import com.ryanwgingrich.budgetButler.dto.db.Account;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.parser.CsvFileParser;
import com.ryanwgingrich.budgetButler.parser.CsvFileParserFactory;
import com.ryanwgingrich.budgetButler.service.BucketService;
import com.ryanwgingrich.budgetButler.service.DBService;
import com.ryanwgingrich.budgetButler.service.FileService;
import com.ryanwgingrich.budgetButler.service.ReportService;
import com.ryanwgingrich.budgetButler.service.TransactionService;

public class BudgetButlerController {

	// GOLBAL variables
	private Logger logger = LogManager.getLogger(BudgetButlerController.class.getName());
	private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	private String newLine = System.getProperty("line.separator");// This will retrieve line separator dependent

	private BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	// private final String DFLT_TRANSACTION_FILE_DIR =
	// "/home/rgingrich/BudgetButler";
	private String transactionFileDir = "/home/ryan/BudgetButler";

	private int menuIntSelection;
	private String menuStringSelection;

	public BudgetButlerController() {

	}

	public void startUp() throws NumberFormatException, IOException, ParseException {

		System.out.println(
				"****************************************************************************************************"
						+ newLine);
		System.out.println(
				"*****************************************    MAIN MENU    ******************************************"
						+ newLine);
		System.out.println("1: Budget Butler");
		System.out.println("2: Setup" + newLine);
		System.out.println(
				"****************************************************************************************************");

		menuIntSelection = getIntConsoleInput();

		switch (menuIntSelection) {
		case 1:
			bbMainMenu();
			break;
		case 2:
			setup();
			break;
		default:
			System.out.println("***INVALID***");
			startUp();
			break;
		}

	}

	private void setup() throws NumberFormatException, IOException, ParseException {
		System.out.println(
				"*******************************************    SETUP    ********************************************"
						+ newLine);
		System.out.println("1: Set Transaction File Directory");
		System.out.println("2: Main Menu" + newLine);
		System.out.println(
				"****************************************************************************************************");

		menuIntSelection = getIntConsoleInput();

		switch (menuIntSelection) {
		case 1:
			bbSetupTransactionFileDir();
			break;
		case 2:
			startUp();
			break;
		default:
			System.out.println("***INVALID***");
			setup();
			break;
		}

	}

	private void bbSetupTransactionFileDir() throws NumberFormatException, IOException, ParseException {

		System.out.println(
				"*****************************    SETUP TRANSACTION FILE(S) DIRECTORY    *****************************"
						+ newLine);

		File[] directoryListing = new File(transactionFileDir).listFiles();
		// boolean fileFound = false;
		if (directoryListing != null && directoryListing.length > 0) {
			// fileFound = true;

			System.out.println("Are these your transaction .csv files? (Y/N): ");
			for (File f : directoryListing) {
				System.out.println(f.getPath());
			}

		} else {
			System.out.println(
					"Is this where I can expect to find your transaction file(s)? (Y/N): " + transactionFileDir);
		}

		menuStringSelection = getStringConsoleInput();

		switch (menuStringSelection.toUpperCase()) {

		case "Y":
			// transactionFileDir = transactionFileDir;
			if (transactionFileDir == "undefined") {
				System.out.println("***INVALID***");
				bbSetupTransactionFileDir();
			} else {
				System.out.println(
						"Please be sure all relevant transaction files are available in " + transactionFileDir);
				startUp();
				break;
			}
		case "N":
			System.out.println("Please enter the full path where you have stashed your transaction file(s): ");
			transactionFileDir = this.getStringConsoleInput();

			System.out.println("Please be sure all relevant transaction files are available in " + transactionFileDir);

			startUp();
			break;

		default:
			System.out.println("***INVALID***");
			bbSetupTransactionFileDir();
			break;
		}

		// transactionFileDirectory = getTransactionDir(transactionFileDirectory);

		// return fileDirectory;

		// *****************************************************************************************/

		// if (directoryListing.length > 0) {

	}

	public void bbInitialLoadReset() throws NumberFormatException, IOException, ParseException {

		DBService.getInstance().clearData();

		// Initialize buckets from ENUM
		BucketService bucketS = new BucketService();
		bucketS.initialize();

		FileService fileS = new FileService(transactionFileDir);
		fileS.removeFile("TransactionDescriptor.csv");

		Calendar budgetDate = Calendar.getInstance();
		// budgetDate.set(Calendar.MONTH, getBudgetMonth());

		// SET "0" as pass value for initial load
		fileS.processFiles(0);

		bucketS.processBuckets(budgetDate.get(Calendar.MONTH), budgetDate.get(Calendar.MONTH));

	}

	public int getBudgetMonth() throws NumberFormatException, IOException {
		System.out.println("Please Enter Month [0-11]: ");
		int month = Integer.valueOf(br.readLine());
		return month;
	}

	public int bbMainMenu() throws NumberFormatException, IOException, ParseException {

		System.out.println(
				"******************************************    MAIN MENU    *****************************************"
						+ newLine);
		System.out.println("1: Initial Load / Reset All Data");
		System.out.println("2: Report Menu");
		System.out.println("9: Exit" + newLine);
		System.out.println(
				"****************************************************************************************************");

		menuIntSelection = getIntConsoleInput();

		// if (compareChar(curChar, toChar("0"))) getButtons().get(i).setText("§");

		if (Integer.compare(menuIntSelection, 0) > 0)
			return menuIntSelection;
		return 0;

	}

	private int getIntConsoleInput() {

		int input = 0;
		System.out.println("MAKE SELECTION [0-9]: ");

		try {
			input = Integer.valueOf(br.readLine());
		} catch (NumberFormatException e) {
			System.out.println("***INVALID***");
			input = getIntConsoleInput();
			// e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return input;
	}

	private String getStringConsoleInput() {

		String input = null;
		// System.out.println("MAKE SELECTION [0-9]: ");

		try {
			input = br.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return input;
	}

	private char getCharConsoleInput() {
		char input = ' ';
		System.out.println("ENTER CHARACTER: ");

		try {
			input = br.readLine().charAt(0);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return input;
	}

	public int bbReportMenu() {
		System.out.println(
				"******************************************    REPORT MENU    *****************************************"
						+ newLine);
		System.out.println("1: Current Transactions");
		System.out.println("2: Budget Buckets");
		System.out.println("9: Exit" + newLine);
		System.out.println(
				"****************************************************************************************************");

		menuIntSelection = getIntConsoleInput();

		if (Integer.compare(menuIntSelection, 0) > 0)
			return menuIntSelection;
		return 0;

	}

	public void bbTransactionReport() {

		// ReportService reportService = new ReportService();

		System.out.println(
				"**************************************    TRANSACTION REPORT    *************************************"
						+ newLine);

		System.out.println(
				"****************************************************************************************************");

		for (Transaction t : ReportService.transactionReport(Calendar.getInstance().get(Calendar.MONTH) + 1,
				Calendar.getInstance().get(Calendar.YEAR))) {
			System.out.println(sdf.format(t.getDate().getTime()) + " " + t.getType() + " " + t.getDescription() + " "
					+ t.getTransactionAmt() + " " + t.getCategory() + newLine);

		}

	}

	@SuppressWarnings("unchecked")
	public void bbBucketReport() {
		// ReportService reportService = new ReportService();

		System.out.println(
				"**************************************    BUDGET BUCKET REPORT    *************************************"
						+ newLine);

		System.out.println(
				"****************************************************************************************************");

		System.out.println("Start Cash Balance: $" + ReportService.getStartCashBalance(
				Calendar.getInstance().get(Calendar.MONTH) + 1, Calendar.getInstance().get(Calendar.YEAR))+ newLine);

		System.out.println("Current Cash Balance: $" + ReportService.getCurrentCashAmt(
				Calendar.getInstance().get(Calendar.MONTH) + 1, Calendar.getInstance().get(Calendar.YEAR))+ newLine);
		
		System.out.println("Projected End Cash Balance: $" + ReportService.getprojectedEndCashAmt(
				Calendar.getInstance().get(Calendar.MONTH) + 1, Calendar.getInstance().get(Calendar.YEAR))+ newLine);

		for (BudgetBucket bucket : (List<BudgetBucket>) DBService.getInstance().getSession()
				.getNamedQuery("BudgetBuckets").getResultList()) {

			System.out.println(bucket.getCategory() + newLine + "Approp Amt: " + bucket.getAppropAmt() + " : "
					+ "Remaining Amt: " + bucket.getRemainingAmt());
			for (Transaction t : (List<Transaction>) bucket.getTransactionList()) {

				System.out.println(sdf.format(t.getDate().getTime()) + " " + t.getType() + " " + t.getDescription() + " "
						+ t.getTransactionAmt() + " " + t.getCategory() + newLine);

			}

		}

	}

}
