package com.ryanwgingrich.budgetButler.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.ryanwgingrich.budgetButler.dto.db.Budget;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.service.BudgetService;
import com.ryanwgingrich.budgetButler.service.DBService;
import com.ryanwgingrich.budgetButler.service.FileService;
import com.ryanwgingrich.budgetButler.service.ReportService;
import com.ryanwgingrich.budgetButler.service.TransactionService;

public class BudgetButlerController {

	// GOLBAL variables
	private Logger logger = LogManager.getLogger(BudgetButlerController.class.getName());
	private static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	private static String newLine = System.getProperty("line.separator");// This will retrieve line separator dependent

	private static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

	private static String transactionFileDir = "/home/ryan/BudgetButler";

	private static int menuIntSelection;

	public BudgetButlerController() {

	}

	public static void initialLoadReset() throws NumberFormatException, IOException, ParseException {

		// Remove existing Budgets, BudgetBickets, Accounts, and Transactions
		DBService.truncate("Account");
		DBService.truncate("Budget");
		DBService.truncate("BudgetBucket");
		DBService.truncate("Transaction");

		// Extract and create appropriate transactions from csv files
		for (File file : new File(transactionFileDir).listFiles()) {

			FileService.parseFile(file.getAbsolutePath());

		}
		Budget budget;

		int minBudgetMonth = TransactionService.getMinDate().get(Calendar.MONTH) + 1;
		int minBudgetYear = TransactionService.getMinDate().get(Calendar.YEAR);

		int maxBudgetMonth = TransactionService.getMaxDate().get(Calendar.MONTH) + 1;
		int maxBudgetYear = TransactionService.getMaxDate().get(Calendar.YEAR);

		int budgetYear = minBudgetYear;
		int budgetMonth = minBudgetMonth;
		while (Integer.valueOf(String.valueOf(budgetYear) + String.format("%02d", budgetMonth)) <= Integer
				.valueOf(String.valueOf(maxBudgetYear) + String.format("%02d", maxBudgetMonth))) {

			budget = new Budget(budgetMonth, budgetYear);
			// process budget
			BudgetService.initBudgetBuckets(budget);

			BudgetService.initBudgetAppropAmt(budget);

			BudgetService.initBudgetExpendAmt(budget);

			BudgetService.initBudgetCashFlow(budget);

			DBService.save(budget);

			budgetMonth += 1;

			if (budgetMonth == 13) {
				budgetMonth = 1;
				budgetYear += 1;
			}

		}

		budgetYear = maxBudgetYear;
		budgetMonth = maxBudgetMonth;

		while (Integer.valueOf(String.valueOf(budgetYear) + String.format("%02d", budgetMonth)) >= Integer
				.valueOf(String.valueOf(minBudgetYear) + String.format("%02d", minBudgetMonth + 1))) {

			budget = (Budget) DBService.getInstance().getSession().get(Budget.class,
					Integer.valueOf(String.valueOf(budgetYear) + String.format("%02d", budgetMonth)));

			budget.setEndCashBalance(BudgetService.getEndCashBalance(budget));

			// budget.setStartCashBalance(BudgetService.getStartCashBalance(budget));
			DBService.save(budget);

			budgetMonth -= 1;

			if (budgetMonth == 0) {
				budgetMonth = 12;
				budgetYear -= 1;
			}

		}

		budgetYear = maxBudgetYear;
		budgetMonth = maxBudgetMonth;
		while (Integer.valueOf(String.valueOf(budgetYear) + String.format("%02d", budgetMonth)) >= Integer
				.valueOf(String.valueOf(minBudgetYear) + String.format("%02d", minBudgetMonth + 1))) {

			budget = (Budget) DBService.getInstance().getSession().get(Budget.class,
					Integer.valueOf(String.valueOf(budgetYear) + String.format("%02d", budgetMonth)));

			budget.setStartCashBalance(BudgetService.getStartCashBalance(budget));
			DBService.save(budget);

			budgetMonth -= 1;

			if (budgetMonth == 0) {
				budgetMonth = 12;
				budgetYear -= 1;
			}

		}

	}

	public static void currentLoadReset() throws NumberFormatException, IOException, ParseException {

		DBService.deleteCurrentData();

		// Extract and create appropriate transactions from csv files
		for (File file : new File(transactionFileDir).listFiles()) {

			FileService.parseFileCurrent(file.getAbsolutePath());

		}

		Budget budget = new Budget(Calendar.getInstance().get(Calendar.MONTH) + 1,
				Calendar.getInstance().get(Calendar.YEAR));

		budget.setEndCashBalance(BudgetService.getEndCashBalance(budget));
		budget.setStartCashBalance(BudgetService.getStartCashBalance(budget));
		DBService.save(budget);

	}

	public static int mainMenu() throws NumberFormatException, IOException, ParseException {

		System.out.println(
				"******************************************    MAIN MENU    *****************************************"
						+ newLine);
		System.out.println("1: Update Menu");
		System.out.println("2: Create Menu");
		System.out.println("3: Report Menu");
		System.out.println("9: Exit" + newLine);
		System.out.println(
				"****************************************************************************************************");

		menuIntSelection = getIntConsoleInput();

		if (Integer.compare(menuIntSelection, 0) > 0)
			return menuIntSelection;
		return 0;

	}

	public static int updateMenu() {

		System.out.println(
				"******************************************    UPDATE MENU    *****************************************"
						+ newLine);
		System.out.println("1: Load/Reset Current Data");
		System.out.println("2: Modify Budget");
		System.out.println("3: Initial Load/ Reset All Data");
		System.out.println("9: Exit" + newLine);
		System.out.println(
				"****************************************************************************************************");

		menuIntSelection = getIntConsoleInput();

		if (Integer.compare(menuIntSelection, 0) > 0)
			return menuIntSelection;
		return 0;
	}

	public static int createMenu() {
		System.out.println(
				"******************************************    CREATE MENU    *****************************************"
						+ newLine);
		System.out.println("1: Create New Budget");
		System.out.println("9: Exit" + newLine);
		System.out.println(
				"****************************************************************************************************");

		menuIntSelection = getIntConsoleInput();

		if (Integer.compare(menuIntSelection, 0) > 0)
			return menuIntSelection;
		return 0;
	}

	public static int reportMenu() {
		System.out.println(
				"******************************************    REPORT MENU    *****************************************"
						+ newLine);
		System.out.println("1: Current Transactions");
		System.out.println("2: Budget Report");
		System.out.println("9: Exit" + newLine);
		System.out.println(
				"****************************************************************************************************");

		menuIntSelection = getIntConsoleInput();

		if (Integer.compare(menuIntSelection, 0) > 0)
			return menuIntSelection;
		return 0;

	}

	public static void transactionReport() {

		System.out.println(
				"**************************************    TRANSACTION REPORT    *************************************"
						+ newLine);

		System.out.println(
				"****************************************************************************************************");

		for (Transaction t : ReportService.transactionReport(Calendar.getInstance().get(Calendar.MONTH) + 1,
				Calendar.getInstance().get(Calendar.YEAR))) {
			System.out.println(sdf.format(t.getDate().getTime()) + " " + t.getType() + " " + t.getDescription() + " "
					+ t.getTransactionAmt() + " " + t.getCategory() + newLine);

		}

	}

	public static void currentBudgetReport() {

		int budgetYear = Calendar.getInstance().get(Calendar.YEAR);
		int budgetMonth = Calendar.getInstance().get(Calendar.MONTH) + 1;

		Budget budget = DBService.getInstance().getSession().get(Budget.class,
				Integer.valueOf(String.valueOf(budgetYear) + String.format("%02d", budgetMonth)));

		BudgetService.budgetReport(budget);

	}

	public static void budgetReport() {

		System.out.println("Enter Budget Month: ");
		int budgetMonth = getIntConsoleInput();
		System.out.println("Enter Budget Year: ");
		int budgetYear = getIntConsoleInput();

		// int budgetYear = Calendar.getInstance().get(Calendar.YEAR);
		// int budgetMonth = Calendar.getInstance().get(Calendar.MONTH) + 1;

		Budget budget = DBService.getInstance().getSession().get(Budget.class,
				Integer.valueOf(String.valueOf(budgetYear) + String.format("%02d", budgetMonth)));

		BudgetService.budgetReport(budget);

	}

	public static void modifyBudget() throws NumberFormatException, IOException {
		System.out.println("Enter Budget Month: ");
		int budgetMonth = getIntConsoleInput();
		System.out.println("Enter Budget Year: ");
		int budgetYear = getIntConsoleInput();

		BudgetService.modifyBudget(DBService.getInstance().getSession().get(Budget.class,
				Integer.valueOf(String.valueOf(budgetYear) + String.format("%02d", budgetMonth))));

	}

	public static String getStringConsoleInput() throws IOException {

		String input = "";
		System.out.println("ENTER SELECTION: ");

		input = br.readLine();

		return input;
	}

	public static int getIntConsoleInput() {

		int input = 0;
		System.out.println("MAKE SELECTION [0-9]: ");

		try {
			input = Integer.valueOf(br.readLine());
		} catch (NumberFormatException e) {
			System.out.println("***INVALID***");
			input = getIntConsoleInput();
			// e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return input;
	}

	public static void createBudget() {
		System.out.println("Enter Budget Month: ");
		int budgetMonth = getIntConsoleInput();
		System.out.println("Enter Budget Year: ");
		int budgetYear = getIntConsoleInput();

		Budget budget;

		budget = new Budget(budgetMonth, budgetYear);
		
		
		
		BudgetService.initBudgetBuckets(budget);

		BudgetService.initBudgetAppropAmt(budget);

		BudgetService.initBudgetExpendAmt(budget);

		BudgetService.initBudgetCashFlow(budget);

		
		

		budget.setStartCashBalance(BudgetService.getStartCashBalance(budget));
		
		budget.setEndCashBalance(BudgetService.getEndCashBalance(budget));

		DBService.save(budget);

	}
}
