package com.ryanwgingrich.budgetButler.dto;



import java.math.BigDecimal;


import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
@Embeddable
public class BudgetBucket {
	
	
	@Id @GeneratedValue
	private int id;
	
	private String category;
	private BigDecimal amt;
	
	
	public BudgetBucket() {
		
	}
	public BudgetBucket(int id, String category, BigDecimal amount) {
		
		this.id = id;
		this.category = category;
		this.amt = amount;		
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public BigDecimal getAmt() {
		return amt;
	}
	public void setAmt(BigDecimal amt) {
		this.amt = amt;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}	
}
