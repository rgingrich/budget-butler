package com.ryanwgingrich.budgetButler.dto.db;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


import com.ryanwgingrich.budgetButler.enums.BucketCategory;

@Entity
@Embeddable
public class TransactionDescriptor { 
	
	@Id
	//@GeneratedValue
	private String transactionDescription;
	private BucketCategory budgetBucket;
	
	public TransactionDescriptor() {
		
	}
	
	public TransactionDescriptor(String description, BucketCategory enteredCategory) {
		this.transactionDescription = description;
		this.budgetBucket = enteredCategory;
	}
	
	public String getTransactionDescription() {
		return transactionDescription;
	}
	public BucketCategory getBudgetBucket() {
		return budgetBucket;
	}
	public void setTransactionDescriprion(String transactionDescription) {
		this.transactionDescription = transactionDescription;
	}
	public void setBudgetBucket(BucketCategory budgetBucket) {
		this.budgetBucket = budgetBucket;
	}
	

}
