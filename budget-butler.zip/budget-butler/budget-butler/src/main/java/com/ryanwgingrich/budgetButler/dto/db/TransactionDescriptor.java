package com.ryanwgingrich.budgetButler.dto.db;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.NamedQuery;

import com.ryanwgingrich.budgetButler.enums.BucketCategory;

@NamedQuery(name = "TransactionDescriptors", query = "FROM TransactionDescriptor")

@NamedQuery(name = "DescriptorBucketLookup", query = "select budgetBucket FROM TransactionDescriptor where descriptor = :descriptor")

@NamedQuery(name = "DeleteTransactionDescriptors", query = "delete TransactionDescriptor")


@Entity
@Embeddable
public class TransactionDescriptor { 
	
	@Id
	//@GeneratedValue
	private String descriptor;
	private BucketCategory budgetBucket;
	
	public TransactionDescriptor() {
		
	}
	
	public TransactionDescriptor(String description, BucketCategory enteredCategory) {
		this.descriptor = description;
		this.budgetBucket = enteredCategory;
	}
	
	public String getDescriptor() {
		return descriptor;
	}
	public BucketCategory getBudgetBucket() {
		return budgetBucket;
	}
	public void setTransactionDescriprion(String transactionDescription) {
		this.descriptor = transactionDescription;
	}
	public void setBudgetBucket(BucketCategory budgetBucket) {
		this.budgetBucket = budgetBucket;
	}
	

}