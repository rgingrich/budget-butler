package com.ryanwgingrich.budgetButler.processor;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.hibernate.Session;

import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;

public interface Processor {

	//void processTransactions(BudgetBucket rentBucket, Session session);
	
	BigDecimal getMonthTtl(BudgetBucket bucket, Session session, Calendar date);
	
	BigDecimal getYearTtl(BudgetBucket bucket, Session session, Calendar date);
	
	void updateBucket(Session session, BudgetBucket bucket, Calendar date);
	
	
	
}
