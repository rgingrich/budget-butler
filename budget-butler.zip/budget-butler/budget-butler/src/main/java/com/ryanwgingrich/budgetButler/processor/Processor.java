package com.ryanwgingrich.budgetButler.processor;

import java.text.SimpleDateFormat;
import java.util.List;

import org.hibernate.Session;

import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;

public interface Processor {
	//SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	//String newLine = System.getProperty("line.separator");
	
	//Date getMaxDate(Session Session);
	//List<?> getTransactionList(Session Session);
	//void processTransactions(BudgetBucket rentBucket);

	void processTransactions(BudgetBucket rentBucket, Session session);
	
	

}
