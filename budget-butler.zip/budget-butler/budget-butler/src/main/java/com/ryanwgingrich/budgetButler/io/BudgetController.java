package com.ryanwgingrich.budgetButler.io;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.ryanwgingrich.budgetButler.dto.db.Account;
import com.ryanwgingrich.budgetButler.dto.db.Budget;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.enums.AccountType;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.service.DBService;

public class BudgetController {
	public BudgetController() {

	}

	@SuppressWarnings("unchecked")
	public void initialize(int budgetMonth, int budgetYear) {

		/********************************************************
		 * set bucket list
		 *******************************************************/

		Budget budget = new Budget(budgetMonth, budgetYear);
		List<BudgetBucket> bucketList = new ArrayList<BudgetBucket>();

		int bucketId = Integer
				.valueOf(String.valueOf(budgetYear) + String.format("%02d", budgetMonth) + String.format("%02d", 0));

		int maxbucketId = Integer.valueOf(String.valueOf(budgetYear) + String.format("%02d", budgetMonth)
				+ String.format("%02d", BucketCategory.values().length - 1));

		while (bucketId <= maxbucketId) {

			bucketList.add(DBService.getInstance().getSession().get(BudgetBucket.class, bucketId));
			bucketId++;

		}
		budget.setBucketList(bucketList);

		/********************************************************
		 * set appropriation amount
		 *******************************************************/

		BigDecimal appropAmt = BigDecimal.valueOf(0);
		for (BudgetBucket bucket : bucketList) {

			if (bucket.getCategory() != BucketCategory.NONE && bucket.getCategory() != BucketCategory.INCOME) {

				appropAmt = appropAmt.add(bucket.getAppropiationAmt());
			}

		}
		budget.setAppropAmt(appropAmt);

		/********************************************************
		 * set expended amount
		 *******************************************************/

		BigDecimal expendedAmt = BigDecimal.valueOf(0);

		for (BudgetBucket bucket : bucketList) {

			if (bucket.getCategory() != BucketCategory.NONE && bucket.getCategory() != BucketCategory.INCOME) {

				// for (Transaction t : bucket.getTransactionList()) {

				// if (t.getAccountType() != AccountType.AMEX_CREDIT) {

				// expendedAmt = expendedAmt.add(t.getTransactionAmt());

				// }
				expendedAmt = expendedAmt.add(bucket.getCashExpenditureAmt());

			}

		}

		budget.setExpendAmt(expendedAmt);

		/********************************************************
		 * set cashflow amount
		 *******************************************************/

		BigDecimal cashFlow = BigDecimal.valueOf(0);

		for (BudgetBucket bucket : bucketList) {

			if (bucket.getCategory() == BucketCategory.INCOME) {

				cashFlow = cashFlow.add((bucket.getCashCreditAmt()));

			} else if (bucket.getCategory() != BucketCategory.NONE) {

				// for (Transaction t : bucket.getTransactionList()) {

				// if (t.getAccountType() != AccountType.AMEX_CREDIT) {

				// cashFlow = cashFlow.subtract(t.getTransactionAmt());

				// }

				cashFlow = cashFlow.subtract(bucket.getCashExpenditureAmt());

			}

		}

		budget.setCashFlow(cashFlow);

		/********************************************************
		 * set end cash balance amount
		 *******************************************************/

		BigDecimal endCashBalance = BigDecimal.valueOf(0);

		int cashAcctCounter = 3;

		for (Account account : (List<Account>) DBService.getInstance().getSession().getNamedQuery("Accounts")
				.getResultList()) {
			BigDecimal acctEndCashBalance = BigDecimal.valueOf(0);

			if (account.getAccountType().equals(AccountType.SCHWAB_CASH)) {

				int minID = 99999999;
				for (Transaction aTransaction : (List<Transaction>) account.getTransactionList()) {

					for (BudgetBucket budgetBucket : bucketList) {

						for (Transaction bTransaction : budgetBucket.getTransactionList()) {

							if (aTransaction.getId() == bTransaction.getId()) {

								if (minID > aTransaction.getId()) {
									minID = aTransaction.getId();
									acctEndCashBalance = aTransaction.getRunningBal();
									cashAcctCounter -= 1;

								}

							}

						}

					}

				}

			}
			endCashBalance = endCashBalance.add(acctEndCashBalance);

		}

		BigDecimal appropIncomeAmt = BigDecimal.valueOf(0);

		BudgetBucket incomeBucket = DBService.getInstance().getSession().get(BudgetBucket.class,
				Integer.valueOf(String.valueOf(budget.getYear()) + String.format("%02d", budget.getMonth())
						+ String.format("%02d", BucketCategory.INCOME.ordinal())));

		appropIncomeAmt = incomeBucket.getAppropiationAmt();

		endCashBalance = (endCashBalance.equals(BigDecimal.valueOf(0)) || (cashAcctCounter > 0)
				? (budget.getStartCashBalance().subtract(appropAmt).add(appropIncomeAmt))
				: endCashBalance);

		budget.setEndCashBalance(endCashBalance);

		/********************************************************
		 * set start cash balance amount
		 *******************************************************/

		BigDecimal startCashBalance = BigDecimal.valueOf(0);

		budgetMonth -= 1;

		if (budgetMonth == 0) {
			budgetMonth = 12;
			budgetYear -= 1;
		}

		Budget prevBudget = DBService.getInstance().getSession().get(Budget.class,
				Integer.valueOf(String.valueOf(budgetYear) + String.format("%02d", budgetMonth)));

		startCashBalance = prevBudget == null ? BigDecimal.valueOf(0) : prevBudget.getEndCashBalance();
		budget.setStartCashBalance(startCashBalance);

		DBService.getInstance().save(budget);

	}

}
