package com.ryanwgingrich.budgetButler.io;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.ryanwgingrich.budgetButler.dto.db.Account;
import com.ryanwgingrich.budgetButler.dto.db.Budget;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.enums.AccountType;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.EnumLookupUtil;
import com.ryanwgingrich.budgetButler.service.DBService;

public class BudgetController {
	public BudgetController() {

	}

	public void initialize(int budgetMonth, int budgetYear) {

		/********************************************************
		 * set bucket list
		 *******************************************************/

		Budget budget = new Budget(budgetMonth, budgetYear);
		List<BudgetBucket> bucketList = new ArrayList<BudgetBucket>();

		int bucketId = Integer
				.valueOf(String.valueOf(budgetYear) + String.format("%02d", budgetMonth) + String.format("%02d", 0));

		int maxbucketId = Integer.valueOf(String.valueOf(budgetYear) + String.format("%02d", budgetMonth)
				+ String.format("%02d", BucketCategory.values().length - 1));

		while (bucketId <= maxbucketId) {

			bucketList.add(DBService.getInstance().getSession().get(BudgetBucket.class, bucketId));
			bucketId++;

		}
		budget.setBucketList(bucketList);

		/********************************************************
		 * set appropriation amount
		 *******************************************************/
		BigDecimal appropAmt = calcAppropAmt(budget);
		budget.setAppropAmt(appropAmt);

		/********************************************************
		 * set expended amount
		 *******************************************************/

		BigDecimal expendedAmt = BigDecimal.valueOf(0);

		for (BudgetBucket bucket : bucketList) {

			if (bucket.getCategory() != BucketCategory.NONE && bucket.getCategory() != BucketCategory.INCOME) {

				expendedAmt = expendedAmt.add(bucket.getCashExpenditureAmt());

			}

		}

		budget.setExpendAmt(expendedAmt);

		/********************************************************
		 * set income amount
		 *******************************************************/
		BigDecimal incomeAmt = BigDecimal.valueOf(0);

		for (BudgetBucket bucket : bucketList) {

			incomeAmt = (bucket.getCategory().equals(EnumLookupUtil.lookup(BucketCategory.class, "INCOME"))
					? incomeAmt.add(bucket.getCashCreditAmt())
					: incomeAmt);
		}

		budget.setIncomeAmt(incomeAmt);

		/********************************************************
		 * set cashflow amount
		 *******************************************************/

		BigDecimal cashFlow = incomeAmt;

		for (BudgetBucket bucket : bucketList) {

			cashFlow = (bucket.getCategory().compareTo(EnumLookupUtil.lookup(BucketCategory.class, "NONE")) != 0
					? cashFlow.subtract((bucket.getCashExpenditureAmt() == null ? BigDecimal.valueOf(0)
							: bucket.getCashExpenditureAmt()))
					: cashFlow);
		}

		budget.setCashFlow(cashFlow);

		/********************************************************
		 * set start cash balance amount
		 *******************************************************/
		BigDecimal startCashBalance = calcStartCashAmt(budget);
		budget.setStartCashBalance(startCashBalance);

		/********************************************************
		 * set end cash balance amount
		 *******************************************************/
		BigDecimal endCashBalance = calcEndCashAmt(budget);
		budget.setEndCashBalance(endCashBalance);

		DBService.getInstance().save(budget);

	}

	private BigDecimal calcStartCashAmt(Budget budget) {
		int budgetMonth = budget.getMonth() - 1;
		int budgetYear = budget.getYear();

		if (budgetMonth == 0) {
			budgetMonth = 12;
			budgetYear -= 1;
		}

		Budget prevBudget = DBService.getInstance().getSession().get(Budget.class,
				Integer.valueOf(String.valueOf(budgetYear) + String.format("%02d", budgetMonth)));

		return prevBudget == null ? BigDecimal.valueOf(0) : prevBudget.getEndCashBalance();

	}

	@SuppressWarnings("unchecked")
	private BigDecimal calcEndCashAmt(Budget budget) {

		int cashAcctCounter = 3;
		BigDecimal endCashBalance = BigDecimal.valueOf(0);

		for (Account account : (List<Account>) DBService.getInstance().getSession().getNamedQuery("Accounts")
				.getResultList()) {
			BigDecimal acctEndCashBalance = BigDecimal.valueOf(0);

			if (account.getAccountType().equals(AccountType.SCHWAB_CASH)) {

				int minID = 99999999;
				for (Transaction aTransaction : (List<Transaction>) account.getTransactionList()) {

					for (BudgetBucket budgetBucket : budget.getBucketList()) {

						List<Transaction> transactionList = (List<Transaction>) budgetBucket.getTransactionList();

						for (Transaction bTransaction : transactionList) {

							if (aTransaction.getId() == bTransaction.getId()) {

								if (minID > aTransaction.getId()) {
									minID = aTransaction.getId();
									acctEndCashBalance = aTransaction.getRunningBal();
									cashAcctCounter -= 1;

								}

							}

						}

					}

				}

			}
			endCashBalance = endCashBalance.add(acctEndCashBalance);

		}

		BigDecimal appropIncomeAmt = BigDecimal.valueOf(0);

		BudgetBucket incomeBucket = DBService.getInstance().getSession().get(BudgetBucket.class,
				Integer.valueOf(String.valueOf(budget.getYear()) + String.format("%02d", budget.getMonth())
						+ String.format("%02d", BucketCategory.INCOME.ordinal())));

		appropIncomeAmt = incomeBucket.getAppropiationAmt();

		return (endCashBalance.equals(BigDecimal.valueOf(0)) || (cashAcctCounter > 0)
				? (budget.getStartCashBalance().subtract(budget.getAppropAmt()).add(appropIncomeAmt))
				: endCashBalance);
	}

	private BigDecimal calcAppropAmt(Budget budget) {

		BigDecimal appropAmt = BigDecimal.valueOf(0);
		for (BudgetBucket bucket : budget.getBucketList()) {

			if (bucket.getCategory() != BucketCategory.NONE && bucket.getCategory() != BucketCategory.INCOME) {

				appropAmt = appropAmt.add(bucket.getAppropiationAmt());
			}

		}

		return appropAmt;
	}

	public void modifyBudget(int budgetMonth, int budgetYear) throws IOException {

		Budget budget = DBService.getInstance().getSession().get(Budget.class,
				Integer.valueOf(String.valueOf(budgetYear) + String.format("%02d", budgetMonth)));

		System.out.println("Updating Budget: " + budget.getId());

		BigDecimal inputAmt = BigDecimal.valueOf(0);

		for (BudgetBucket bucket : (List<BudgetBucket>) budget.getBucketList()) {

			System.out.println("Updating Budget Bucket: " + bucket.getCategory());
			System.out.println("Current Appropiation Amount: " + bucket.getAppropiationAmt());

			if (bucket.getCategory() == BucketCategory.INCOME) {
				System.out.println("Current Credit Amount: " + bucket.getCashCreditAmt());
				System.out.println("Enter New Appropiation Amount: ");

			} else {
				System.out.println("Current Expenditure Amount: "
						+ bucket.getCashExpenditureAmt().add(bucket.getCreditExpenditureAmt()));
				System.out.println("Enter New Appropiation Amount: ");

			}
			String inputString = getStringConsoleInput();

			inputAmt = BigDecimal.valueOf(
					Float.parseFloat((inputString.isEmpty() ? bucket.getAppropiationAmt().toString() : inputString)));

			bucket.setAppropiationAmt(inputAmt);
			DBService.getInstance().save(bucket);

		}

		budget.setAppropAmt(calcAppropAmt(budget));

		while (budget != null) {

			budget.setEndCashBalance(calcEndCashAmt(budget));
			budget.setStartCashBalance(calcStartCashAmt(budget));
			DBService.getInstance().save(budget);

			budgetYear = (budgetMonth + 1 == 13 ? budgetYear + 1 : budgetYear);
			budgetMonth = (budgetMonth + 1 == 13 ? 1 : budgetMonth + 1);

			budget = DBService.getInstance().getSession().get(Budget.class,
					Integer.valueOf(String.valueOf(budgetYear) + String.format("%02d", budgetMonth)));

		}

	}

	private String getStringConsoleInput() throws IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		String input = "";
		System.out.println("ENTER SELECTION: ");

		input = br.readLine();

		return input;
	}

}
