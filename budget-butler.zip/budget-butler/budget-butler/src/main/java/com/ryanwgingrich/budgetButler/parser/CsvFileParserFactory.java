package com.ryanwgingrich.budgetButler.parser;

import com.ryanwgingrich.budgetButler.parser.CsvFileParser;

public class CsvFileParserFactory {

	public CsvFileParser getFileParser(String fileName) {
		if (fileName.contains("TransactionDescriptor")) {
			return new TransactionDescriptorParser();

		} else if (fileName.contains("Chase")) {
			return new ChaseTransactionParser();
		} else if (fileName.contains("Checking")) {
			return new SchwabTransactionParser();
		} else if (fileName.contains("Transactions")) {
			return new AmexTransactionParser();
		} else
			return null;

	}
}
