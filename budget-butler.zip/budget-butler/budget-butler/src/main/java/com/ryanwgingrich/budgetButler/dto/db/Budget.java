package com.ryanwgingrich.budgetButler.dto.db;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.annotations.NamedQuery;

import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.BudgetStatus;
import com.ryanwgingrich.budgetButler.service.BucketService;
import com.ryanwgingrich.budgetButler.service.BudgetService;
import com.ryanwgingrich.budgetButler.service.DBService;
import com.ryanwgingrich.budgetButler.service.TransactionService;

@NamedQuery(name = "Budget.byYearMonth", query = "FROM Budget " + "where year = :year and month = :month")

@NamedQuery(name = "DeleteBudgetById", query = "delete Budget where id = :id")

@Entity
public class Budget {
	static Logger logger = LogManager.getLogger(Budget.class.getName());

	// DateFormat format = new SimpleDateFormat("mm/dd/yyyy", Locale.ENGLISH);
	// String DATE_FORMAT = "MM/dd/yyyy";
	// SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);

	@Id
	int id;
	private int month = 0;
	private int year = 0;
	private BigDecimal startCashBalance;
	private BigDecimal endCashBalance;
	@ElementCollection
	private Collection<BudgetBucket> bucketList = new ArrayList<BudgetBucket>();
	// private BudgetStatus budgetStatus;

	public Budget() {

	}

	public Budget(int month, int year) {

		this.month = month;
		this.year = year;
		this.id = Integer.valueOf(String.valueOf(year) + String.format("%02d", month));

		for (BucketCategory category : BucketCategory.values()) {

			BudgetBucket budgetBucket = new BudgetBucket(year, month, category);

			DBService.save(budgetBucket);
			this.bucketList.add(budgetBucket);
		}
		
	//	this.startCashBalance = BudgetService.getStartCashBalance(this);

	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public BigDecimal getStartCashBalance() {
		return startCashBalance;
	}

	public void setStartCashBalance(BigDecimal startCashBalance) {
		this.startCashBalance = startCashBalance;
	}

	public BigDecimal getEndCashBalance() {
		return endCashBalance;
	}

	public void setEndCashBalance(BigDecimal endCashBalance) {
		this.endCashBalance = endCashBalance;
	}

	public Collection<BudgetBucket> getBucketList() {
		return bucketList;
	}

	public void setBucketList(Collection<BudgetBucket> bucketList) {
		this.bucketList = bucketList;
	}

//	public BudgetStatus getBudgetStatus() {
//		return budgetStatus;
//	}
//
//	public void setBudgetStatus(BudgetStatus budgetStatus) {
//		this.budgetStatus = budgetStatus;
//	}

}
