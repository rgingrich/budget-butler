package com.ryanwgingrich.budgetButler.dto.db;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.annotations.NamedQuery;

import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.BudgetStatus;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

// @NamedQuery(name = "SumTransactions.byCategoryYearMonth", query = "SELECT
// SUM(" + "case "
// + "when type in (9) and transactionAmt < 0 "// TransactionType.AMEX(9)
// + "then abs(transactionAmt) " + "else transactionAmt end) " + "FROM
// Transaction "
// + "where category = :category and YEAR(date) = :year and MONTH(date) = :month
// +1")
//
// @NamedQuery(name = "SumTransactions.byCategoryYear", query = "SELECT SUM(" +
// "case "
// + "when type in (9) and transactionAmt < 0 "// TransactionType.AMEX(9)
// + "then abs(transactionAmt) " + "else transactionAmt end) " + "FROM
// Transaction "
// + "where category = :category and YEAR(date) = :year")
//
// @NamedQuery(name = "Transactions.byCategoryYearMonth", query = "FROM
// Transaction "
// + "where category = :category and YEAR(date) = :year and MONTH(date) = :month
// +1")
//
// @NamedQuery(name = "Transactions.byYearMonth", query = "FROM Transaction "
// + "where YEAR(date) = :year and MONTH(date) = :month +1")
//
// @NamedQuery(name = "Transactions", query = "FROM Transaction")

@Entity
public class Budget {
	static Logger logger = LogManager.getLogger(Budget.class.getName());

	// DateFormat format = new SimpleDateFormat("mm/dd/yyyy", Locale.ENGLISH);
	String DATE_FORMAT = "MM/dd/yyyy";
	SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);

	@Id
	@GeneratedValue
	private int id;
	private String name;
	private Date startDate;
	private Date endDate;
	private BigDecimal cashBalance;
	private BigDecimal creditBalance;
	@ElementCollection
	private Collection<BudgetBucket> bucketList = new ArrayList<BudgetBucket>();
	@ElementCollection
	private Collection<Account> cashAcctList = new ArrayList<Account>();
	//@ElementCollection
	//private Collection<Account> creditAcctList = new ArrayList<Account>();
	private BudgetStatus budgetStatus;

	public Budget() {

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public Date getStartDate() {
		return startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public BigDecimal getCashBalance() {
		return cashBalance;
	}

	public BigDecimal getCreditBalance() {
		return creditBalance;
	}

	public Collection<BudgetBucket> getBucketList() {
		return bucketList;
	}

	public Collection<Account> getCashAcctList() {
		return cashAcctList;
	}

//	public Collection<Account> getCreditAcctList() {
//		return creditAcctList;
//	}

	public BudgetStatus getBudgetStatus() {
		return budgetStatus;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public void setCashBalance(BigDecimal cashBalance) {
		this.cashBalance = cashBalance;
	}

	public void setCreditBalance(BigDecimal creditBalance) {
		this.creditBalance = creditBalance;
	}

	public void setBucketList(Collection<BudgetBucket> bucketList) {
		this.bucketList = bucketList;
	}

	public void setCashAcctList(Collection<Account> cashAcctList) {
		this.cashAcctList = cashAcctList;
	}

//	public void setCreditAcctList(Collection<Account> creditAcctList) {
//		this.creditAcctList = creditAcctList;
//	}

	public void setBudgetStatus(BudgetStatus budgetStatus) {
		this.budgetStatus = budgetStatus;
	}

}
