package com.ryanwgingrich.budgetButler.parser;

import com.ryanwgingrich.budgetButler.enums.FinancialInstitutionCode;

public class ParseFactory {

	public Parser getParser(FinancialInstitutionCode financialInstitutionCode) {
		if (financialInstitutionCode.equals(FinancialInstitutionCode.CHARLES_SCHWAB_BANK)) {
			return new SchwabParser();

		} else if (financialInstitutionCode.equals(FinancialInstitutionCode.CHASE_BANK)) {
			return new ChaseParser();

		} else if (financialInstitutionCode.equals(FinancialInstitutionCode.AMERICAN_EXPRESS_CREDIT)) {
			return new AmexParser();
		}

		return null;
	}
}
