package com.ryanwgingrich.budgetButler.parser;

import com.ryanwgingrich.budgetButler.enums.ParserType;

public class ParseFactory {

	public Parser getParser(ParserType parserType) {
		if (parserType.equals(ParserType.SCHWAB_BANK)) {
			return new SchwabParser();

		} else if (parserType.equals(ParserType.CHASE_BANK)) {
			return new ChaseParser();

		} else if (parserType.equals(ParserType.AMEX_CREDIT)) {
			return new AmexParser();
		} 
		else if (parserType.equals(ParserType.DESCRIPTOR)) {
			return new DescriptorParser();
		}
		
		return null;

	}
}
