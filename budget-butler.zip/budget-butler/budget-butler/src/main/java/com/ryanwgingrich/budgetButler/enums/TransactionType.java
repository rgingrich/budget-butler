package com.ryanwgingrich.budgetButler.enums;

public enum TransactionType {	
	ACH,
	ATM,
	ATMREBATE,
	CHECK,
	DEPOSIT,
	INTADJUST,
	TRANSFER,
	VISA,
	PENDING,
	SALE,
	FEE,
	AMEX,
	PAYMENT,
	RETURN
}
