package com.ryanwgingrich.budgetButler.parser;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.List;
import java.util.ListIterator;

import com.opencsv.bean.CsvToBeanBuilder;
import com.ryanwgingrich.budgetButler.io.csvToBean.ChaseTransaction;

public class ChaseTransactionParser extends CsvFileParser {

	@Override
	public List<ChaseTransaction> getItems(String fileName, Class itemClass) throws FileNotFoundException {
		FileReader fileReader = new FileReader(fileName);

		CsvToBeanBuilder<?> csvToBeanBuilder = new CsvToBeanBuilder<ChaseTransaction>(fileReader)
				.withType(ChaseTransaction.class);

		@SuppressWarnings("unchecked")
		List<ChaseTransaction> chaseTransactions = (List<ChaseTransaction>) csvToBeanBuilder.build().parse();

		ListIterator<ChaseTransaction> chaseIterator = chaseTransactions.listIterator();

		ChaseTransaction chaseTransaction;
		while (chaseIterator.hasNext()) {
			chaseTransaction = (ChaseTransaction) chaseIterator.next();
			if (chaseTransaction.getDate().equalsIgnoreCase("Trans Date")) {
				chaseIterator.remove();
			}
		}

		return chaseTransactions;
	}

}
