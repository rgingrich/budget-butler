package com.ryanwgingrich.budgetButler.parser;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.List;
import java.util.ListIterator;

import org.hibernate.Session;

import com.opencsv.bean.CsvToBeanBuilder;
import com.ryanwgingrich.budgetButler.dto.csv.SchwabTransaction;
import com.ryanwgingrich.budgetButler.dto.csv.TransactionDescriptorCSV;
import com.ryanwgingrich.budgetButler.dto.db.TransactionDescriptor;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

public class DescriptorParser implements Parser {

	@Override
	public List<TransactionDescriptorCSV> getRecordList(String fileName) throws FileNotFoundException {
		
		FileReader fileReader = new FileReader(fileName);

		CsvToBeanBuilder<TransactionDescriptorCSV> csvToBeanBuilder = new CsvToBeanBuilder<TransactionDescriptorCSV>(fileReader).withType(TransactionDescriptorCSV.class);

		List<TransactionDescriptorCSV> descriptorList = (List<TransactionDescriptorCSV>) csvToBeanBuilder.build().parse();

		
		
		return descriptorList;
		
		
		
	}

	@Override
	public void parseToDB(String fileName, Session session) throws FileNotFoundException {
		session.beginTransaction();
	
		List<TransactionDescriptorCSV> descriptorList = (List<TransactionDescriptorCSV>) getRecordList(fileName);
		
		
		

		for (TransactionDescriptorCSV descriptor : descriptorList) {
			

			session.save(new TransactionDescriptor(descriptor.getDescriptor(),BucketCategory.valueOf(descriptor.getBudgetBucket())));

		}

		session.getTransaction().commit();
		
	}

	

}
