package com.ryanwgingrich.budgetButler.parser;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.List;
import java.util.ListIterator;

import org.hibernate.Session;

import com.opencsv.bean.CsvToBeanBuilder;
import com.ryanwgingrich.budgetButler.dto.db.SchwabTransactionDescriptor;
import com.ryanwgingrich.budgetButler.dto.db.TransactionDescriptor;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;
import com.ryanwgingrich.budgetButler.io.csvToBean.SchwabTransaction;

public class DescriptorParser implements Parser {

	@Override
	public List<SchwabTransactionDescriptor> getRecordList(String fileName) throws FileNotFoundException {
		
		FileReader fileReader = new FileReader(fileName);

		CsvToBeanBuilder<SchwabTransactionDescriptor> csvToBeanBuilder = new CsvToBeanBuilder<SchwabTransactionDescriptor>(fileReader).withType(SchwabTransactionDescriptor.class);

		List<SchwabTransactionDescriptor> descriptorList = (List<SchwabTransactionDescriptor>) csvToBeanBuilder.build().parse();

		
		
		return descriptorList;
		
		
		
	}

	@Override
	public void parseToDB(String fileName, Session session) throws FileNotFoundException {
		session.beginTransaction();
	
		List<SchwabTransactionDescriptor> descriptorList = (List<SchwabTransactionDescriptor>) getRecordList(fileName);
		
		
		

		for (SchwabTransactionDescriptor descriptor : descriptorList) {
			

			session.save(new TransactionDescriptor(descriptor.getDescriptor(),BucketCategory.valueOf(descriptor.getBudgetBucket())));

		}

		session.getTransaction().commit();
		
	}

	

}
