package com.ryanwgingrich.budgetButler.factory;

import java.io.FileNotFoundException;
import java.util.List;


public interface Parser {
	
	List<?> getTransactionList(String fileName) throws FileNotFoundException;
		
		
}