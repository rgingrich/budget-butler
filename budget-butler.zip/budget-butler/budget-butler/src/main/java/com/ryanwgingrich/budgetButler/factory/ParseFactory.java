package com.ryanwgingrich.budgetButler.factory;

import com.ryanwgingrich.budgetButler.enums.FinancialInstitutionCode;

public class ParseFactory {

	public Parser getParser(FinancialInstitutionCode financialInstitutionCode) {
		if (financialInstitutionCode == null) {
			return null;
		}
		if (financialInstitutionCode.equals(FinancialInstitutionCode.SCHWAB)) {
			return new SchwabParser();

		} else if (financialInstitutionCode.equals(FinancialInstitutionCode.CHASE)) {
			return new ChaseParser();

		} else if (financialInstitutionCode.equals(FinancialInstitutionCode.AMEX)) {
			return new AmexParser();
		}

		return null;
	}
}
