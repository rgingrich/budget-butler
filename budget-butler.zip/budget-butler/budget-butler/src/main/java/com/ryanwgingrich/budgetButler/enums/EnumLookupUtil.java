package com.ryanwgingrich.budgetButler.enums;

public class EnumLookupUtil {
	public static <E extends Enum<E>> E lookup(Class<E> c, String id) {
		E result = null;
		try {
			result = Enum.valueOf(c, id);
		} catch (IllegalArgumentException e) {
			System.out.println(
					"****************************************************************************************************");
			System.out.println("Invalid " + c.getSimpleName() + " value: " + id);
		}

		return result;
	}

}
