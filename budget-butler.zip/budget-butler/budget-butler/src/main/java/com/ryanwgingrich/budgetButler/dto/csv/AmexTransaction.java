package com.ryanwgingrich.budgetButler.dto.csv;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByPosition;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

public class AmexTransaction {

	public AmexTransaction() {
	}

	@CsvBindByPosition(required = true, position = 0)
	private String date;

	@CsvBindByPosition(required = false, position = 2)
	private String description;
	
	@CsvBindByPosition(required = false, position = 3)
	private String cardHolder;

	@CsvBindByPosition(required = false, position = 7)
	private String transactionAmount;

	public String getDate() {
		return date;
	}
	public String getDescription() {
		return description;
	}
	public String getCardHolder() {
		return cardHolder;
	}
	public String getTransactionAmount() {
		return transactionAmount;
	}
	
	public void setDate(String date) {
		this.date = date;
	}	
	public void setDescription(String description) {
		this.description = description;
	}
	public void setCardHolder(String cardHolder) {
		this.cardHolder = cardHolder;
	}
	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	
}
