package com.ryanwgingrich.budgetButler.io.csvToBean;

import com.opencsv.bean.CsvBindByPosition;

public class ChaseTransaction {

	public ChaseTransaction() {
	}

	@CsvBindByPosition(required = true, position = 1)
	private String date;

	@CsvBindByPosition(required = false, position = 3)
	private String description;

	@CsvBindByPosition(required = false, position = 0)
	private String type;

	@CsvBindByPosition(required = false, position = 4)
	private String transactionAmount;
	
	//private String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDate() {
		return date;
	}

	public String getDescription() {
		return description;
	}

//	public String getCardHolder() {
//		return cardHolder;
//	}

	public String getTransactionAmount() {
		return transactionAmount;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public void setDescription(String description) {
		this.description = description;
	}

//	public void setCardHolder(String cardHolder) {
//		this.cardHolder = cardHolder;
//	}

	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount.replaceAll("-", "") ;
	}

}
