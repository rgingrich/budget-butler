package com.ryanwgingrich.budgetButler.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.persistence.NoResultException;

import org.hibernate.Session;

import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.dto.db.TransactionDescriptor;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.EnumLookupUtil;
import com.ryanwgingrich.budgetButler.enums.TransactionType;
import com.ryanwgingrich.budgetButler.parser.FileService;
import com.ryanwgingrich.budgetButler.service.DBService;

public class TransactionController {

	public TransactionController() {

	}

	public void categorize(Transaction t) throws IOException {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		BucketCategory bucketCategory = null;
		// private static SimpleDateFormat sdfAmex = new SimpleDateFormat("yyyy-MM-dd");

		String descriptorString = t.getDescription().toUpperCase().replaceAll("[^A-Za-z]", "")
				.replaceAll("PAYPAL *", "").replaceAll("SAMPAY", "").replaceAll("THE", "")
				.replaceAll("SARATOGASPRI", "").replaceAll("SARATOGASPRINGS", "").replaceAll("SARATOGASPGS", "")
				.replaceAll("ALBANY", "").replaceAll("LATHAM", "").replaceAll("LATHAM", "").replaceAll("MALTA", "")
				.replaceAll("CLIFTONPARK", "").replaceAll("SCOTIA", "").replaceAll("GLENMONT", "")
				.replaceAll("GLENMONT", "").replaceAll("SCHENECTADY", "").replaceAll("BURLINGTON", "")
				.replaceAll("ALBANY", "").replaceAll("MANCHESTER", "").replaceAll("MENANDS", "")
				.replaceAll("SPRINGFIELDMA", "").replaceAll("BALLSTONLAKE", "").replaceAll("GLENVILLE", "")
				.replaceAll("GLENVILLE", "").replaceAll("SCOTIA", "").replaceAll("GREENWICH", "")
				.replaceAll("BALLSTONSPA", "").replaceAll("WILTON", "").replaceAll("LOUDONVILLE", "")
				.replaceAll("HALFMOON", "").replaceAll("PLATTSBURGH", "").replaceAll("GANSEVOORT", "")
				.replaceAll("LAKEGEORGE", "").replaceAll("NY", "").replaceAll("NEWYORK", "").replaceAll("VT", "")
				.replaceAll("COLUMBUS", "").replaceAll("MENANDS", "").replaceAll("CASTLETON", "");

		if (t.getType().equals(TransactionType.TRANSFER)) {
			bucketCategory = BucketCategory.NONE;
		} else if (t.getType().equals(TransactionType.ATM)) {
			bucketCategory = BucketCategory.CASH;
		} else if (t.getType().equals(TransactionType.RETURN) || t.getType().equals(TransactionType.ATMREBATE)
				|| t.getType().equals(TransactionType.INTADJUST) || t.getType().equals(TransactionType.DEPOSIT)
				|| descriptorString.contains("REGSALARY") || descriptorString.contains("NEWYORKSTATEDIRDEP")) {
			bucketCategory = BucketCategory.INCOME;
		} else if (t.getType().equals(TransactionType.CHECK)
				&& (t.getTransactionAmt().compareTo(BigDecimal.valueOf(1000.00)) == 0
						|| t.getTransactionAmt().compareTo(BigDecimal.valueOf(1010.00)) == 0
						|| t.getTransactionAmt().compareTo(BigDecimal.valueOf(995.00)) == 0)) {
			bucketCategory = BucketCategory.RENT;
		} else if (descriptorString.contains("MCDONALDS") || descriptorString.contains("STARBUCKS")
				|| descriptorString.contains("PRICECHOPPER") || descriptorString.contains("DUNKIN")
				|| descriptorString.contains("MARKETBYPRICE") || descriptorString.contains("DAIRYCIRCUS")
				|| descriptorString.contains("HANNAFORD") || descriptorString.contains("SMASHBURGER")
				|| descriptorString.contains("BURGERKING") || descriptorString.contains("FRESHMARKET")
				|| descriptorString.contains("SHAKESHACK") || descriptorString.contains("SUBWAY")
				|| descriptorString.contains("BURGERFI") || descriptorString.contains("REDROBIN")
				|| descriptorString.contains("TIPSYMOOSE") || descriptorString.contains("GREATTANG")
				|| descriptorString.contains("ESPRESSO") || descriptorString.contains("COFFEE")
				|| descriptorString.contains("MEXICANCONNECTION") || descriptorString.contains("THIRSTYOWL")
				|| descriptorString.contains("BUTCHER") || descriptorString.contains("BEVERAGE")) {
			bucketCategory = BucketCategory.FOOD;
		} else if (descriptorString.contains("AMAZON") || descriptorString.contains("WOOT")) {
			bucketCategory = BucketCategory.AMAZON;
		} else if (descriptorString.contains("ULTA") || descriptorString.contains("SEPHORACOM")
				|| descriptorString.contains("SEPHORA") || descriptorString.contains("SEPHORAUSA")
				|| descriptorString.contains("KELLEYKINDL")) {
			bucketCategory = BucketCategory.BEAUTY;
		} else if (descriptorString.contains("PET") || descriptorString.contains("VETERINARY")) {
			bucketCategory = BucketCategory.PET;
		} else if (descriptorString.contains("HULUCOM") || descriptorString.contains("NETFLIXCOM")
				|| descriptorString.contains("HBO") || descriptorString.contains("SLINGTV")) {
			bucketCategory = BucketCategory.SUBSCRIPTIONS;
		} else if (descriptorString.contains("MOHRS") || descriptorString.contains("PARKING")
				|| descriptorString.contains("SUNOCOPUMP") || descriptorString.contains("CARWASH")) {
			bucketCategory = BucketCategory.CAR;
		} else if (descriptorString.contains("TIMEWARNERCABLE")) {
			bucketCategory = BucketCategory.INTERNET;
		} else if (descriptorString.contains("TAX")) {
			bucketCategory = BucketCategory.TAX;
		}

		if (bucketCategory == null) {

			try {
				bucketCategory = (BucketCategory) DBService.getInstance().getSession()
						.getNamedQuery("DescriptorBucketLookup")
						.setParameter("descriptor", descriptorString + t.getType()).getSingleResult();
			} catch (NoResultException nre) {
				// Ignore this because as per your logic this is ok!
				if (bucketCategory == null) {

					System.out.println(sdf.format(t.getDate().getTime()) + " : " + t.getDescription() + " : "
							+ t.getTransactionAmt() + " : " + t.getType());
					System.out.println("Please enter category: ");

					BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

					while (bucketCategory == null) {

						bucketCategory = EnumLookupUtil.lookup(BucketCategory.class, br.readLine());

					}

					////////////////////////////////////////////
					// SAVE DESCRIPTOR TO DATABASE
					TransactionDescriptor transactionDescriptor = new TransactionDescriptor(
							descriptorString + t.getType(), bucketCategory);
					DBService.getInstance().save(transactionDescriptor);
				}
			}

		}
		t.setCategory(bucketCategory);
	}
	
	public  Calendar getMinDate() {

		Session dbSession = DBService.getInstance().getSession();

		Calendar minDate = (Calendar) dbSession.getNamedQuery("Transactions.minDate").getSingleResult();
		return minDate;

	}

	public  Calendar getMaxDate() {

		Session dbSession = DBService.getInstance().getSession();

		Calendar maxDate = (Calendar) dbSession.getNamedQuery("Transactions.maxDate").getSingleResult();
		return maxDate;

	}

	public void initialize(int budgetMonth, int budgetYear) {
		FileService fileService = new FileService();
	
	}

}
