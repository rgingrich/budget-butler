package com.ryanwgingrich.budgetButler.parser;

import java.io.FileNotFoundException;
import java.util.List;

public class AmexParser implements Parser {

	@Override
	public List<?> getTransactionList(String fileName) throws FileNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

}
