package com.ryanwgingrich.budgetButler.parser;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.math.BigDecimal;
import java.util.List;
import java.util.ListIterator;

import org.hibernate.Session;

import com.opencsv.bean.CsvToBeanBuilder;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.enums.TransactionType;
import com.ryanwgingrich.budgetButler.io.csvToBean.AmexTransaction;
import com.ryanwgingrich.budgetButler.io.csvToBean.SchwabTransaction;

public class AmexParser implements Parser {

	@Override
	public List<?> getRecordList(String fileName) throws FileNotFoundException {
		FileReader fileReader = new FileReader(fileName);

		
		CsvToBeanBuilder csvToBeanBuilder = new CsvToBeanBuilder<AmexTransaction>(fileReader)
				.withType(AmexTransaction.class);
		
	    List<AmexTransaction> amexTransactions = csvToBeanBuilder.build().parse();

	   	return amexTransactions;
	}

	@Override
	public void parseToDB(String fileName, Session session) throws FileNotFoundException {
		//getTransactionList();
		session.beginTransaction();
		
		List<AmexTransaction> amexTransactions = (List<AmexTransaction>) getRecordList(fileName);

		for (AmexTransaction amexTransaction : amexTransactions) {

			session.save(new Transaction(amexTransaction.getDate(), amexTransaction.getDescription(), amexTransaction.getCardHolder(), new BigDecimal(amexTransaction.getTransactionAmount()),TransactionType.AMEX));
		}
		amexTransactions.removeAll(amexTransactions);
		session.getTransaction().commit();
	}


}
