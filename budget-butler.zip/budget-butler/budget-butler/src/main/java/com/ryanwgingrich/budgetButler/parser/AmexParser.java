package com.ryanwgingrich.budgetButler.parser;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.List;
import java.util.ListIterator;

import org.hibernate.Session;

import com.opencsv.bean.CsvToBeanBuilder;
import com.ryanwgingrich.budgetButler.dto.csv.AmexTransaction;
import com.ryanwgingrich.budgetButler.dto.csv.SchwabTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BBTransaction;

public class AmexParser implements Parser {

	@Override
	public List<?> getTransactionList(String fileName) throws FileNotFoundException {
		FileReader fileReader = new FileReader(fileName);

		
		CsvToBeanBuilder csvToBeanBuilder = new CsvToBeanBuilder<AmexTransaction>(fileReader)
				.withType(AmexTransaction.class);
		
	    List<AmexTransaction> amexTransactions = csvToBeanBuilder.build().parse();

	   	return amexTransactions;
	}

	@Override
	public void parseToDB(String fileName, Session session) throws FileNotFoundException {
		//getTransactionList();
		session.beginTransaction();
		
		List<AmexTransaction> amexTransactions = (List<AmexTransaction>) getTransactionList(fileName);

		for (AmexTransaction amexTransaction : amexTransactions) {

			session.save(new BBTransaction(amexTransaction.getDate(), amexTransaction.getDescription(), amexTransaction.getCardHolder(), amexTransaction.getTransactionAmount()));
		}
		amexTransactions.removeAll(amexTransactions);
		session.getTransaction().commit();
	}


}
