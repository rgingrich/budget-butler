package com.ryanwgingrich.budgetButler.enums;

public enum BucketCategory {
	FOOD,
	GAS,
	INCOME,
	OTHER,
	PHONE,
	RENT
}
