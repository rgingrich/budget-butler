package com.ryanwgingrich.budgetButler.enums;

public enum BucketCategory {
	APT_INS,
	BEAUTY,
	CAR,
	CAR_INS,
	CASH,
	CREDIT_CARD,
	DISABILITY_INS,
	FOOD,
	GAS,
	HOME_IMPROVEMENT,
	INCOME,
	NATL_GRID,
	NONE,
	OTHER,
	PARKING,
	PHONE,
	RENT,
	TRANSFER
}
