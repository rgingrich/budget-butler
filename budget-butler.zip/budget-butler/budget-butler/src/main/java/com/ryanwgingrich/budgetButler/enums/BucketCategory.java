package com.ryanwgingrich.budgetButler.enums;

public enum BucketCategory {
	AMAZON,
	APT_INS,
	BEAUTY,
	BUFFER,
	CAR,
	CAR_INS,
	CASH,
	CREDIT_CARD,
	DISABILITY_INS,
	ENTERTAINMENT,
	FOOD,
	GAS,
	HEALTH,
	HOME,
	INCOME,
	INTERNET,
	NONE,
	OTHER,
	PARKING,
	PET,
	PHONE,
	RENT,
	TAX,
	UTILITIES

}
