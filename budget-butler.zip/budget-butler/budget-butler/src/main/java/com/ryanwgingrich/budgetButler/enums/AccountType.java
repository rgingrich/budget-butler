package com.ryanwgingrich.budgetButler.enums;

public enum AccountType {
	DESCRIPTOR,
	SCHWAB_BANK,
	AMEX_CREDIT,
	U_FIRST,
	CITI_BANK, 
	CHASE_CREDIT
}
