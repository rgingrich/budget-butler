package com.ryanwgingrich.budgetButler.enums;

public enum AccountType {
	//DESCRIPTOR,
	SCHWAB_CASH,
	AMEX_CREDIT,
	UFIRST_CREDIT,
	CITI_CREDIT, 
	CHASE_CREDIT
}
