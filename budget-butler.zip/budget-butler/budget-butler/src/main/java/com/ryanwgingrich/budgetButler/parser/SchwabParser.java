package com.ryanwgingrich.budgetButler.parser;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.List;

import com.opencsv.bean.CsvToBeanBuilder;
import com.ryanwgingrich.budgetButler.dto.csv.SchwabTransaction;

public class SchwabParser implements Parser {

	@Override
	public List<?> getTransactionList(String fileName) throws FileNotFoundException {
		FileReader fileReader = new FileReader(fileName);

		CsvToBeanBuilder csvToBeanBuilder = new CsvToBeanBuilder<SchwabTransaction>(fileReader)
				.withType(SchwabTransaction.class)
				.withSkipLines(1);

		List<SchwabTransaction> schwabTransactions = csvToBeanBuilder.build().parse();

		return schwabTransactions;
	}

}
