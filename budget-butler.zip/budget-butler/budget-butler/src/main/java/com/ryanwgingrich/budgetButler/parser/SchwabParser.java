package com.ryanwgingrich.budgetButler.parser;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.hibernate.Session;

import com.opencsv.bean.ColumnPositionMappingStrategy;
import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.CsvToBeanFilter;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;
import com.ryanwgingrich.budgetButler.io.csvToBean.SchwabTransaction;

public class SchwabParser implements Parser {

	@Override
	public List<SchwabTransaction> getRecordList(String fileName) throws FileNotFoundException {
		FileReader fileReader = new FileReader(fileName);

		CsvToBeanBuilder<SchwabTransaction> csvToBeanBuilder = new CsvToBeanBuilder<SchwabTransaction>(fileReader)
				.withType(SchwabTransaction.class).withSkipLines(1);

		List<SchwabTransaction> schwabTransactions = (List<SchwabTransaction>) csvToBeanBuilder.build().parse();

		ListIterator<SchwabTransaction> schwabIterator = schwabTransactions.listIterator();

		SchwabTransaction schwabTransaction;
		while (schwabIterator.hasNext()) {
			schwabTransaction = (SchwabTransaction) schwabIterator.next();
			if (schwabTransaction.getDate().equalsIgnoreCase("Posted Transactions")) {
				schwabIterator.remove();
			}
			else if (schwabTransaction.getDate().equalsIgnoreCase("Pending Transactions")) {
				schwabIterator.remove();
			}
			else if(schwabTransaction.getDate().equalsIgnoreCase("Total Pending Check and other Credit(s)")) {
				schwabIterator.remove();
			}
			
			if(schwabTransaction.getType() == null) {
				schwabTransaction.setType(TransactionType.PENDING.toString());
				
			}
		}

		return schwabTransactions;
	}

	@Override
	public void parseToDB(String fileName, Session session) throws FileNotFoundException {

		session.beginTransaction();
		String transactionAmt;
		List<SchwabTransaction> schwabTransactions = (List<SchwabTransaction>) getRecordList(fileName);

		for (SchwabTransaction schwabTransaction : schwabTransactions) {

			if (schwabTransaction.getDeposit() != null) {

				transactionAmt = schwabTransaction.getDeposit();

			} else if (schwabTransaction.getWithdrawal() != "") {

				transactionAmt = schwabTransaction.getWithdrawal();

			} else
				transactionAmt = "";

			session.save(new Transaction(schwabTransaction.getDate(), schwabTransaction.getType(),
					schwabTransaction.getCheckNum(), schwabTransaction.getDescription(),
					schwabTransaction.getRunningBalance(), transactionAmt));

		}

		session.getTransaction().commit();
		
	}

}
