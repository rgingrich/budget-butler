package com.ryanwgingrich.budgetButler.parser;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import com.opencsv.bean.ColumnPositionMappingStrategy;
import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.CsvToBeanFilter;
import com.ryanwgingrich.budgetButler.dto.csv.SchwabTransaction;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

public class SchwabParser implements Parser {

	@Override
	public List<?> getTransactionList(String fileName) throws FileNotFoundException {
		FileReader fileReader = new FileReader(fileName);

		
		CsvToBeanBuilder csvToBeanBuilder = new CsvToBeanBuilder<SchwabTransaction>(fileReader)
				.withType(SchwabTransaction.class)
				.withSkipLines(1);
		
	    List<SchwabTransaction> schwabTransactions = csvToBeanBuilder.build().parse();
	    
	    //for (SchwabTransaction schwabTransaction : schwabTransactions) {
	    //Integer idxToRemove = 0;
	    ListIterator<SchwabTransaction> schwabIterator = schwabTransactions.listIterator();
	    
	    while (schwabIterator.hasNext()) {	
	    	if(((SchwabTransaction) schwabIterator.next()).getDate().equalsIgnoreCase("Posted Transactions")) {
	    		schwabIterator.remove();
	    	}
	    }
	    
		
		
		return schwabTransactions;
	}

}
