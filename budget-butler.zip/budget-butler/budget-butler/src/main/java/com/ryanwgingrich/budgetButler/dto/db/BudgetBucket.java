package com.ryanwgingrich.budgetButler.dto.db;



import java.math.BigDecimal;


import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import com.ryanwgingrich.budgetButler.enums.BucketCategory;

@Entity
@Embeddable
public class BudgetBucket {
	
	
	//@Id @GeneratedValue
	//private int id;
	@Id
	private BucketCategory category;
	private BigDecimal appropAmt;
	private BigDecimal remainingAmt;
	
	
	
	public BudgetBucket() {
		
	}
	public BudgetBucket(BucketCategory category, BigDecimal appropAmt) {
		
		//this.id = id;
		this.category = category;
		this.appropAmt = appropAmt;
		this.remainingAmt = appropAmt;
		
	}
	
	/*public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}*/
	
	
	public BucketCategory getCategory() {
		return category;
	}
	public void setCategory(BucketCategory category) {
		this.category = category;
	}
	public BigDecimal getAppropAmt() {
		return appropAmt;
	}
	public BigDecimal getRemainingAmt() {
		return remainingAmt;
	}
	public void setAppropAmt(BigDecimal appropAmt) {
		this.appropAmt = appropAmt;
	}
	public void setRemainingAmt(BigDecimal remainingAmt) {
		this.remainingAmt = remainingAmt;
	}
	
}
