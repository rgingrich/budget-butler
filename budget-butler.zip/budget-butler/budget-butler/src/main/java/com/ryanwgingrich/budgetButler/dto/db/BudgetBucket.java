package com.ryanwgingrich.budgetButler.dto.db;

import java.math.BigDecimal;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.CollectionId;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.NamedQuery;

import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.service.BucketService;
import com.ryanwgingrich.budgetButler.service.TransactionService;

@NamedQuery(name = "BudgetBuckets", query = "FROM BudgetBucket")

@NamedQuery(name = "DeleteBudgetBuckets", query = "delete BudgetBucket")

@NamedQuery(name = "DeleteBucketById", query = "delete BudgetBucket where id = :id")

@Entity
@Embeddable
public class BudgetBucket {

	// @Id @GeneratedValue
	// private int id;
	@Id
	private int id;
	private BucketCategory category;
	private BigDecimal appropiationAmt;

	private BigDecimal cashCreditAmt;
	private BigDecimal cashExpenditureAmt;

	private BigDecimal creditExpenditureAmt;

	@ElementCollection
	//@ManyToOne(targetEntity = Transaction.class)
	private Collection<Transaction> transactionList = new ArrayList<Transaction>();

	public BudgetBucket() {

	}

	public BudgetBucket(int year, int month, BucketCategory category) {

		this.id = Integer.valueOf(
				String.valueOf(year) + String.format("%02d", month) + String.format("%02d", category.ordinal()));
		this.category = category;

		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public BucketCategory getCategory() {
		return category;
	}

	public void setCategory(BucketCategory category) {
		this.category = category;
	}

	public BigDecimal getAppropiationAmt() {
		return appropiationAmt;
	}

	public void setAppropiationAmt(BigDecimal appropiationAmt) {
		this.appropiationAmt = appropiationAmt;
	}

	public BigDecimal getCashCreditAmt() {
		return cashCreditAmt;
	}

	public void setCashCreditAmt(BigDecimal cashCreditAmt) {
		this.cashCreditAmt = cashCreditAmt;
	}

	public BigDecimal getCashExpenditureAmt() {
		return cashExpenditureAmt;
	}

	public void setCashExpenditureAmt(BigDecimal cashExpenditureAmt) {
		this.cashExpenditureAmt = cashExpenditureAmt;
	}

	public BigDecimal getCreditExpenditureAmt() {
		return creditExpenditureAmt;
	}

	public void setCreditExpenditureAmt(BigDecimal creditExpenditureAmt) {
		this.creditExpenditureAmt = creditExpenditureAmt;
	}

	public Collection<Transaction> getTransactionList() {
		return transactionList;
	}

	public void setTransactionList(Collection<Transaction> transactionList) {
		this.transactionList = transactionList;
	}

	

}
