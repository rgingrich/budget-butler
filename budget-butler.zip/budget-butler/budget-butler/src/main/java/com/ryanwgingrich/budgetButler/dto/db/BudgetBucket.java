package com.ryanwgingrich.budgetButler.dto.db;

import java.math.BigDecimal;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

import org.hibernate.annotations.CollectionId;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.NamedQuery;

import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.service.TransactionService;

@NamedQuery(name = "BudgetBuckets", query = "FROM BudgetBucket")

@NamedQuery(name = "DeleteBudgetBuckets", query = "delete BudgetBucket")

@Entity
@Embeddable
public class BudgetBucket {

	// @Id @GeneratedValue
	// private int id;
	@Id
	private int id;
	private BucketCategory category;
	private BigDecimal appropAmt;
	private BigDecimal creditAmt;
	private BigDecimal debitAmt;

	@ElementCollection(fetch = FetchType.EAGER)
	private Collection<Transaction> transactionList = new ArrayList<Transaction>();

	public BudgetBucket() {

	}

	public BudgetBucket(int year, int month, BucketCategory category) {

		this.category = category;
		this.id = Integer.valueOf(String.valueOf(year) + String.format("%02d", month) + String.valueOf(category.ordinal()));
		
		//TODO: set Transaction List
		//List<Transaction> transactionList = new ArrayList<Transaction>();
		
		
		this.transactionList = TransactionService.getTransactionsByYearMonth(year, month, category);
	}

	public BucketCategory getCategory() {
		return category;
	}

	public void setCategory(BucketCategory category) {
		this.category = category;
	}

	public BigDecimal getAppropAmt() {
		return appropAmt;
	}

	public void setAppropAmt(BigDecimal appropAmt) {
		this.appropAmt = appropAmt;
	}

	public BigDecimal getCreditAmt() {
		return creditAmt;
	}

	public void setCreditAmt(BigDecimal creditAmt) {
		this.creditAmt = creditAmt;
	}

	public BigDecimal getDebitAmt() {
		return debitAmt;
	}

	public void setDebitAmt(BigDecimal debitAmt) {
		this.debitAmt = debitAmt;
	}

	public Collection<Transaction> getTransactionList() {
		return transactionList;
	}

	public void setTransactionList(Collection<Transaction> transactionList) {
		this.transactionList = transactionList;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
