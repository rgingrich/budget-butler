package com.ryanwgingrich.budgetButler.dto.db;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import com.ryanwgingrich.budgetButler.enums.BucketCategory;

@Entity
@Embeddable
public class BudgetBucket {

	// @Id @GeneratedValue
	// private int id;
	@Id
	private BucketCategory category;
	private BigDecimal appropAmt;
	private BigDecimal remainingAmt;
	private BigDecimal totalAmt;
	// private List<Transaction> transactionList;
	@ElementCollection
	private Collection<Transaction> transactionList = new ArrayList<Transaction>();

	public BudgetBucket() {

	}

	public BudgetBucket(BucketCategory category, BigDecimal appropAmt) {

		this.category = category;
		this.appropAmt = appropAmt;
		this.remainingAmt = appropAmt;

	}

	public BucketCategory getCategory() {
		return category;
	}

	public void setCategory(BucketCategory category) {
		this.category = category;
	}

	public BigDecimal getAppropAmt() {
		return appropAmt;
	}

	public BigDecimal getRemainingAmt() {
		return remainingAmt;
	}

	public void setAppropAmt(BigDecimal appropAmt) {
		this.appropAmt = appropAmt;
	}

	public void setRemainingAmt(BigDecimal remainingAmt) {
		this.remainingAmt = remainingAmt;
	}

	public Collection<Transaction> getTransactionList() {
		return transactionList;
	}

	public void setTransactionList(Collection<Transaction> transactionList) {
		this.transactionList = transactionList;
	}

	public BigDecimal getTotalAmt() {
		return totalAmt;
	}

	public void setTotalAmt(BigDecimal totalAmt) {
		this.totalAmt = totalAmt;
	}
	

}
