package com.ryanwgingrich.budgetButler.dto.db;

import java.math.BigDecimal;




import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.NamedQuery;

import com.ryanwgingrich.budgetButler.enums.BucketCategory;

@NamedQuery(name = "BudgetBuckets", query = "FROM BudgetBucket")

@NamedQuery(name = "DeleteBudgetBuckets", query = "delete BudgetBucket")

@Entity
@Embeddable
public class BudgetBucket {

	// @Id @GeneratedValue
	// private int id;
	@Id
	private BucketCategory category;
	private BigDecimal appropAmt;
	private BigDecimal remainingAmt;
	private BigDecimal limitAmt;
	// private List<Transaction> transactionList;
	@ElementCollection
	private Collection<Transaction> transactionList = new ArrayList<Transaction>();

	public BudgetBucket() {

	}

	public BudgetBucket(BucketCategory category, BigDecimal appropAmt, BigDecimal limitAmt) {

		this.category = category;
		this.appropAmt = appropAmt;
		this.remainingAmt = appropAmt;
		this.limitAmt = limitAmt;

	}

	public BucketCategory getCategory() {
		return category;
	}

	public void setCategory(BucketCategory category) {
		this.category = category;
	}

	public BigDecimal getAppropAmt() {
		return appropAmt;
	}

	public BigDecimal getRemainingAmt() {
		return remainingAmt;
	}

	public void setAppropAmt(BigDecimal appropAmt) {
		this.appropAmt = appropAmt;
	}

	public void setRemainingAmt(BigDecimal remainingAmt) {
		this.remainingAmt = remainingAmt;
	}

	public Collection<Transaction> getTransactionList() {
		return transactionList;
	}

	public void setTransactionList(Collection<Transaction> transactionList) {
		this.transactionList = transactionList;
	}

	public BigDecimal getLimitAmt() {
		return limitAmt;
	}

	public void setLimitAmt(BigDecimal totalAmt) {
		this.limitAmt = limitAmt;
	}
	

}
