package com.ryanwgingrich.budgetButler.dto.db;



import java.math.BigDecimal;


import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import com.ryanwgingrich.budgetButler.enums.BucketCategory;

@Entity
@Embeddable
public class BudgetBucket {
	
	
	//@Id @GeneratedValue
	//private int id;
	@Id
	private BucketCategory category;
	private BigDecimal appropAmt;
	private BigDecimal remainingAmt;
	private boolean isReadyForCheck;
	private boolean isCheckCleared;
	private boolean isBillPaid;
	
	
	
	

	public BudgetBucket() {
		
	}
	public BudgetBucket(BucketCategory category, BigDecimal appropAmt) {
		
		this.category = category;
		this.appropAmt = appropAmt;
		this.remainingAmt = appropAmt;
		this.isReadyForCheck = false;
		this.isCheckCleared = false;
		this.isBillPaid = false;
		
	}
	

	
	
	public boolean isBillPaid() {
		return isBillPaid;
	}
	public void setBillPaid(boolean isBillPaid) {
		this.isBillPaid = isBillPaid;
	}
	public boolean isCheckCleared() {
		return isCheckCleared;
	}
	public void setCheckCleared(boolean hasCheckCleared) {
		this.isCheckCleared = hasCheckCleared;
	}
	public boolean isReadyForCheck() {
		return isReadyForCheck;
	}
	public void setReadyForCheck(boolean isReadyForCheck) {
		this.isReadyForCheck = isReadyForCheck;
	}
	public BucketCategory getCategory() {
		return category;
	}
	public void setCategory(BucketCategory category) {
		this.category = category;
	}
	public BigDecimal getAppropAmt() {
		return appropAmt;
	}
	public BigDecimal getRemainingAmt() {
		return remainingAmt;
	}
	public void setAppropAmt(BigDecimal appropAmt) {
		this.appropAmt = appropAmt;
	}
	public void setRemainingAmt(BigDecimal remainingAmt) {
		this.remainingAmt = remainingAmt;
	}
	
}
