package com.ryanwgingrich.budgetButler.parser;

public class TransactionDescriptorController {

}
