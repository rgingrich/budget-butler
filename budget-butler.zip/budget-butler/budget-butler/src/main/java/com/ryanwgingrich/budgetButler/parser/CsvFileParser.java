package com.ryanwgingrich.budgetButler.parser;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.List;

import com.opencsv.bean.CsvToBeanBuilder;
import com.ryanwgingrich.budgetButler.io.csvToBean.CsvTransactionDescriptor;

public abstract class CsvFileParser {

	public abstract List<?> getItems(String fileName, Class itemClass) throws FileNotFoundException;

}
