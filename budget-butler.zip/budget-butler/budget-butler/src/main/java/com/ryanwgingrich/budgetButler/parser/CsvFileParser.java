package com.ryanwgingrich.budgetButler.parser;

import java.io.FileNotFoundException;
import java.util.List;

public abstract class CsvFileParser {

	public abstract List<?> getItems(String fileName, Class itemClass) throws FileNotFoundException;

}
