package com.ryanwgingrich.budgetButler.dto.csv;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.opencsv.bean.CsvBindByName;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

public class SchwabTransactionDescriptor {

	public SchwabTransactionDescriptor() {
	}

	@CsvBindByName(column = "descriptor", required = true)
	private String descriptor;
	@CsvBindByName(column = "budgetBucket", required = true)
	private String budgetBucket;
	

	public String getDescriptor() {
		return descriptor;
	}

	public String getBudgetBucket() {
		return budgetBucket;
	}

	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}

	public void setBudgetBucket(String BudgetBucket) {

		this.budgetBucket = BudgetBucket;
	}

}
