package com.ryanwgingrich.budgetButler.dto.db;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.annotations.NamedQuery;

import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

@NamedQuery(name = "SumTransactions.byCategoryYearMonth", query = "SELECT SUM(" + "case "
		+ "when type in (9) and transactionAmt < 0 "// TransactionType.AMEX(9)
		+ "then abs(transactionAmt) " + "else transactionAmt end) " + "FROM Transaction "
		+ "where category = :category and YEAR(date) = :year and MONTH(date) = :month +1")

@NamedQuery(name = "SumTransactions.byCategoryYear", query = "SELECT SUM(" + "case "
		+ "when type in (9) and transactionAmt < 0 "// TransactionType.AMEX(9)
		+ "then abs(transactionAmt) " + "else transactionAmt end) " + "FROM Transaction "
		+ "where category = :category and YEAR(date) = :year")

@NamedQuery(name = "Transactions.byCategoryYearMonth", query = "FROM Transaction "
		+ "where category = :category and YEAR(date) = :year and MONTH(date) = :month +1")

@NamedQuery(name = "Transactions.byYearMonth", query = "FROM Transaction "
		+ "where YEAR(date) = :year and MONTH(date) = :month +1")

@NamedQuery(name = "MonthEndBalance.byYearMonth", query = "SELECT runningBal FROM Transaction where id in (select min(id) from Transaction WHERE runningBal IS NOT NULL and YEAR(date) = :year and MONTH(date) = :month +1)")

@NamedQuery(name = "Transactions", query = "FROM Transaction")

@NamedQuery(name = "DeleteCurrentTransactions", query = "delete Transaction where MONTH(date) = :month+1 and YEAR(date) = :year")

@Entity
@Embeddable
public class Transaction {
	static Logger logger = LogManager.getLogger(Transaction.class.getName());

	// DateFormat format = new SimpleDateFormat("mm/dd/yyyy", Locale.ENGLISH);
	String DATE_FORMAT = "MM/dd/yyyy";
	SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);

	@Id
	@GeneratedValue
	private int id;
	private Date date;
	private TransactionType type;
	private int checkNum;
	private String description;
	private BigDecimal runningBal;
	private String cardHolder;
	private BigDecimal transactionAmt;
	private BucketCategory category;

	public Transaction() {
	}

	public Transaction(String date2, String description2, String cardHolder, BigDecimal transactionAmt,
			TransactionType type2) {
		// TODO Auto-generated constructor stub
		try {
			this.date = sdf.parse(date2);

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.description = description2;
		this.cardHolder = cardHolder;
		this.transactionAmt = transactionAmt;
		this.type = type2;

	}

	public Transaction(String date2, String type2, int checkNum2, String description2, String runningBalance,
			String transactionAmt2) {
		try {
			this.date = sdf.parse(date2);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.type = TransactionType.valueOf(type2);
		this.description = description2;
		this.checkNum = checkNum2;
		this.runningBal = new BigDecimal((runningBalance == null) ? "0.00" : runningBalance.replaceAll("[^0-9.]", ""));
		this.transactionAmt = new BigDecimal(
				(transactionAmt2 == null) ? "0.00" : transactionAmt2.replaceAll("[^0-9.]", ""));

	}

	public Transaction(String date2, String type2, String description2, String cardHolder2, String transactionAmount2) {
		try {
			this.date = sdf.parse(date2);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.type = TransactionType.valueOf(type2);
		this.description = description2;
		this.cardHolder = cardHolder2;
		this.transactionAmt = new BigDecimal(
				(transactionAmount2 == null) ? "0.00" : transactionAmount2.replaceAll("[^0-9.]", ""));
	}

	public Transaction(String date2, String type2, String description2, String cardHolder2, String transactionAmount2,
			BucketCategory category) {
		try {
			this.date = sdf.parse(date2);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.type = TransactionType.valueOf(type2);
		this.description = description2;
		this.cardHolder = cardHolder2;
		this.transactionAmt = new BigDecimal(
				(transactionAmount2 == null) ? "0.00" : transactionAmount2.replaceAll("[^0-9.]", ""));
		this.category = category;
	}

	public Transaction(String date2, String type2, String description2, String transactionAmount2) {
		try {
			this.date = sdf.parse(date2);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.type = TransactionType.valueOf(type2.toUpperCase());
		this.description = description2;
		this.transactionAmt = new BigDecimal(
				(transactionAmount2 == null) ? "0.00" : transactionAmount2.replaceAll("[^0-9.]", ""));
	}

	public int getId() {
		return id;
	}

	public TransactionType getType() {
		return type;
	}

	public int getCheckNum() {
		return checkNum;
	}

	public String getDescription() {
		return description;
	}

	public BigDecimal getRunningBal() {
		return runningBal;
	}

	public String getCardHolder() {
		return cardHolder;
	}

	public BigDecimal getTransactionAmt() {
		return transactionAmt;
	}

	public BucketCategory getCategory() {
		return category;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setType(TransactionType type) {
		this.type = type;
	}

	public void setCheckNum(int checkNum) {
		this.checkNum = checkNum;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setRunningBal(BigDecimal runningBal) {
		this.runningBal = runningBal;
	}

	public void setCardHolder(String cardHolder) {
		this.cardHolder = cardHolder;
	}

	public void setTransactionAmt(BigDecimal transactionAmt) {
		this.transactionAmt = transactionAmt;
	}

	public void setCategory(BucketCategory category) {
		this.category = category;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(String date) throws ParseException {
		this.date = sdf.parse(date);
	}

}
