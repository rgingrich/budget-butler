package com.ryanwgingrich.budgetButler.dto.db;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.annotations.NamedQuery;

import com.ryanwgingrich.budgetButler.enums.AccountType;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

@NamedQuery(name = "Transactions.minDate", query = "SELECT MIN(date) FROM Transaction")

@NamedQuery(name = "Transactions.maxDate", query = "SELECT MAX(date) FROM Transaction")

//Query used in: 
@NamedQuery(name = "Transactions.byYearMonth", query = "FROM Transaction "
		+ "where YEAR(date) = :year and MONTH(date) = :month ORDER BY DATE ASC")

@NamedQuery(name = "Transactions.byYearMonthCategory", query = "FROM Transaction "
		+ "where YEAR(date) = :year and MONTH(date) = :month and category = :category ORDER BY DATE ASC")

//Query used in: TransactionService.transactionReport(int, int)
@NamedQuery(name = "Transactions", query = "FROM Transaction ORDER BY DATE ASC" + "")

//Query used in: 
@NamedQuery(name = "SumTransactions.byCategoryYearMonth", query = "SELECT SUM(" + "case "
		+ "when type in (9) and transactionAmt < 0 "// TransactionType.AMEX(9)
		+ "then abs(transactionAmt) " + "else transactionAmt end) " + "FROM Transaction "
		+ "where category = :category and YEAR(date) = :year and MONTH(date) = :month")

@NamedQuery(name = "SumCashTransactions.byCategoryYearMonth", query = "SELECT SUM(" + "case "
		+ "when type in (9) and transactionAmt < 0 "// TransactionType.AMEX(9)
		+ "then abs(transactionAmt) " + "else transactionAmt end) " + "FROM Transaction "
		+ "where category = :category and YEAR(date) = :year and MONTH(date) = :month and accountType = :accountType")

@NamedQuery(name = "SumCreditTransactions.byCategoryYearMonth", query = "SELECT SUM(" + "case "
		+ "when type in (9) and transactionAmt < 0 "// TransactionType.AMEX(9)
		+ "then abs(transactionAmt) " + "else transactionAmt end) " + "FROM Transaction "
		+ "where category = :category and YEAR(date) = :year and MONTH(date) = :month and accountType <> :accountType")

//Query used in: 
@NamedQuery(name = "SumTransactions.byCategoryYear", query = "SELECT SUM(" + "case "
		+ "when type in (9) and transactionAmt < 0 "// TransactionType.AMEX(9)
		+ "then abs(transactionAmt) " + "else transactionAmt end) " + "FROM Transaction "
		+ "where category = :category and YEAR(date) = :year")

//Query used in: 
@NamedQuery(name = "Transactions.byCategoryYearMonth", query = "FROM Transaction "
		+ "where category = :category and YEAR(date) = :year and MONTH(date) = :month")

//Query used in: 
@NamedQuery(name = "MonthEndBalance.byYearMonth", query = "SELECT runningBal FROM Transaction where id in (select min(id) from Transaction WHERE runningBal IS NOT NULL and YEAR(date) = :year and MONTH(date) = :month +1)")

//Query used in: 
@NamedQuery(name = "DeleteTransactions", query = "delete Transaction")

//Query used in: 
@NamedQuery(name = "DeleteCurrentTransactions", query = "delete Transaction where MONTH(date) = :month and YEAR(date) = :year")

@Entity
@Embeddable
public class Transaction {
	static Logger logger = LogManager.getLogger(Transaction.class.getName());

	// DateFormat format = new SimpleDateFormat("mm/dd/yyyy", Locale.ENGLISH);
	String DATE_FORMAT = "MM/dd/yyyy";
	SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);

	@Id
	@GeneratedValue
	private int id;
	private Calendar date;
	private TransactionType type;
	private int checkNum;
	private String description;
	private BigDecimal runningBal;
	private String cardHolder;
	private BigDecimal transactionAmt;
	private BucketCategory category;
	private AccountType accountType;

	public Transaction() {
	}

	public Transaction(String date, String type, String description, String cardHolder, String transactionAmt,
			AccountType accountType) {
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		// TODO Auto-generated constructor stub
		try {
			Calendar myDate = Calendar.getInstance();
			myDate.setTime(sdf.parse(date));

			this.date = myDate;

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.description = description;
		this.cardHolder = cardHolder;
		this.transactionAmt = new BigDecimal(
				(transactionAmt == null) ? "0.00" : transactionAmt.replaceAll("[^0-9.]", ""));
		
		this.type = TransactionType.valueOf(type);
		this.accountType = accountType;

	}

	public Transaction(String date, String type, int checkNum, String description, String runningBalance,
			String transactionAmt, AccountType accountType) {
		try {
			Calendar myDate = Calendar.getInstance();
			myDate.setTime(sdf.parse(date));

			this.date = myDate;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.type = TransactionType.valueOf(type);
		this.description = description;
		this.checkNum = checkNum;
		this.runningBal = new BigDecimal((runningBalance == null) ? "0.00" : runningBalance.replaceAll("[^0-9.]", ""));
		this.transactionAmt = new BigDecimal(
				(transactionAmt == null) ? "0.00" : transactionAmt.replaceAll("[^0-9.]", ""));

		this.accountType = accountType;

	}

	public Transaction(String date, String type, String description, String transactionAmount,
			AccountType accountType) {
		try {
			Calendar myDate = Calendar.getInstance();
			myDate.setTime(sdf.parse(date));

			this.date = myDate;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.type = TransactionType.valueOf(type.toUpperCase());
		this.description = description;
		this.transactionAmt = new BigDecimal(
				(transactionAmount == null) ? "0.00" : transactionAmount.replaceAll("[^0-9.]", ""));
		this.accountType = accountType;
	}

	public int getId() {
		return id;
	}

	public TransactionType getType() {
		return type;
	}

	public int getCheckNum() {
		return checkNum;
	}

	public String getDescription() {
		return description;
	}

	public BigDecimal getRunningBal() {
		return runningBal;
	}

	public String getCardHolder() {
		return cardHolder;
	}

	public BigDecimal getTransactionAmt() {
		return transactionAmt;
	}

	public BucketCategory getCategory() {
		return category;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setType(TransactionType type) {
		this.type = type;
	}

	public void setCheckNum(int checkNum) {
		this.checkNum = checkNum;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setRunningBal(BigDecimal runningBal) {
		this.runningBal = runningBal;
	}

	public void setCardHolder(String cardHolder) {
		this.cardHolder = cardHolder;
	}

	public void setTransactionAmt(BigDecimal transactionAmt) {
		this.transactionAmt = transactionAmt;
	}

	public void setCategory(BucketCategory category) {
		this.category = category;
	}

	public Calendar getDate() {
		return date;
	}

	public void setDate(String date) throws ParseException {
		Calendar myDate = Calendar.getInstance();
		myDate.setTime(sdf.parse(date));

		this.date = myDate;
	}

	public AccountType getAccountType() {
		return accountType;
	}

	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}

}
