/**
 * 
 */
package com.ryanwgingrich.budgetButler.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.List;

import org.hibernate.Session;

import com.ryanwgingrich.budgetButler.dto.db.Account;
import com.ryanwgingrich.budgetButler.dto.db.Budget;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.enums.AccountType;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.EnumLookupUtil;
import com.ryanwgingrich.budgetButler.io.BudgetButlerController;

/**
 * @author ryan
 *
 */
public class BudgetService {

	private static Session dbSession = DBService.getInstance().getSession();
	private static String newLine = System.getProperty("line.separator");// This will retrieve line separator dependent

	private BudgetService() {
	}

	public static BigDecimal getStartCashBalance(Budget budget) {

		int budgetMonth = (budget.getMonth() - 1 == 0 ? 12 : budget.getMonth() - 1);
		int budgetYear = (budget.getMonth() - 1 == 0 ? budget.getYear() - 1 : budget.getYear());

		Budget prevBudget = dbSession.get(Budget.class,
				Integer.valueOf(String.valueOf(budgetYear) + String.format("%02d", budgetMonth)));

		return (prevBudget.getEndCashBalance() == null ? BigDecimal.valueOf(0) : prevBudget.getEndCashBalance());

	}

	@SuppressWarnings("unchecked")
	public static BigDecimal getEndCashBalance(Budget budget) {
		BigDecimal acctEndCashBalance = BigDecimal.valueOf(0);
		BigDecimal endCashBalance = BigDecimal.valueOf(0);

		for (Account account : (List<Account>) dbSession.getNamedQuery("Accounts").getResultList()) {

			if (account.getAccountType().equals(AccountType.SCHWAB_CASH)) {
				int minID = 99999999;
				for (Transaction aTransaction : (List<Transaction>) account.getTransactionList()) {

					for (BudgetBucket budgetBucket : budget.getBucketList()) {

						for (Transaction bTransaction : budgetBucket.getTransactionList()) {

							if (aTransaction.getId() == bTransaction.getId()) {

								if (minID > bTransaction.getId()) {
									minID = bTransaction.getId();
									acctEndCashBalance = bTransaction.getRunningBal();

								}

							}

						}

					}

				}

				endCashBalance = endCashBalance.add(acctEndCashBalance);

			}

		}

		return endCashBalance;

	}

	public static BigDecimal getprojectedEndCashAmt(Budget budget) {

		BigDecimal endCashBalance = getEndCashBalance(budget);
		BigDecimal remainingBalance;

		for (BudgetBucket bucket : budget.getBucketList()) {

			if (!(bucket.getCategory() == BucketCategory.NONE)) {

				if (bucket.getCategory() == BucketCategory.INCOME) {

					remainingBalance = bucket.getAppropiationAmt().subtract(bucket.getCashCreditAmt());

					endCashBalance = endCashBalance
							.add(remainingBalance.compareTo(BigDecimal.valueOf(0)) < 0 ? BigDecimal.valueOf(0)
									: remainingBalance);

				} else {

					remainingBalance = bucket.getAppropiationAmt()
							.subtract(bucket.getCashExpenditureAmt().add(bucket.getCreditExpenditureAmt()));

					endCashBalance = endCashBalance
							.subtract(remainingBalance.compareTo(BigDecimal.valueOf(0)) < 0 ? BigDecimal.valueOf(0)
									: remainingBalance);
				}

			}

		}

		return endCashBalance;
	}

	public static void budgetReport(Budget budget) {
		
		
		Budget prevBudget;

		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

		System.out.println("************************************** " + budget.getId()
				+ "   BUDGET  REPORT    *************************************" + newLine);

		System.out.println(
				"****************************************************************************************************");

		for (BudgetBucket bucket : budget.getBucketList()) {

			System.out.println(bucket.getCategory() + newLine + "Approp Amt: " + bucket.getAppropiationAmt() + " : "
					+ "Remaining Amt: " + BucketService.getRemainingAmt(bucket) + newLine);
			for (Transaction t : (List<Transaction>) bucket.getTransactionList()) {

				System.out.println(sdf.format(t.getDate().getTime()) + " " + t.getType() + " " + t.getDescription()
						+ " " + t.getTransactionAmt() + " " + t.getCategory() + newLine);

			}

		}

		
		
		
		System.out.println("Start Cash Balance: $" + budget.getStartCashBalance() + newLine);

		System.out.println("Current Cash Balance: $" + budget.getEndCashBalance() + newLine);

		System.out.println(
				"Projected End Cash Balance: $" + BudgetService.getprojectedEndCashAmt(budget) + newLine + newLine);

	}

	public static void modifyBudget(Budget budget) throws IOException {

		System.out.println("Updating Budget: " + budget.getId());

		List<BudgetBucket> bucketList = (List<BudgetBucket>) budget.getBucketList();

		System.out.println("Enter Bucket Category You Would Like To Update: " + newLine);
		BucketCategory category = EnumLookupUtil.lookup(BucketCategory.class,
				BudgetButlerController.getStringConsoleInput());

		for (BudgetBucket bucket : bucketList) {

			if (category == bucket.getCategory()) {

				System.out.println("Updating Budget Bucket: " + bucket.getCategory());

				System.out.println("Current Appropiation Amount: " + bucket.getAppropiationAmt());
				System.out.println("Enter New Appropiation Amount: ");
				bucket.setAppropiationAmt(
						BigDecimal.valueOf(Long.valueOf(BudgetButlerController.getStringConsoleInput())));

				DBService.save(bucket);

			}

		}

	}

}
