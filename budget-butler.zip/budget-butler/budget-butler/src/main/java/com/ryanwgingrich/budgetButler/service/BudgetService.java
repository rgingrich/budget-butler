/**
 * 
 */
package com.ryanwgingrich.budgetButler.service;

import java.io.IOException;
import java.util.Calendar;

import javax.persistence.NoResultException;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;

import org.hibernate.Session;

import com.ryanwgingrich.budgetButler.dto.db.Budget;

/**
 * @author ryan
 *
 */
public final class BudgetService {
	private static final BudgetService INSTANCE = new BudgetService();

	private BudgetService() {
	}

	public static BudgetService getInstance() {
		return INSTANCE;
	}

	
	public static void init(int month, int year) throws NumberFormatException, IOException {

		DBService.save(new Budget(month, year));

		// update Budge Buckets

	}

	
	public static void deleteBudget(int id) {
		Session dbSession = DBService.getInstance().getSession();

		// Criteria API (JPA 2.1 and above)
		dbSession.beginTransaction();

		DBService.getInstance().getSession().getNamedQuery("DeleteBudgetById")
		.setParameter("id", Integer.valueOf(String.valueOf(Calendar.getInstance().get(Calendar.YEAR))+String.format("%02d", Calendar.getInstance().get(Calendar.MONTH)+1))).executeUpdate();


		dbSession.getTransaction().commit();
		dbSession.clear();

	}

	public static Budget getBudget(int month, int year) {
		Session dbSession = DBService.getInstance().getSession();
		Budget budget = null;

		try {
			budget = (Budget) dbSession.getNamedQuery("Budget.byYearMonth").setParameter("month", month)
					.setParameter("year", year).getSingleResult();
		}

		catch (NoResultException nre) {
			// Ignore this because as per your logic this is ok!
		}

		return budget;

	}

}
