/**
 * 
 */
package com.ryanwgingrich.budgetButler.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;

import javax.persistence.NoResultException;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;

import org.hibernate.Session;

import com.ryanwgingrich.budgetButler.dto.db.Budget;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.io.BudgetButlerController;

/**
 * @author ryan
 *
 */
public final class BudgetService {
	private static final BudgetService INSTANCE = new BudgetService();

	private BudgetService() {
	}

	public static BudgetService getInstance() {
		return INSTANCE;
	}

	private static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

	public static void init(int month, int year) throws NumberFormatException, IOException {

		DBService.save(new Budget(month, year));

		// update Budge Buckets

	}

	private static int getIntConsoleInput() {

		int input = 0;
		// System.out.println("MAKE SELECTION [1-12]: ");

		try {
			input = Integer.valueOf(br.readLine());
		} catch (NumberFormatException e) {
			System.out.println("***INVALID***");
			input = getIntConsoleInput();
			// e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return input;
	}

	public static void deleteBudgets() {
		Session dbSession = DBService.getInstance().getSession();

		// Criteria API (JPA 2.1 and above)
		dbSession.beginTransaction();

		CriteriaBuilder builder = dbSession.getCriteriaBuilder();
		CriteriaDelete<Budget> query = builder.createCriteriaDelete(Budget.class);
		query.from(Budget.class);
		dbSession.createQuery(query).executeUpdate();

		dbSession.getTransaction().commit();
		dbSession.clear();

	}

	public static Budget getBudget(int month, int year) {
		Session dbSession = DBService.getInstance().getSession();
		Budget budget = null;

		try {
			budget = (Budget) dbSession.getNamedQuery("Budget.byYearMonth").setParameter("month", month)
					.setParameter("year", year).getSingleResult();
		}

		catch (NoResultException nre) {
			// Ignore this because as per your logic this is ok!
		}

		return budget;

	}

}
