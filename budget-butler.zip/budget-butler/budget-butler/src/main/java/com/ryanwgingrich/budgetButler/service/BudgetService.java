/**
 * 
 */
package com.ryanwgingrich.budgetButler.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.List;

import org.hibernate.Session;

import com.ryanwgingrich.budgetButler.dto.db.Account;
import com.ryanwgingrich.budgetButler.dto.db.Budget;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.enums.AccountType;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;

/**
 * @author ryan
 *
 */
public final class BudgetService {

	private static Session dbSession = DBService.getInstance().getSession();

	private static final BudgetService INSTANCE = new BudgetService();

	private BudgetService() {
	}

	public static BudgetService getInstance() {
		return INSTANCE;
	}

	public static void deleteBudget(int id) {

		// Criteria API (JPA 2.1 and above)
		dbSession.beginTransaction();

		DBService.getInstance().getSession().getNamedQuery("DeleteBudgetById")
				.setParameter("id",
						Integer.valueOf(String.valueOf(Calendar.getInstance().get(Calendar.YEAR))
								+ String.format("%02d", Calendar.getInstance().get(Calendar.MONTH) + 1)))
				.executeUpdate();

		dbSession.getTransaction().commit();
		dbSession.clear();

	}

	public static BigDecimal getStartCashBalance(Budget budget) {

		int budgetMonth = (budget.getMonth() - 1 == 0 ? 12 : budget.getMonth() - 1);
		int budgetYear = (budget.getMonth() - 1 == 0 ? budget.getYear() - 1 : budget.getYear());

		return (getEndCashBalance(dbSession.get(Budget.class,
				Integer.valueOf(String.valueOf(budgetYear) + String.format("%02d", budgetMonth)))) == null
						? BigDecimal.valueOf(0)
						: getEndCashBalance(dbSession.get(Budget.class,
								Integer.valueOf(String.valueOf(budgetYear) + String.format("%02d", budgetMonth)))));

	}

	@SuppressWarnings("unchecked")
	public static BigDecimal getEndCashBalance(Budget budget) {
		BigDecimal acctEndCashBalance = BigDecimal.valueOf(0);
		BigDecimal endCashBalance = BigDecimal.valueOf(0);

		for (Account account : (List<Account>) dbSession.getNamedQuery("Accounts").getResultList()) {

			if (account.getAccountType().equals(AccountType.SCHWAB_CASH)) {
				int minID = 99999999;
				for (Transaction aTransaction : (List<Transaction>) account.getTransactionList()) {

					for (BudgetBucket budgetBucket : budget.getBucketList()) {

						for (Transaction bTransaction : budgetBucket.getTransactionList()) {

							if (aTransaction.getId() == bTransaction.getId()) {

								if (minID > bTransaction.getId()) {
									minID = bTransaction.getId();
									acctEndCashBalance = bTransaction.getRunningBal();

								}

							}

						}

					}

				}

				endCashBalance = endCashBalance.add(acctEndCashBalance);

			}

		}

		return endCashBalance;

	}

}
