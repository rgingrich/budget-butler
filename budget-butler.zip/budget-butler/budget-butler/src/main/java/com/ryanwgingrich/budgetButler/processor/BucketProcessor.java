package com.ryanwgingrich.budgetButler.processor;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.ryanwgingrich.budgetButler.dto.db.BBTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

public class BucketProcessor {


	public void updateBucket(Session session, BudgetBucket bucket, Calendar date) {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

		// use last months total to determine the current approp amt
		date.set(Calendar.MONTH, (date.get(Calendar.MONTH) - 1));
		// date.set(Calendar.YEAR,date.get(Calendar.YEAR));
		BigDecimal totalAmt = getMonthTtl(session, bucket.getCategory(), date);
		if (totalAmt == null) {
			totalAmt = BigDecimal.valueOf(0);

		}
		bucket.setAppropAmt(totalAmt);

		date.set(Calendar.MONTH, date.get(Calendar.MONTH) + 1);
		totalAmt = getMonthTtl(session, bucket.getCategory(), date);
		if (totalAmt == null) {
			totalAmt = BigDecimal.valueOf(0);

		}
		bucket.setRemainingAmt(bucket.getAppropAmt().subtract(totalAmt));

		@SuppressWarnings("unchecked")
		List<BBTransaction> transactionList = (List<BBTransaction>) session
				.getNamedQuery("Transactions.byCategoryYearMonth").setParameter("category", bucket.getCategory())
				.setParameter("year", date.get(Calendar.YEAR)).setParameter("month", date.get(Calendar.MONTH))
				.getResultList();

		bucket.setTransactionList(transactionList);

		session.beginTransaction();
		session.save("BudgetBucket", bucket);
		session.getTransaction().commit();

		for (BBTransaction transaction : bucket.getTransactionList()) {

			System.out.println(sdf.format(transaction.getDate()) + " " + transaction.getType() + " "
					+ transaction.getDescription() + " " + transaction.getTransactionAmt());
		}

	}

	
	public BigDecimal getMonthTtl(Session session, BucketCategory category, Calendar date) {
		int month = date.get(Calendar.MONTH);
		int year = date.get(Calendar.YEAR);

	
		BigDecimal sumTransactionResult = (BigDecimal) session.getNamedQuery("SumTransactions.byCategoryYearMonth")
				.setParameter("category", category).setParameter("year", year).setParameter("month", month)
				.getSingleResult();
		
		return (sumTransactionResult == null) ? BigDecimal.valueOf(0) : sumTransactionResult;
		
		
		
		
	}

	
	public BigDecimal getYearTtl(Session session, BucketCategory category, Calendar date) {
		int year = date.get(Calendar.YEAR);

		return (BigDecimal) session.getNamedQuery("SumTransactions.byCategoryYear").setParameter("category", category)
				.setParameter("year", year).getSingleResult();
	}

}
