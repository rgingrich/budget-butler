package com.ryanwgingrich.budgetButler.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.List;

import com.ryanwgingrich.budgetButler.dto.db.Budget;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;

public class ReportService {

	
	public ReportService() {

	}

	@SuppressWarnings("unchecked")
	public static List<Transaction> transactionReport(int month, int year) {

		return DBService.getInstance().getSession().getNamedQuery("Transactions.byYearMonth").setParameter("year", year)
				.setParameter("month", month).getResultList();

	}

	public static BigDecimal getStartCashBalance(int month, int year) {

		Budget budget = (Budget) DBService.getInstance().getSession().get(Budget.class,
				Integer.valueOf(String.valueOf(year) + String.format("%02d", month)));

		return BudgetService.getStartCashBalance(budget);

	}

}
