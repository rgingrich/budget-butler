package com.ryanwgingrich.budgetButler.service;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.List;

import com.ryanwgingrich.budgetButler.dto.db.Account;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;

public class ReportService {

	public ReportService() {

	}

	@SuppressWarnings("unchecked")
	public static List<Transaction> transactionReport(int month, int year) {

		return DBService.getInstance().getSession().getNamedQuery("Transactions.byYearMonth").setParameter("year", year)
				.setParameter("month", month).getResultList();

	}

	public static BigDecimal getStartCashBalance(int month, int year) {

		@SuppressWarnings("unchecked")
		List<Account> accountList = (List<Account>) DBService.getInstance().getSession().getNamedQuery("Accounts")
				.getResultList();

		BigDecimal startCashBalance = BigDecimal.valueOf(0);
		BigDecimal acctStartCashBalance;
		for (Account account : accountList) {
			acctStartCashBalance = BigDecimal.valueOf(0);

			if (!(account.getAcctName().contains("CREDIT") || account.getTransactionList().isEmpty())) {

				int tId = 0;
				for (Transaction t : account.getTransactionList()) {

					if (t.getId() > tId && t.getDate().get(Calendar.YEAR) == year
							&& t.getDate().get(Calendar.MONTH) + 1 == month) {

						if (t.getCategory().equals(BucketCategory.INCOME)) {
							acctStartCashBalance = t.getRunningBal().subtract(t.getTransactionAmt());

						} else {
							acctStartCashBalance = t.getRunningBal().add(t.getTransactionAmt());
						}
						tId = t.getId();
					}

				}
				startCashBalance = startCashBalance.add(acctStartCashBalance);

			}

		}

		return startCashBalance;

	}

	@SuppressWarnings("unchecked")
	public static BigDecimal getCurrentCashAmt(int month, int year) {

		@SuppressWarnings("unchecked")
		List<Account> accountList = (List<Account>) DBService.getInstance().getSession().getNamedQuery("Accounts")
				.getResultList();

		BigDecimal currentCashBalance = BigDecimal.valueOf(0);
		BigDecimal acctCurrentCashBalance = BigDecimal.valueOf(0);

		for (Account account : (List<Account>) DBService.getInstance().getSession().getNamedQuery("Accounts")
				.getResultList()) {
			acctCurrentCashBalance = BigDecimal.valueOf(0);

			if (!(account.getAcctName().contains("CREDIT") || account.getTransactionList().isEmpty())) {

				int tId = 99999;
				for (Transaction t : account.getTransactionList()) {

					if (t.getId() < tId && t.getDate().get(Calendar.YEAR) == year
							&& t.getDate().get(Calendar.MONTH) + 1 == month) {

						acctCurrentCashBalance = t.getRunningBal();
						tId = t.getId();
					}

				}

			}

			currentCashBalance = currentCashBalance.add(acctCurrentCashBalance);

		}

		return currentCashBalance;

	}

	@SuppressWarnings("unchecked")
	public static BigDecimal getprojectedEndCashAmt(int month, int year) {
		BigDecimal projectedEndBalance = getCurrentCashAmt(Calendar.getInstance().get(Calendar.MONTH) + 1,
				Calendar.getInstance().get(Calendar.YEAR));

		for (BudgetBucket b : (List<BudgetBucket>) DBService.getInstance().getSession().getNamedQuery("BudgetBuckets")
				.getResultList()) {

			if (!(b.getCategory() == BucketCategory.NONE || b.getCategory() == BucketCategory.BUFFER
					|| b.getRemainingAmt().compareTo(BigDecimal.valueOf(0)) < 0)) {

				if (b.getCategory() == BucketCategory.INCOME) {
					projectedEndBalance = projectedEndBalance.add(b.getRemainingAmt());
				} else {
					projectedEndBalance = projectedEndBalance.subtract(b.getRemainingAmt());

				}
			}
		}

		return projectedEndBalance;
	}

}
