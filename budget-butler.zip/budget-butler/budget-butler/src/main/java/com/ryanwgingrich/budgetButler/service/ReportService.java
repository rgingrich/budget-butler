package com.ryanwgingrich.budgetButler.service;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.List;

import com.ryanwgingrich.budgetButler.dto.db.Account;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;

public class ReportService {

	public ReportService() {

	}

	@SuppressWarnings("unchecked")
	public static List<Transaction> transactionReport(int month, int year) {

		return DBService.getInstance().getSession().getNamedQuery("Transactions.byYearMonth").setParameter("year", year)
				.setParameter("month", month).getResultList();

	}

	public static BigDecimal getStartCashBalance(int month, int year) {

		// Calendar date = Calendar.getInstance();
		// date.set(Calendar.MONTH, month);

		@SuppressWarnings("unchecked")
		List<Account> accountList = (List<Account>) DBService.getInstance().getSession().getNamedQuery("Accounts")
				.getResultList();

		BigDecimal startCashBalance = BigDecimal.valueOf(0);
		for (Account account : accountList) {

			if (!(account.getAcctName().contains("CREDIT") || account.getTransactionList().isEmpty())) {
				int tId = 0;
				for (Transaction t : account.getTransactionList()) {

					if (t.getId() > tId && t.getDate().get(Calendar.YEAR) == year
							&& t.getDate().get(Calendar.MONTH) == month) {

						tId = t.getId();
					}
				}
				Transaction t = DBService.getInstance().getSession().get(Transaction.class, tId);

				if (t.getCategory().equals(BucketCategory.INCOME)) {
					startCashBalance = startCashBalance.add(t.getRunningBal().subtract(t.getTransactionAmt()));

				} else {
					startCashBalance = startCashBalance.add(t.getRunningBal().add(t.getTransactionAmt()));
				}

			}

		}

		return startCashBalance;

	}

	public static String getCurrentCashAmt() {
		// TODO Auto-generated method stub
		return null;
	}

	public static String getprojectedEndCashAmt() {
		// TODO Auto-generated method stub
		return null;
	}

}
