package com.ryanwgingrich.budgetButler.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.List;

import com.ryanwgingrich.budgetButler.dto.db.Budget;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;

public class ReportService {

	private static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	private static String newLine = System.getProperty("line.separator");// This will retrieve line separator dependent

	public ReportService() {

	}

	@SuppressWarnings("unchecked")
	public static List<Transaction> transactionReport(int month, int year) {

		return DBService.getInstance().getSession().getNamedQuery("Transactions.byYearMonth").setParameter("year", year)
				.setParameter("month", month).getResultList();

	}

	public static BigDecimal getStartCashBalance(int month, int year) {

		Budget budget = (Budget) DBService.getInstance().getSession().get(Budget.class,
				Integer.valueOf(String.valueOf(year) + String.format("%02d", month)));

		return BudgetService.getStartCashBalance(budget);

		// return startCashBalance;

	}

	public static void budgetReport(Budget budget) {
		System.out.println("************************************** " + budget.getId()
				+ "   BUDGET  REPORT    *************************************" + newLine);

		System.out.println(
				"****************************************************************************************************");

		System.out.println("Start Cash Balance: $" + budget.getStartCashBalance() + newLine);

		System.out.println("Current Cash Balance: $" + budget.getEndCashBalance() + newLine);

		System.out.println(
				"Projected End Cash Balance: $" + BudgetService.getprojectedEndCashAmt(budget) + newLine + newLine);

		for (BudgetBucket bucket : budget.getBucketList()) {

			System.out.println(bucket.getCategory() + newLine + "Approp Amt: " + bucket.getAppropiationAmt() + " : "
					+ "Remaining Amt: " + BucketService.getRemainingAmt(bucket) + newLine);
			for (Transaction t : (List<Transaction>) bucket.getTransactionList()) {

				System.out.println(sdf.format(t.getDate().getTime()) + " " + t.getType() + " " + t.getDescription()
						+ " " + t.getTransactionAmt() + " " + t.getCategory() + newLine);

			}

		}

	}

}
