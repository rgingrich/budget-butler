package com.ryanwgingrich.budgetButler.dto.db;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.NamedQuery;

@NamedQuery(name = "Accounts", query = "FROM Account")

// "MonthEndBalance.byYearMonth"

// @NamedQuery(name = "MonthEndBalance.byIdYearMonth", query = "SELECT
// transactionList.runningBal FROM Account where id = :id and
// YEAR(transactionList.date) = :year and MONTH(transactionList.date) = :month
// +1)")
//@NamedQuery(name = "MonthEndBalance", query = "SELECT transactionList.runningBal FROM Account "
//		+ "where id = :id and transactionList.id in (select min(transactionList.id)"
//		+ "from Account WHERE YEAR(transactionList.date) = :year and MONTH(transactionList.date) = :month +1)")

@NamedQuery(name = "AccountTransactions.byId", query = "SELECT transactionList FROM Account a where a.id = :id")

//@NamedQuery(name = "AccountTransactions.byIdYearMonth", query = "SELECT transactionList FROM Account a where a.id = :id and YEAR(transactionList.date) = :year and MONTH(transactionList.date) = :month")
@NamedQuery(name = "DeleteAccounts", query = "delete Account")


@Entity
@Embeddable
public class Account {

	public Account() {

	}

	public Account(String acctName, String csvFile) {

		this.acctName = acctName;
		this.csvFile = csvFile;
	}

	@Id
	//@GeneratedValue
	//private int id;
	private String acctName;
	private String csvFile;
	@ElementCollection
	private Collection<Transaction> transactionList = new ArrayList<Transaction>();

	//public int getId() {
	//	return id;
	//}

	//public void setId(int id) {
	//	this.id = id;
	//}

	public String getAcctName() {
		return acctName;
	}

	public String getCsvFile() {
		return csvFile;
	}

	public void setAcctName(String name) {
		this.acctName = name;
	}

	public void setCsvFile(String csvFile) {
		this.csvFile = csvFile;
	}

	public Collection<Transaction> getTransactionList() {
		return transactionList;
	}

	public void setTransactionList(Collection<Transaction> transactionList) {
		this.transactionList = transactionList;
	}

}
