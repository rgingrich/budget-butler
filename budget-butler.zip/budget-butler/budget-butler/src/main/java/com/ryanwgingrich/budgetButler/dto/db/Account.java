package com.ryanwgingrich.budgetButler.dto.db;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.NamedQuery;




@Entity
@Embeddable
public class Account {

	public Account() {

	}

	public Account(String acctName, String csvFile) {

		this.acctName = acctName;
		this.csvFile = csvFile;

	}

	@Id
	@GeneratedValue
	private int id;
	private String acctName;
	private String csvFile;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAcctName() {
		return acctName;
	}

	public String getCsvFile() {
		return csvFile;
	}

	public void setAcctName(String name) {
		this.acctName = name;
	}

	public void setCsvFile(String csvFile) {
		this.csvFile = csvFile;
	}

}
