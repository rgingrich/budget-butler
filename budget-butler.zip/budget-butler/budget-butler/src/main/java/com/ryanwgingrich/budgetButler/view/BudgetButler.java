package com.ryanwgingrich.budgetButler.view;

import java.text.ParseException;
import java.util.Calendar;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ryanwgingrich.budgetButler.dto.db.Budget;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.io.BudgetBucketController;
import com.ryanwgingrich.budgetButler.io.BudgetButlerController;
import com.ryanwgingrich.budgetButler.io.BudgetController;
import com.ryanwgingrich.budgetButler.io.TransactionController;
import com.ryanwgingrich.budgetButler.parser.FileService;
import com.ryanwgingrich.budgetButler.service.BudgetBucketService;
import com.ryanwgingrich.budgetButler.service.BudgetService;
import com.ryanwgingrich.budgetButler.service.DBService;
import com.ryanwgingrich.budgetButler.service.TransactionService;

public class BudgetButler {

	// GOLBAL variables
	private static Logger logger = LogManager.getLogger(BudgetButler.class.getName());
	// private static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	private static String newLine = System.getProperty("line.separator");
	private static String transactionFileDir = "/home/ryan/BudgetButler";

	public static void main(String[] args) throws IOException, NumberFormatException, ParseException {

		System.out.println(
				"****************************************************************************************************");
		System.out.println(
				"****************************************************************************************************"
						+ newLine);
		System.out.println(
				"*************************************    BUDGET BUTLER v1.0    *************************************"
						+ newLine);
		System.out.println(
				"****************************************************************************************************");

		mainMenu();

		System.out.println("SEE YOU SOON!");
		System.exit(0);

	}

	private static void mainMenu() throws IOException {

		int mainMenuSelection = 0;
		while (mainMenuSelection == 0) {
			System.out.println(
					"******************************************    MAIN MENU    *****************************************"
							+ newLine);
			System.out.println("1: Budget Menu");
			System.out.println("2: Setup");
			System.out.println(newLine);
			System.out.println("9: Exit" + newLine);
			System.out.println(
					"****************************************************************************************************");

			mainMenuSelection = getIntConsoleInput();

			switch (mainMenuSelection) {
			case 1:

				budgetMenu();

				mainMenuSelection = 0;
				break;

			case 2:

				setupMenu();

				mainMenuSelection = 0;
				break;

//			case 3:
//
//				int setuptMeuSelection = 0;
//
//				while (reportMeuSelection == 0) {
//
//					reportMeuSelection = BudgetButlerController.reportMenu();
//					switch (reportMeuSelection) {
//					case 1:
//						BudgetButlerController.transactionReport();
//						reportMeuSelection = 0;
//						break;
//					case 2:
//						BudgetButlerController.budgetReport();
//						reportMeuSelection = 0;
//						break;
//
//					case 9:
//						break;
//
//					default:
//						reportMeuSelection = 0;
//						break;
//
//					}
//
//				}
//
//				mainMenuSelection = 0;
//				break;
			case 9:
				// mainMenuSelection = 0;
				break;
			default:
				mainMenuSelection = 0;
				break;

			}

		}

	}

	private static void setupMenu() throws IOException {

		int setupMenuSelection = 0;

		while (setupMenuSelection == 0) {
			System.out.println(
					"******************************************    SETUP MENU    *****************************************"
							+ newLine);
			System.out.println("1: Initialize Budget Butler");
			System.out.println(newLine);
			System.out.println("9: BACK" + newLine);
			System.out.println(
					"****************************************************************************************************");

			setupMenuSelection = getIntConsoleInput();
			switch (setupMenuSelection) {
			case 1:

				initialize();
				setupMenuSelection = 0;
				break;

			case 9:
				break;

			default:
				setupMenuSelection = 0;
				break;

			}

		}

	}

	private static void initialize() throws IOException {
		DBService dbService = DBService.getInstance();
		FileService fileService = new FileService(transactionFileDir);
		BudgetBucketController budgetBucketController = new BudgetBucketController();
		TransactionController transactionController = new TransactionController();
		BudgetController budgetController = new BudgetController();

		// Remove existing Budgets, BudgetBickets, Accounts, and Transactions
		dbService.truncate("Account");
		dbService.truncate("Budget");
		dbService.truncate("BudgetBucket");
		dbService.truncate("Transaction");
		//dbService.truncate("TransactionDescriptor");

		for (File file : new File(transactionFileDir).listFiles()) {

			fileService.parseFile(file.getAbsolutePath());

		}

		// FIGURE OUT WHERE TO PUT THESE QUERIES...NOT IN TRANSACTIONCONTROLLER
		int minBudgetMonth = transactionController.getMinDate().get(Calendar.MONTH) + 1;
		int minBudgetYear = transactionController.getMinDate().get(Calendar.YEAR);

		int maxBudgetMonth = transactionController.getMaxDate().get(Calendar.MONTH) + 1;
		int maxBudgetYear = transactionController.getMaxDate().get(Calendar.YEAR);

		int budgetYear = minBudgetYear;
		int budgetMonth = minBudgetMonth;
		while (Integer.valueOf(String.valueOf(budgetYear) + String.format("%02d", budgetMonth)) <= Integer
				.valueOf(String.valueOf(maxBudgetYear) + String.format("%02d", maxBudgetMonth))) {

			budgetBucketController.initialize(budgetMonth, budgetYear);
			budgetController.initialize(budgetMonth, budgetYear);
		
			
			
			
			
			

			budgetMonth++;

			if (budgetMonth == 13) {
				budgetMonth = 1;
				budgetYear += 1;
			}

		}

	}

	private static void budgetMenu() {

		int budgetMenuSelection = 0;

		while (budgetMenuSelection == 0) {
			System.out.println(
					"******************************************    BUDGET MENU    *****************************************"
							+ newLine);
			System.out.println("1: Create");
			System.out.println("2: Update");
			System.out.println("3: Delete");
			System.out.println(newLine);
			System.out.println("9: BACK" + newLine);
			System.out.println(
					"****************************************************************************************************");

			budgetMenuSelection = getIntConsoleInput();
			switch (budgetMenuSelection) {
			case 1:
				// TODO:CALL INIT METHODS
				budgetMenuSelection = 0;
				break;
			case 2:
				// TODO:CALL INIT METHODS
				budgetMenuSelection = 0;
				break;
			case 3:
				// TODO:CALL INIT METHODS
				budgetMenuSelection = 0;
				break;

			case 9:
				break;

			default:
				budgetMenuSelection = 0;
				break;

			}

		}

	}

	private static void updateMenu() {

		int updateMeuSelection = 0;
		while (updateMeuSelection == 0) {

			updateMeuSelection = getIntConsoleInput();
			switch (updateMeuSelection) {
			case 1:
				// BudgetButlerController.currentLoadReset();
				updateMeuSelection = 0;
				break;
			case 2:
				// BudgetButlerController.modifyBudget();
				updateMeuSelection = 0;
				break;
			case 3:
				// BudgetButlerController.initialLoadReset();
				updateMeuSelection = 0;
				break;
			case 9:
				break;
			default:
				updateMeuSelection = 0;
				break;
			}
		}

	}

	private static int getIntConsoleInput() {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int input = 0;
		System.out.println("ENTER SELECTION: ");

		try {
			input = Integer.valueOf(br.readLine());
		} catch (NumberFormatException | IOException e) {
			System.out.println("***INVALID***");
			input = getIntConsoleInput();
		}

		return input;
	}

}
