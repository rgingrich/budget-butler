package com.ryanwgingrich.budgetButler.dto.db;

import java.text.SimpleDateFormat;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Entity
@Embeddable
public class Profile {

	// static Logger logger = LogManager.getLogger(Profile.class.getName());

	// DateFormat format = new SimpleDateFormat("mm/dd/yyyy", Locale.ENGLISH);
	// String DATE_FORMAT = "MM/dd/yyyy";
	// SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);

	@Id
	@GeneratedValue
	private int id;
	private String name;
	private String csvfileDirectory;

	public Profile(String name) {
		this.name = name;

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCsvfileDirectory() {
		return csvfileDirectory;
	}

	public void setCsvfileDirectory(String csvfileDirectory) {
		this.csvfileDirectory = csvfileDirectory;
	}

}
