package com.ryanwgingrich.budgetButler.processor;

import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;

public class ProcessorFactory {
	
	

	public Processor getProcessor(BudgetBucket budgetBucket) {
		if (budgetBucket.getCategory().equals(BucketCategory.RENT)) {
			return new RentProcessor();

		} 
		else if (budgetBucket.getCategory().equals(BucketCategory.FOOD)) {
			return new FoodProcessor();

		} 

		return null;
	}
}