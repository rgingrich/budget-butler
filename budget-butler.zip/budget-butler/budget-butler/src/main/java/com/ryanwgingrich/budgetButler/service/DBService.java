package com.ryanwgingrich.budgetButler.service;

import java.util.Calendar;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import com.ryanwgingrich.budgetButler.dto.db.TransactionDescriptor;
import com.ryanwgingrich.budgetButler.dto.db.Account;
import com.ryanwgingrich.budgetButler.dto.db.Budget;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;

public final class DBService {
	private static final DBService INSTANCE = new DBService();

	private DBService() {
	}

	public static DBService getInstance() {
		return INSTANCE;
	}

	private static Session s = new Configuration().configure().buildSessionFactory().openSession();

	public void clearData() {
		s.beginTransaction();
		// s.getNamedQuery("DeleteTransactionDescriptors").executeUpdate();
		s.getNamedQuery("DeleteAccounts").executeUpdate();
		DBService.getInstance();
		s.getNamedQuery("DeleteBudgetBuckets").executeUpdate();
		s.getNamedQuery("DeleteTransactions").executeUpdate();
		s.getTransaction().commit();
		s.clear();

	}

	public void clearTransactions(int month) {
		s.beginTransaction();
		// s.getNamedQuery("DeleteTransactionDescriptors").executeUpdate();
		// s.getNamedQuery("DeleteAccounts").executeUpdate();
		// s.getNamedQuery("DeleteBudgetBuckets").executeUpdate();
		s.getNamedQuery("DeleteCurrentTransactions").setParameter("year", Calendar.getInstance().get(Calendar.YEAR))
				.setParameter("month", month).executeUpdate();

		s.getTransaction().commit();
		s.clear();

	}

	public Session getSession() {
		// TODO Auto-generated method stub
		return s;
	}

	public static void save(Object object) {
		s.beginTransaction();
		s.saveOrUpdate(object);
		s.getTransaction().commit();
		s.clear();

	}

	public static void truncate(String className) {
		s.beginTransaction();

		if (className == "Transaction") {

			CriteriaBuilder builder = s.getCriteriaBuilder();
			CriteriaDelete<Transaction> query = builder.createCriteriaDelete(Transaction.class);
			query.from(Transaction.class);
			s.createQuery(query).executeUpdate();
		}

		else if (className == "BudgetBucket") {
			CriteriaBuilder builder = s.getCriteriaBuilder();
			CriteriaDelete<BudgetBucket> query = builder.createCriteriaDelete(BudgetBucket.class);
			query.from(BudgetBucket.class);
			s.createQuery(query).executeUpdate();

		} else if (className == "Budget") {
			CriteriaBuilder builder = s.getCriteriaBuilder();
			CriteriaDelete<Budget> query = builder.createCriteriaDelete(Budget.class);
			query.from(Budget.class);
			s.createQuery(query).executeUpdate();

		}

		s.getTransaction().commit();
		s.clear();

	}

	public Object getAccounts() {
		// TODO Auto-generated method stub
		return null;
	}

	public static void deleteCurrentData() {

		Budget budget = s.find(Budget.class, Integer.valueOf(String.valueOf(Calendar.getInstance().get(Calendar.YEAR))
				+ String.format("%02d", Calendar.getInstance().get(Calendar.MONTH) + 1)));

		s.beginTransaction();
		for (BudgetBucket budgetBucket : (List<BudgetBucket>) budget.getBucketList()) {

			for (Transaction t : (List<Transaction>) budgetBucket.getTransactionList()) {
				s.remove(t);
			}
			s.remove(budgetBucket);

		}

		s.remove(budget);
		s.getTransaction().commit();
		s.clear();
	}
}