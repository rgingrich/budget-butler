package com.ryanwgingrich.budgetButler.service;

import java.util.Calendar;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import com.ryanwgingrich.budgetButler.dto.db.TransactionDescriptor;
import com.ryanwgingrich.budgetButler.dto.db.Account;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;

public final class DBService {
	private static final DBService INSTANCE = new DBService();

	private DBService() {
	}

	public static DBService getInstance() {
		return INSTANCE;
	}

	private Session s = new Configuration().configure().buildSessionFactory().openSession();

	public void clearData() {
		s.beginTransaction();
		s.getNamedQuery("DeleteTransactionDescriptors").executeUpdate();
		s.getNamedQuery("DeleteAccounts").executeUpdate();
		s.getNamedQuery("DeleteBudgetBuckets").executeUpdate();
		s.getNamedQuery("DeleteTransactions").executeUpdate();
		s.getTransaction().commit();
		s.clear();
		
		

	}
	
	public void clearCurrentTransactions(int month) {
		s.beginTransaction();
		
		//s.getNamedQuery("DeleteCurrentTransactions")
		//.setParameter("year", Calendar.getInstance().get(Calendar.YEAR))
		//.setParameter("month", month)
		//.executeUpdate();
		//s.getTransaction().commit();
		
		
		List<Transaction> transactionList = (List<Transaction>) s.getNamedQuery("Transactions.byYearMonth")
		.setParameter("year", Calendar.getInstance().get(Calendar.YEAR))
		.setParameter("month", month).getResultList();
		
		for (Transaction t : transactionList) {
			s.remove(t);
			
			
		}




	}
	

	public Session getSession() {
		// TODO Auto-generated method stub
		return s;
	}

	public void save(Object object) {
		s.beginTransaction();
		s.saveOrUpdate(object);
		s.getTransaction().commit();

	}
}