package com.ryanwgingrich.budgetButler.enums;

public enum ParserType {
	DESCRIPTOR,
	SCHWAB_BANK,
	CHASE_BANK,
	AMEX_CREDIT,
	U_FIRST,
	CITI_BANK
}
