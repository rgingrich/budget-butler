package com.ryanwgingrich.budgetButler;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.opencsv.CSVWriter;
import com.ryanwgingrich.budgetButler.dto.db.BBBudget;
import com.ryanwgingrich.budgetButler.dto.db.BBTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.db.TransactionDescriptor;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.ParserType;
import com.ryanwgingrich.budgetButler.parser.ParseFactory;
import com.ryanwgingrich.budgetButler.parser.Parser;
import com.ryanwgingrich.budgetButler.processor.BucketProcessor;

public class BudgetButler {

	private static Logger logger = LogManager.getLogger(BudgetButler.class.getName());

	private static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	private static String newLine = System.getProperty("line.separator");// This will retrieve line separator dependent
																			// on OS.

	public static void main(String[] args) throws IOException {

		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();

		List<BudgetBucket> bucketList = new ArrayList<BudgetBucket>();
		for (BucketCategory bucketCategory : BucketCategory.values()) {
			bucketList.add(new BudgetBucket(bucketCategory, null));
		}

		/*****************************************************************************************
		 * Define the DEFAULT directory where to find .csv transaction files
		 *****************************************************************************************/
		String myDirectoryPath = "/home/rgingrich/BudgetButler Transactions";
		/*****************************************************************************************
		*****************************************************************************************/

		File dir = new File(myDirectoryPath);
		File[] directoryListing = dir.listFiles();

		if (directoryListing.length > 0) {

			Parser parser = null;
			for (File child : directoryListing) {

				// Load list of TransactionDiscriptors to DB
				if (FilenameUtils.getExtension(child.getName()).equalsIgnoreCase("csv")
						&& child.getName().contains("TransactionDescriptor")) {
					System.out.print("Detected a transaction descriptor file: " + child.getName() + newLine);
					parser = new ParseFactory().getParser(ParserType.DESCRIPTOR);
					parser.parseToDB(child.getAbsolutePath(), session);

				} else if (FilenameUtils.getExtension(child.getName()).equalsIgnoreCase("csv")
						&& !child.getName().contains("TransactionDescriptor")) {
					/*****************************************************************************************
					 * I found a .csv file! Let's start processing
					 *****************************************************************************************/
					if (child.getName().contains("Checking")) {
						// I am a SCHWAB CHECKING file!
						System.out
								.print("Detected a " + ParserType.SCHWAB_BANK + " file: " + child.getName() + newLine);
						parser = new ParseFactory().getParser(ParserType.SCHWAB_BANK);
						parser.parseToDB(child.getAbsolutePath(), session);

					} else if (child.getName().contains("Transactions")) {
						// I am a AMEX CREDIT file!
						System.out
								.print("Detected a " + ParserType.AMEX_CREDIT + " file: " + child.getName() + newLine);
						parser = new ParseFactory().getParser(ParserType.AMEX_CREDIT);
						parser.parseToDB(child.getAbsolutePath(), session);
					}

				}

			}
			categorizeTransactions(session);

		} else

		{
			System.out.print("I couldnt find anything in (" + myDirectoryPath + ")..." + newLine);
			session.close();
			System.exit(0);
		}

		
		/*****************************************************************************************
		 * Process Buckets
		 *****************************************************************************************/
		Calendar date = Calendar.getInstance();

		BucketProcessor bucketProcessor = new BucketProcessor();

		for (BudgetBucket bucket : bucketList) {

			BigDecimal currentMonthTtl = bucketProcessor.getMonthTtl(session, bucket.getCategory(), date);

			System.out.println(
					newLine + "Current Actual " + bucket.getCategory() + ": $" + currentMonthTtl + newLine);
			bucketProcessor.updateBucket(session, bucket, date);

			date.set(Calendar.MONTH, date.get(Calendar.MONTH) - 1);

			System.out.println(newLine + "Current Expected " + bucket.getCategory() + ": $" + bucket.getAppropAmt());

			date.set(Calendar.MONTH, date.get(Calendar.MONTH) + 1);

			// end loop bucketList loop
		}

		/*****************************************************************************************
		 *****************************************************************************************/
		
		
		
		BBBudget budget = new BBBudget();
		budget.setDate(date);
		budget.setStartCashAmt(BigDecimal.valueOf(0));
		budget.setBucketList(bucketList);
		
		budget.setTotalIncomeAmt(bucketProcessor.getMonthTtl(session, BucketCategory.INCOME, date));
		
		
		budget.setEndCashAmt(budget.getStartCashAmt().add(budget.getTotalIncomeAmt()));
		
		
		
		
		//budget.setAvailableAmt(availableAmt);
		
		
		
		
		///budget.setTotalAmtSpent(totalAmtSpent);
		

		session.beginTransaction();
		session.save(budget);
		session.getTransaction().commit();
		
		
		session.close();
		System.exit(0);

	}

	private static boolean doesTransactionDescriptionExist(Session session, BBTransaction transaction) {

		transaction.getDescription().replaceAll("\'", "\\\\\"");
		String queryDesc = transaction.getDescription().replaceAll("\'", "\\\''");

		long result = (long) session.getNamedQuery("DescriptorLookupCount").setParameter("queryDesc", queryDesc)
				.setParameter("type", transaction.getType()).getSingleResult();

		if (result > 0)
			return true;
		else
			return false;

	}

	private static void categorizeTransactions(Session session) throws IOException {

		/*****************************************************************************************
		 * Catagorize Transactions
		 *****************************************************************************************/
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String myDirectoryPath = "/home/rgingrich/BudgetButler Transactions";
		@SuppressWarnings("unchecked")
		List<BBTransaction> transactionList = session.getNamedQuery("Transactions").getResultList();

		@SuppressWarnings("unchecked")
		List<TransactionDescriptor> descriptorList = session.getNamedQuery("TransactionDescriptors").getResultList();

		for (BBTransaction transaction : transactionList) {

			if (transaction.getCategory() == null) {

				for (TransactionDescriptor transactionDescriptor : descriptorList) {
					if (transactionDescriptor.getdescription().startsWith(transaction.getDescription().substring(0, 10))
							&& transactionDescriptor.getdescription().endsWith(transaction.getType().toString())) {

						transaction.setCategory(transactionDescriptor.getBudgetBucket());

						session.beginTransaction();
						session.update(transaction);
						session.getTransaction().commit();

					}
				}
				if (transaction.getCategory() == null) {
					System.out.println(sdf.format(transaction.getDate()) + " : " + transaction.getDescription() + " : "
							+ transaction.getTransactionAmt());
					System.out.println("Please enter category: ");

					String enteredCategory = br.readLine();
					try {

						transaction.setCategory(BucketCategory.valueOf(enteredCategory));
					} catch (IllegalArgumentException e) {
						enteredCategory = br.readLine();

					}

					session.beginTransaction();
					session.update(transaction);
					session.getTransaction().commit();

					if (!doesTransactionDescriptionExist(session, transaction)) {
						CSVWriter csvWriter = new CSVWriter(
								new FileWriter(myDirectoryPath + "/TransactionDescriptor.csv", true));

						TransactionDescriptor descriptor = new TransactionDescriptor();

						session.beginTransaction();
						descriptor.setBudgetBucket(transaction.getCategory());
						descriptor.setTransactionDescriprion(transaction.getDescription() + transaction.getType());
						session.save(descriptor);
						session.getTransaction().commit();

						descriptorList.add(descriptor);

						String[] record = { descriptor.getdescription(), descriptor.getBudgetBucket().toString() };

						csvWriter.writeNext(record);

						csvWriter.close();

					}

				}
			}
		}
	}
}
