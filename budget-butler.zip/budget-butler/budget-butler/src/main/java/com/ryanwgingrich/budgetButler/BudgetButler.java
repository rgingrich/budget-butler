package com.ryanwgingrich.budgetButler;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.opencsv.bean.CsvToBeanBuilder;
import com.ryanwgingrich.budgetButler.dto.csv.SchwabTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BBTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.db.TransactionDescriptor;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.FinancialInstitutionCode;
import com.ryanwgingrich.budgetButler.enums.TransactionType;
import com.ryanwgingrich.budgetButler.parser.ParseFactory;
import com.ryanwgingrich.budgetButler.parser.Parser;
import com.ryanwgingrich.budgetButler.processor.Processor;
import com.ryanwgingrich.budgetButler.processor.ProcessorFactory;

public class BudgetButler {

	private static Logger logger = LogManager.getLogger(BudgetButler.class.getName());
	private static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	private static String newLine = System.getProperty("line.separator");// This will retrieve line separator dependent
																			// on OS.

	public static void main(String[] args) throws IOException {

		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();

		/*****************************************************************************************
		 * Define and save your BudgetBuckets here
		 *****************************************************************************************/
		  BudgetBucket incomeBucket = new BudgetBucket(BucketCategory.INCOME,BigDecimal.valueOf(0));
		 
		//  session.beginTransaction(); 
		//  session.save(incomeBucket);
		//  session.getTransaction().commit();
		 /*****************************************************************************************
		 *****************************************************************************************/

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("PROCESS .CSV FILES? (Y/N): ");
		if (br.readLine().equalsIgnoreCase("Y")) {

			/*****************************************************************************************
			 * Define the DEFAULT directory where to find .csv transaction files
			 *****************************************************************************************/
			String myDirectoryPath = "/home/rgingrich/BudgetButler Transactions";
			/*****************************************************************************************
			*****************************************************************************************/

			File dir = new File(myDirectoryPath);
			File[] directoryListing = dir.listFiles();

			if (directoryListing != null) {

				for (File child : directoryListing) {

					if (FilenameUtils.getExtension(child.getName()).equalsIgnoreCase("csv")) {
						/*****************************************************************************************
						 * I found a .csv file! Let's start processing
						 *****************************************************************************************/
						// FinancialInstitutionCode financialInstitutionCode = null;

						System.out.print("Found file: " + child.getName() + newLine);

						FinancialInstitutionCode financialInstitutionCode = getFinancialInstitutionCode(br);
						Parser parser = new ParseFactory().getParser(financialInstitutionCode);

						/*****************************************************************************************
						 * Saving transactions to DB
						 *****************************************************************************************/
						parser.parseToDB(child.getAbsolutePath(), session);
					}
				}

			} else {
				System.out.print("I couldnt find anything in (" + myDirectoryPath + ")..." + newLine);
				System.out.print("Tell me where to find your .csv files: ");

				myDirectoryPath = br.readLine();
			}

		}

		/*****************************************************************************************
		 * Catagorize Transactions
		 *****************************************************************************************/
		List<BBTransaction> transactionList = getTransactions(session);
		
		System.out.print(newLine + "Lets start categorizing transactions..." + newLine);
		System.out.println("Please indicate proper BudgetBucket... " + newLine);

		for (BucketCategory bucketCategory : BucketCategory.values()) {
			System.out.print(bucketCategory.toString() + newLine);
		}
		System.out.print(newLine);

		String enteredCategory;
		BudgetBucket budgetBucket;

		for (BBTransaction transaction : transactionList) {
			session.beginTransaction();
			if (transaction.getCategory() != null) {

				System.out.println(sdf.format(transaction.getDate()) + " : " + transaction.getDescription() + " : "
						+ transaction.getTransactionAmt() + " : " + transaction.getCategory().toString());

			} else {
				
				List<TransactionDescriptor> descriptiorList = getTransactionDescriptions(session);

				for (TransactionDescriptor transactionDescriptor : descriptiorList) {
					if (transactionDescriptor.getTransactionDescription().startsWith(transaction.getDescription().substring(0, 10)) && transactionDescriptor.getTransactionDescription().endsWith(transaction.getType().toString())) {

						transaction.setCategory(transactionDescriptor.getBudgetBucket());
						session.save(transaction);
						System.out.println(sdf.format(transaction.getDate()) + " : " + transaction.getDescription()
								+ " : " + transaction.getTransactionAmt() + " : "
								+ transaction.getCategory().toString());
					}
				}
				if (transaction.getCategory() == null) {
					System.out.println(sdf.format(transaction.getDate()) + " : " + transaction.getDescription() + " : "
							+ transaction.getTransactionAmt());
					System.out.println("Please enter category: ");

					enteredCategory = br.readLine();
					transaction.setCategory(BucketCategory.valueOf(enteredCategory));
					session.save(transaction);
					
					if (!doestransactionDescriptionExist(session, transaction)){
						session.save(new TransactionDescriptor(transaction.getDescription()+transaction.getType(), transaction.getCategory()));
						
					}
								
				}

			}
			session.getTransaction().commit();

		}
		/*****************************************************************************************
		*****************************************************************************************/

		/*****************************************************************************************
		 * Process Income Bucket
		 *****************************************************************************************/

		
		Processor incomeProcessor = new ProcessorFactory().getProcessor(incomeBucket);

		System.out.println("PREV YEAR TOTAL INCOME FOR: $" + incomeProcessor.getPrevYearMonthlyTtl(incomeBucket, session));

		/*****************************************************************************************
		*****************************************************************************************/

		// ProcessorFactory processorFactory = new ProcessorFactory();
		// Processor processor = processorFactory.getProcessor(rentBucket);
		// processor.processTransactions(rentBucket,session);

		// processor = processorFactory.getProcessor(foodBucket);
		// processor.processTransactions(foodBucket, session);

		session.close();
		System.exit(0);

	}

	





	private static List<BBTransaction> getTransactions(Session session) {

		Query<BBTransaction> allTransactionsQuery = session.createQuery("FROM BBTransaction WHERE CATEGORY IS NULL order by date desc");

		List<BBTransaction> transactionList = (List<BBTransaction>) allTransactionsQuery.getResultList();
		return transactionList;

	}

	private static List<TransactionDescriptor> getTransactionDescriptions(Session session) {

		Query<TransactionDescriptor> transactionDescriptionsQuery = session.createQuery("FROM TransactionDescriptor WHERE SUBSTR(transactionDescription, 1, 10) IN (SELECT SUBSTR(transactionDescription, 1, 10) FROM TransactionDescriptor GROUP BY SUBSTR(transactionDescription, 1, 10))");

		List<TransactionDescriptor> transactionDescriptionList = (List<TransactionDescriptor>) transactionDescriptionsQuery
				.getResultList();
		return transactionDescriptionList;

	}
	
	
	private static boolean doestransactionDescriptionExist(Session session, BBTransaction transaction) {
		
	   transaction.getDescription().replaceAll("\'", "\\\\\"");
		String queryDesc = transaction.getDescription().replaceAll("\'", "\\\''");
		Query<Long> query = session.createQuery("select count(*) FROM TransactionDescriptor where transactionDescription = '"+queryDesc+transaction.getType()+"'");

		long result = (long) query.getSingleResult();
		
		if(result > 0)
			return true	;		
		else
			return false;
		
}

	/*
	 * 
	 * 
	 * // Read data BudgetBucket bucket = (BudgetBucket)
	 * session.get(BudgetBucket.class, 2); logger.debug(bucket.getCategory());
	 * 
	 * // Delete data // session.delete(bucket);
	 * 
	 * // Update data // bucket.setAmt(BigDecimal.valueOf(666.99));
	 * 
	 * 
	 * // session.update(bucket);
	 * 
	 * 
	 * // Query query = session.createQuery("from BudgetBucket where id > 5"); //
	 * List buckets = query.list();
	 * 
	 * // Query query = session.getNamedQuery("BudgetSheet.byId"); //
	 * query.setInteger(0, 1);
	 * 
	 * // BudgetBucket bucket3 = new BudgetBucket(); // bucket3 =
	 * (BudgetBucket)session.get(BudgetBucket.class, 1);
	 * 
	 */

	private static FinancialInstitutionCode getFinancialInstitutionCode(BufferedReader br2) throws IOException {
		System.out.print("Please Enter Financial Institution Code..." + newLine);
		for (FinancialInstitutionCode fiCode : FinancialInstitutionCode.values()) {
			System.out.print(fiCode.toString() + newLine);
		}

		try {
			return FinancialInstitutionCode.valueOf(br2.readLine());
		} catch (IllegalArgumentException badFinancialInstitutionCodeExceptione) {
			System.out.print("INVALID Financial Institution Code" + newLine);

			for (FinancialInstitutionCode fiCode : FinancialInstitutionCode.values()) {
				System.out.print(fiCode.toString() + newLine);
			}
			// badFinancialInstitutionCodeExceptione.printStackTrace();
			System.out.print("Please Enter one of the listed Financial Institution Codes: ");
			return getFinancialInstitutionCode(br2);

		}

	}

}
