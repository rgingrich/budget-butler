package com.ryanwgingrich.budgetButler;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.opencsv.CSVWriter;
import com.ryanwgingrich.budgetButler.dto.db.Account;
import com.ryanwgingrich.budgetButler.dto.db.Budget;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.dto.db.TransactionDescriptor;
import com.ryanwgingrich.budgetButler.enums.AccountType;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;
import com.ryanwgingrich.budgetButler.io.BudgetButlerController;
import com.ryanwgingrich.budgetButler.io.csvToBean.AmexTransaction;
import com.ryanwgingrich.budgetButler.io.csvToBean.ChaseTransaction;
import com.ryanwgingrich.budgetButler.io.csvToBean.CsvTransactionDescriptor;
import com.ryanwgingrich.budgetButler.io.csvToBean.SchwabTransaction;
import com.ryanwgingrich.budgetButler.parser.AmexTransactionParser;
import com.ryanwgingrich.budgetButler.parser.ChaseTransactionParser;
import com.ryanwgingrich.budgetButler.parser.CsvFileParser;
import com.ryanwgingrich.budgetButler.parser.CsvFileParserFactory;
import com.ryanwgingrich.budgetButler.parser.SchwabTransactionParser;
import com.ryanwgingrich.budgetButler.parser.TransactionDescriptorParser;
import com.ryanwgingrich.budgetButler.service.BucketService;
import com.ryanwgingrich.budgetButler.service.BudgetService;
import com.ryanwgingrich.budgetButler.service.DBService;
import com.ryanwgingrich.budgetButler.service.FileService;
import com.ryanwgingrich.budgetButler.service.TransactionService;

public class BudgetButler {

	// GOLBAL variables
	private static Logger logger = LogManager.getLogger(BudgetButler.class.getName());
	private static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	private static String newLine = System.getProperty("line.separator");// This will retrieve line separator dependent
	private static String transactionFileDir = "/home/ryan/BudgetButler"; // on OS.

	private static BudgetButlerController bbController = new BudgetButlerController();

	public static void main(String[] args) throws IOException, NumberFormatException, ParseException {

		System.out.println(
				"****************************************************************************************************");
		System.out.println(
				"****************************************************************************************************"
						+ newLine);
		System.out.println(
				"*************************************    BUDGET BUTLER v1.0    *************************************"
						+ newLine);
		System.out.println(
				"****************************************************************************************************");

		int mainMenuSelection = 0;

		while (mainMenuSelection == 0) {

			// MainMenu returns an int of user selection
			mainMenuSelection = bbController.bbMainMenu();
			switch (mainMenuSelection) {
			case 1:
				bbController.bbInitialLoadReset();
				mainMenuSelection = 0;
				break;
			case 2:
				bbController.bbCurrentLoadReset();
				mainMenuSelection = 0;
				break;
			case 3:

				int reportMeuSelection = 0;

				while (reportMeuSelection == 0) {
					reportMeuSelection = bbController.bbReportMenu();
					switch (reportMeuSelection) {
					case 1:
						bbController.bbTransactionReport();
						reportMeuSelection = 0;
						break;
					case 2:
						bbController.bbBucketReport();
						reportMeuSelection = 0;
						break;

					case 9:
						break;

					}

				}

				mainMenuSelection = 0;
				break;
			case 4:
				// BudgetService.init();
				mainMenuSelection = 0;
				break;
			}

		}

		System.out.println("SEE YOU SOON!");

	}

//*************************************************************************************/
	// /*****************************************************************************************
	// * Process Buckets
	// *****************************************************************************************/
	//
//		BucketService bucketService = new BucketService();
//
//		// Calendar endDate = Calendar.getInstance();
//
//		for (BudgetBucket b : (List<BudgetBucket>) s.getNamedQuery("BudgetBuckets").getResultList()) {
//
//			bucketService.updateBucket(s, b, curDate);
//
//			List<Transaction> transactionList = (List<Transaction>) b.getTransactionList();
//
//			System.out.println(b.getCategory() + newLine + "Approp Amt: " + b.getAppropAmt() + " : " + "Remaining Amt: "
//					+ b.getRemainingAmt());
//			for (Transaction t : transactionList) {
//
//				System.out.println(
//						t.getDate().getTime().toString() + " : " + t.getDescription() + " : " + t.getTransactionAmt());
//			}
//			System.out.println(newLine);
//
//		}

//
//			List<String[]> creditRecordList = new ArrayList<String[]>();
//			List<String[]> debtRecordList = new ArrayList<String[]>();
//
//			CSVWriter csvWriter = new CSVWriter(new FileWriter(transactionFileDirectory + "/MonthSummary.csv", true));
//
//			String[] reportRecord = null;
//			Calendar reportDate = Calendar.getInstance();
//			// reportDate.set(Calendar.MONTH, reportDate.get(Calendar.MONTH));
//			// Calendar transactionDate = null;//= Calendar.getInstance();
//
//			List<Transaction> transactionList = (List<Transaction>) s.getNamedQuery("Transactions.byYearMonth")
//					.setParameter("year", reportDate.get(Calendar.YEAR))
//					.setParameter("month", reportDate.get(Calendar.MONTH)).getResultList();
//
//			// update qury to only retireve what i need
//			for (Transaction t : transactionList) {
//
//				// transactionDate.setTime(t.getDate().getTime());
//
//				if (t.getCategory().equals(BucketCategory.INCOME)) {
//					String[] creditRecord = { null, t.getDate().toString(), t.getTransactionAmt().toString(),
//							t.getDescription(), t.getCategory().toString() };
//
//					creditRecordList.add(creditRecord);
//
//				} else {
//
//					String[] debtRecord = { null, t.getDate().toString(), t.getTransactionAmt().toString(),
//							t.getDescription(), t.getCategory().toString() };
//
//					debtRecordList.add(debtRecord);
//				}
//
//			}
//
//			for (String[] debtRecord : debtRecordList) {
//
//				reportRecord = debtRecord;
//				csvWriter.writeNext(reportRecord);
//
//			}
//
//			for (String[] creditRecord : creditRecordList) {
//
//				reportRecord = creditRecord;
//				csvWriter.writeNext(reportRecord);
//
//			}
//
//			try {
//				csvWriter.close();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//
//			s.close();
//			System.exit(0);
//
//		} else {
//
//			System.out.print("No files found in (" + transactionFileDirectory + ")...EXITING." + newLine);
//
//			s.close();
//			System.exit(0);
//		}
//	}
//

//
//	@SuppressWarnings("unchecked")

//
	private static int getIntConsoleInput() {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int input = 0;
		System.out.println("MAKE SELECTION [0-9]: ");

		try {
			input = Integer.valueOf(br.readLine());
		} catch (NumberFormatException e) {
			System.out.println("***INVALID***");
			input = getIntConsoleInput();
			// e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return input;
	}
}
