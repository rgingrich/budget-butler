package com.ryanwgingrich.budgetButler;

import java.text.ParseException;
import java.io.IOException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.ryanwgingrich.budgetButler.io.BudgetButlerController;

public class BudgetButler {

	// GOLBAL variables
	private static Logger logger = LogManager.getLogger(BudgetButler.class.getName());
	// private static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	private static String newLine = System.getProperty("line.separator");// This will retrieve line separator dependent
	// private static String transactionFileDir = "/home/ryan/BudgetButler"; // on
	// OS.

	// private static BudgetButlerController bbController = new
	// BudgetButlerController();

	public static void main(String[] args) throws IOException, NumberFormatException, ParseException {

		System.out.println(
				"****************************************************************************************************");
		System.out.println(
				"****************************************************************************************************"
						+ newLine);
		System.out.println(
				"*************************************    BUDGET BUTLER v1.0    *************************************"
						+ newLine);
		System.out.println(
				"****************************************************************************************************");

		int mainMenuSelection = 0;

		while (mainMenuSelection == 0) {

			// MainMenu returns an int of user selection
			mainMenuSelection = BudgetButlerController.mainMenu();

			switch (mainMenuSelection) {

			case 1:
				int updateMeuSelection = 0;

				while (updateMeuSelection == 0) {

					updateMeuSelection = BudgetButlerController.updateMenu();
					switch (updateMeuSelection) {

					case 1:
						BudgetButlerController.bbCurrentLoadReset();
						updateMeuSelection = 0;
						break;
					case 2:
						BudgetButlerController.bbInitialLoadReset();
						updateMeuSelection = 0;
						break;
					case 9:
						break;
					default:
						updateMeuSelection = 0;
						break;
					}

				}
				mainMenuSelection = 0;
				break;

			case 2:

				int reportMeuSelection = 0;

				while (reportMeuSelection == 0) {

					reportMeuSelection = BudgetButlerController.reportMenu();
					switch (reportMeuSelection) {
					case 1:
						BudgetButlerController.transactionReport();
						reportMeuSelection = 0;
						break;
					case 2:
						BudgetButlerController.currentBudgetReport();
						reportMeuSelection = 0;
						break;

					case 9:
						break;

					default:
						reportMeuSelection = 0;
						break;

					}

				}

				mainMenuSelection = 0;
				break;
			case 9:
				// mainMenuSelection = 0;
				break;
			default:
				mainMenuSelection = 0;
				break;

			}

		}

		System.out.println("SEE YOU SOON!");
		System.exit(0);

	}

}
