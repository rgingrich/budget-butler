package com.ryanwgingrich.budgetButler;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.opencsv.CSVWriter;
import com.ryanwgingrich.budgetButler.dto.db.Account;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.dto.db.TransactionDescriptor;
import com.ryanwgingrich.budgetButler.enums.AccountType;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;
import com.ryanwgingrich.budgetButler.io.BudgetButlerController;
import com.ryanwgingrich.budgetButler.io.csvToBean.AmexTransaction;
import com.ryanwgingrich.budgetButler.io.csvToBean.ChaseTransaction;
import com.ryanwgingrich.budgetButler.io.csvToBean.CsvTransactionDescriptor;
import com.ryanwgingrich.budgetButler.io.csvToBean.SchwabTransaction;
import com.ryanwgingrich.budgetButler.parser.AmexTransactionParser;
import com.ryanwgingrich.budgetButler.parser.ChaseTransactionParser;
import com.ryanwgingrich.budgetButler.parser.CsvFileParser;
import com.ryanwgingrich.budgetButler.parser.CsvFileParserFactory;
import com.ryanwgingrich.budgetButler.parser.SchwabTransactionParser;
import com.ryanwgingrich.budgetButler.parser.TransactionDescriptorParser;
import com.ryanwgingrich.budgetButler.service.BucketService;
import com.ryanwgingrich.budgetButler.service.FileService;

public class BudgetButler {

	// GOLBAL variables
	private static Logger logger = LogManager.getLogger(BudgetButler.class.getName());
	private static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	private static String newLine = System.getProperty("line.separator");// This will retrieve line separator dependent
	private static String transactionFileDir = "/home/ryan/BudgetButler"; // on OS.

	private static BudgetButlerController bbController = new BudgetButlerController();
	private static FileService fileService = new FileService(transactionFileDir);

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws IOException, NumberFormatException, ParseException {

		System.out.println(
				"****************************************************************************************************");
		System.out.println(
				"****************************************************************************************************"
						+ newLine);
		System.out.println(
				"*************************************    BUDGET BUTLER v1.0    *************************************"
						+ newLine);
		System.out.println(
				"****************************************************************************************************");

		// MainMenu returns an int of user selection

		int mainMenuSelection = 0;

		while (mainMenuSelection == 0) {

			mainMenuSelection = bbController.bbMainMenu();
			switch (mainMenuSelection) {
			case 1:
				bbController.bbInitialLoadReset();
				mainMenuSelection = 0;
				break;
			case 2:
				// fileService.processFiles(Calendar.getInstance().MONTH);
				// TODO:Output A report of the Transactions

				int reportMeuSelection = 0;

				while (reportMeuSelection == 0) {
					reportMeuSelection = bbController.bbReportMenu();
					switch (reportMeuSelection) {
					case 1:
						bbController.bbTransactionReport();
						reportMeuSelection = 0;
						break;
					case 9:
						break;
					default:
						reportMeuSelection = 0;
						break;
					}

				}

				mainMenuSelection = 0;
				break;
			case 9:
				break;
			default:
				// System.out.println("***INVALID***");
				mainMenuSelection = 0;
				break;
			}

		}

		System.out.println("SEE YOU SOON!");

	}

//		System.out
//				.println("********************************************************************************" + newLine);
//		System.out.println("*************************TRANSACTIONS******************************************" + newLine);
//		System.out
//				.println("********************************************************************************" + newLine);

	// *****************************************************************************************
	// *****************************************************************************************/
	// /*****************************************************************************************
	// * Process Buckets
	// *****************************************************************************************/
	//
//		BucketService bucketService = new BucketService();
//
//		// Calendar endDate = Calendar.getInstance();
//
//		for (BudgetBucket b : (List<BudgetBucket>) s.getNamedQuery("BudgetBuckets").getResultList()) {
//
//			bucketService.updateBucket(s, b, curDate);
//
//			List<Transaction> transactionList = (List<Transaction>) b.getTransactionList();
//
//			System.out.println(b.getCategory() + newLine + "Approp Amt: " + b.getAppropAmt() + " : " + "Remaining Amt: "
//					+ b.getRemainingAmt());
//			for (Transaction t : transactionList) {
//
//				System.out.println(
//						t.getDate().getTime().toString() + " : " + t.getDescription() + " : " + t.getTransactionAmt());
//			}
//			System.out.println(newLine);
//
//		}

//			System.out.println("Start Cash Balance: $"
//					+ getStartCashBalance(s, curDate.get(Calendar.YEAR), curDate.get(Calendar.MONTH)));
//
//			System.out.println("Current Cash Balance: $" + getCurrentCashAmt(s));
//
//			System.out.println("Projected End Cash Balance: $" + getprojectedEndCashAmt(s));
//
//			List<String[]> creditRecordList = new ArrayList<String[]>();
//			List<String[]> debtRecordList = new ArrayList<String[]>();
//
//			CSVWriter csvWriter = new CSVWriter(new FileWriter(transactionFileDirectory + "/MonthSummary.csv", true));
//
//			String[] reportRecord = null;
//			Calendar reportDate = Calendar.getInstance();
//			// reportDate.set(Calendar.MONTH, reportDate.get(Calendar.MONTH));
//			// Calendar transactionDate = null;//= Calendar.getInstance();
//
//			List<Transaction> transactionList = (List<Transaction>) s.getNamedQuery("Transactions.byYearMonth")
//					.setParameter("year", reportDate.get(Calendar.YEAR))
//					.setParameter("month", reportDate.get(Calendar.MONTH)).getResultList();
//
//			// update qury to only retireve what i need
//			for (Transaction t : transactionList) {
//
//				// transactionDate.setTime(t.getDate().getTime());
//
//				if (t.getCategory().equals(BucketCategory.INCOME)) {
//					String[] creditRecord = { null, t.getDate().toString(), t.getTransactionAmt().toString(),
//							t.getDescription(), t.getCategory().toString() };
//
//					creditRecordList.add(creditRecord);
//
//				} else {
//
//					String[] debtRecord = { null, t.getDate().toString(), t.getTransactionAmt().toString(),
//							t.getDescription(), t.getCategory().toString() };
//
//					debtRecordList.add(debtRecord);
//				}
//
//			}
//
//			for (String[] debtRecord : debtRecordList) {
//
//				reportRecord = debtRecord;
//				csvWriter.writeNext(reportRecord);
//
//			}
//
//			for (String[] creditRecord : creditRecordList) {
//
//				reportRecord = creditRecord;
//				csvWriter.writeNext(reportRecord);
//
//			}
//
//			try {
//				csvWriter.close();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//
//			s.close();
//			System.exit(0);
//
//		} else {
//
//			System.out.print("No files found in (" + transactionFileDirectory + ")...EXITING." + newLine);
//
//			s.close();
//			System.exit(0);
//		}
//	}
//
//	private static BigDecimal getStartCashBalance(Session s, int year, int month) {
//
//		// Calendar date = Calendar.getInstance();
//		// date.set(Calendar.MONTH, month);
//
//		@SuppressWarnings("unchecked")
//		List<Account> accountList = (List<Account>) s.getNamedQuery("Accounts").getResultList();
//
//		BigDecimal startCashBalance = BigDecimal.valueOf(0);
//		for (Account account : accountList) {
//
//			if (!(account.getAcctName().contains("CREDIT") || account.getTransactionList().isEmpty())) {
//				int tId = 0;
//				for (Transaction t : account.getTransactionList()) {
//
//					if (t.getId() > tId
//							&& (t.getDate().get(Calendar.YEAR) == year && t.getDate().get(Calendar.MONTH) == month)) {
//
//						tId = t.getId();
//					}
//				}
//				Transaction t = s.get(Transaction.class, tId);
//
//				if (t.getCategory().equals(BucketCategory.INCOME)) {
//					startCashBalance = startCashBalance.add(t.getRunningBal().subtract(t.getTransactionAmt()));
//
//				} else {
//					startCashBalance = startCashBalance.add(t.getRunningBal().add(t.getTransactionAmt()));
//				}
//
//			}
//
//		}
//
//		return startCashBalance;
//
//	}
//
//	public static BigDecimal getCurrentCashAmt(Session s) {
//		//
//		@SuppressWarnings("unchecked")
//		List<Account> accountList = (List<Account>) s.getNamedQuery("Accounts").getResultList();
//		//
//		// // BigDecimal startCashBalance = BigDecimal.valueOf(0);
//		BigDecimal currentCashBalance = BigDecimal.valueOf(0);
//		// //
//		for (Account account : accountList) {
//			//
//			if (!account.getAcctName().contains("CREDIT")) {
//
//				List<Transaction> transactionList = (List<Transaction>) account.getTransactionList();
//
//				BigDecimal tAmt = null;
//				int i = 0;
//				do {
//					if (!transactionList.isEmpty()) {
//						tAmt = transactionList.get(i).getRunningBal();
//						i++;
//					}
//				} while (tAmt.compareTo(BigDecimal.valueOf(0)) == 0);
//
//				currentCashBalance = currentCashBalance.add(tAmt);
//
//			}
//		}
//		return currentCashBalance;
//
//	}
//
//	@SuppressWarnings("unchecked")
//	private static BigDecimal getprojectedEndCashAmt(Session s) {
//
//		BigDecimal projectedEndBalance = BigDecimal.valueOf(0);
//
//		projectedEndBalance = projectedEndBalance.add(getCurrentCashAmt(s));
//
//		for (BudgetBucket b : (List<BudgetBucket>) s.getNamedQuery("BudgetBuckets").getResultList()) {
//
//			if (!(b.getCategory() == BucketCategory.NONE || b.getCategory() == BucketCategory.BUFFER
//					|| b.getRemainingAmt().compareTo(BigDecimal.valueOf(0)) < 0)) {
//
//				if (b.getCategory() == BucketCategory.INCOME) {
//					projectedEndBalance = projectedEndBalance.add(b.getRemainingAmt());
//				} else {
//					projectedEndBalance = projectedEndBalance.subtract(b.getRemainingAmt());
//
//				}
//			}
//		}
//
//		return projectedEndBalance;
//	}
//

}
