package com.ryanwgingrich.budgetButler;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.opencsv.bean.CsvToBeanBuilder;
import com.ryanwgingrich.budgetButler.dto.csv.SchwabTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BBTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.FinancialInstitutionCode;
import com.ryanwgingrich.budgetButler.enums.TransactionType;
import com.ryanwgingrich.budgetButler.parser.ParseFactory;
import com.ryanwgingrich.budgetButler.parser.Parser;
import com.ryanwgingrich.budgetButler.processor.Processor;
import com.ryanwgingrich.budgetButler.processor.ProcessorFactory;

public class BudgetButler {

	private static Logger logger = LogManager.getLogger(BudgetButler.class.getName());
	// private static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	private static String newLine = System.getProperty("line.separator");// This will retrieve line separator dependent
																			// on OS.

	public static void main(String[] args) throws IOException {

		//

		// TODO: Create UI to create BudgetBuckets
		BudgetBucket rentBucket = new BudgetBucket(BucketCategory.RENT, BigDecimal.valueOf(995));
		BudgetBucket foodBucket = new BudgetBucket(BucketCategory.FOOD, BigDecimal.valueOf(400));
		// BudgetBucket incomeBucket = new BudgetBucket(BucketCategory.INCOME,
		// BigDecimal.valueOf(0));

		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(rentBucket);
		session.save(foodBucket);
		session.getTransaction().commit();
		session.close();

		String myDirectoryPath = "/home/rgingrich/BudgetButler Transactions";

		File dir = new File(myDirectoryPath);
		File[] directoryListing = dir.listFiles();
		if (directoryListing != null) {

			session = sessionFactory.openSession();
			
			FinancialInstitutionCode financialInstitutionCode = null;
			for (File child : directoryListing) {

				System.out.print("Found file: " + child.getAbsolutePath() + newLine);
				System.out.print("Please Enter Financial Institution Code: ");

				financialInstitutionCode = getFinancialInstitutionCode();

				Parser parser = new ParseFactory().getParser(financialInstitutionCode);

				parser.parseToDB(child.getAbsolutePath(), session);

				

				//System.out.print("Processing transactions..." + newLine + newLine);

				ProcessorFactory processorFactory = new ProcessorFactory();
				Processor processor = processorFactory.getProcessor(rentBucket);
				processor.processTransactions(rentBucket,session);

				processor = processorFactory.getProcessor(foodBucket);
				processor.processTransactions(foodBucket, session);
			}
		}
		session.close();
	}

	/*
	 * 
	 * 
	 * // Read data BudgetBucket bucket = (BudgetBucket)
	 * session.get(BudgetBucket.class, 2); logger.debug(bucket.getCategory());
	 * 
	 * // Delete data // session.delete(bucket);
	 * 
	 * // Update data // bucket.setAmt(BigDecimal.valueOf(666.99));
	 * 
	 * 
	 * // session.update(bucket);
	 * 
	 * 
	 * // Query query = session.createQuery("from BudgetBucket where id > 5"); //
	 * List buckets = query.list();
	 * 
	 * // Query query = session.getNamedQuery("BudgetSheet.byId"); //
	 * query.setInteger(0, 1);
	 * 
	 * // BudgetBucket bucket3 = new BudgetBucket(); // bucket3 =
	 * (BudgetBucket)session.get(BudgetBucket.class, 1);
	 * 
	 */

	private static FinancialInstitutionCode getFinancialInstitutionCode() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		try {
			return FinancialInstitutionCode.valueOf(br.readLine());
		} catch (IllegalArgumentException badFinancialInstitutionCodeExceptione) {
			System.out.print("INVALID Financial Institution Code" + newLine);

			for (FinancialInstitutionCode fiCode : FinancialInstitutionCode.values()) {
				System.out.print(fiCode.toString() + newLine);
			}
			// badFinancialInstitutionCodeExceptione.printStackTrace();
			System.out.print("Please Enter one of the listed Financial Institution Codes: ");
			return getFinancialInstitutionCode();

		}

	}

}
