package com.ryanwgingrich.budgetButler;

import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Writer;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.opencsv.CSVWriter;
import com.opencsv.bean.CsvToBeanBuilder;
import com.ryanwgingrich.budgetButler.dto.csv.SchwabTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BBTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.db.TransactionDescriptor;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.ParserType;
import com.ryanwgingrich.budgetButler.enums.TransactionType;
import com.ryanwgingrich.budgetButler.parser.ParseFactory;
import com.ryanwgingrich.budgetButler.parser.Parser;
import com.ryanwgingrich.budgetButler.processor.Processor;
import com.ryanwgingrich.budgetButler.processor.ProcessorFactory;

public class BudgetButler {

	private static Logger logger = LogManager.getLogger(BudgetButler.class.getName());
	private static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	private static Calendar date = Calendar.getInstance();
	private static String newLine = System.getProperty("line.separator");// This will retrieve line separator dependent
																			// on OS.

	public static void main(String[] args) throws IOException {

		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();

		/*****************************************************************************************
		 * Define and save your BudgetBuckets here
		 *****************************************************************************************/
		List<BudgetBucket> bucketList = new ArrayList<BudgetBucket>();
		bucketList.add(new BudgetBucket(BucketCategory.INCOME, null));

		for (BudgetBucket bucket : bucketList) {

			session.beginTransaction();
			session.save(bucket);
			session.getTransaction().commit();

		}

		/*****************************************************************************************
		*****************************************************************************************/

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		// System.out.print("PROCESS .CSV FILES? (Y/N): ");
		// if (br.readLine().equalsIgnoreCase("Y")) {

		/*****************************************************************************************
		 * Define the DEFAULT directory where to find .csv transaction files
		 *****************************************************************************************/
		String myDirectoryPath = "/home/rgingrich/BudgetButler Transactions";
		/*****************************************************************************************
		*****************************************************************************************/

		File dir = new File(myDirectoryPath);
		File[] directoryListing = dir.listFiles();

		if (directoryListing.length > 0) {

			Parser parser = null;
			for (File child : directoryListing) {

				// Load list of TransactionDiscriptors to DB
				if (FilenameUtils.getExtension(child.getName()).equalsIgnoreCase("csv")
						&& child.getName().contains("TransactionDescriptor")) {
					System.out.print("Detected a transaction descriptor file: " + child.getName() + newLine);
					parser = new ParseFactory().getParser(ParserType.DESCRIPTOR);
					/*****************************************************************************************
					 * Saving transaction descriptors to DB
					 *****************************************************************************************/
					parser.parseToDB(child.getAbsolutePath(), session);

				} else if (FilenameUtils.getExtension(child.getName()).equalsIgnoreCase("csv")
						&& !child.getName().contains("TransactionDescriptor")) {
					/*****************************************************************************************
					 * I found a .csv file! Let's start processing
					 *****************************************************************************************/
					if (child.getName().contains("Checking")) {
						// I am a SCHWAB CHECKING file!

						System.out
								.print("Detected a " + ParserType.SCHWAB_BANK + " file: " + child.getName() + newLine);
						parser = new ParseFactory().getParser(ParserType.SCHWAB_BANK);

						/*****************************************************************************************
						 * Saving transactions to DB
						 *****************************************************************************************/
						parser.parseToDB(child.getAbsolutePath(), session);

						/*****************************************************************************************
						 * Catagorize Transactions
						 *****************************************************************************************/

						@SuppressWarnings("unchecked")
						List<BBTransaction> transactionList = session.getNamedQuery("Transactions").getResultList();
								//.setParameter("year", date.get(Calendar.YEAR))
								//.setParameter("month", date.get(Calendar.MONTH)).getResultList();

						@SuppressWarnings("unchecked")
						List<TransactionDescriptor> descriptorList = session.getNamedQuery("TransactionDescriptors")
								.getResultList();

						
						for (BBTransaction transaction : transactionList) {

							if (transaction.getCategory() != null) {

								System.out.println(sdf.format(transaction.getDate()) + " : "
										+ transaction.getDescription() + " : " + transaction.getTransactionAmt() + " : "
										+ transaction.getCategory().toString());

							} else {

								for (TransactionDescriptor transactionDescriptor : descriptorList) {
									if (transactionDescriptor.getdescription()
											.startsWith(transaction.getDescription().substring(0, 10))
											&& transactionDescriptor.getdescription()
													.endsWith(transaction.getType().toString())) {

										transaction.setCategory(transactionDescriptor.getBudgetBucket());
										System.out.println(sdf.format(transaction.getDate()) + " : "
												+ transaction.getDescription() + " : " + transaction.getTransactionAmt()
												+ " : " + transaction.getCategory().toString());
										session.beginTransaction();
										session.update(transaction);
										session.getTransaction().commit();

									}
								}
								if (transaction.getCategory() == null) {
									System.out.println(sdf.format(transaction.getDate()) + " : "
											+ transaction.getDescription() + " : " + transaction.getTransactionAmt());
									System.out.println("Please enter category: ");

									String enteredCategory = br.readLine();
									try {

										transaction.setCategory(BucketCategory.valueOf(enteredCategory));
									} catch (IllegalArgumentException e) {
										enteredCategory = br.readLine();

									}

									session.beginTransaction();
									session.update(transaction);
									session.getTransaction().commit();

									if (!doesTransactionDescriptionExist(session, transaction)) {
										CSVWriter csvWriter = new CSVWriter(
												new FileWriter(myDirectoryPath + "/TransactionDescriptor.csv", true));
										
										TransactionDescriptor descriptor = new TransactionDescriptor();

										session.beginTransaction();
										descriptor.setBudgetBucket(transaction.getCategory());
										descriptor.setTransactionDescriprion(
												transaction.getDescription() + transaction.getType());
										session.save(descriptor);
										session.getTransaction().commit();

										descriptorList.add(descriptor);

										String[] record = (descriptor.getdescription() + ","
													+ descriptor.getBudgetBucket().toString()).split(",");

											csvWriter.writeNext(record);
											

										
										csvWriter.close();

									}

								}

							}
							
						}

					}

				}

			}

		} else

		{
			System.out.print("I couldnt find anything in (" + myDirectoryPath + ")..." + newLine);
			System.exit(0);
		}

		/*****************************************************************************************
		*****************************************************************************************/

		/*****************************************************************************************
		 * Process Income Bucket
		 *****************************************************************************************/
	
		BudgetBucket incomeBucket = null;

		// look at enhancing this loop
		for (BudgetBucket bucket : bucketList) {
			if (bucket.getCategory().equals(BucketCategory.INCOME)) {
				incomeBucket = bucket;
			}
		}
		Calendar date = Calendar.getInstance();
		Processor incomeProcessor = new ProcessorFactory().getProcessor(incomeBucket);

		BigDecimal currentMonthTtl = incomeProcessor.getMonthTtl(session, BucketCategory.INCOME, date);
		date.set(Calendar.YEAR, date.get(Calendar.YEAR) - 1);
		incomeBucket.setAppropAmt(incomeProcessor.getMonthTtl(session, BucketCategory.INCOME, date));

		date.set(Calendar.YEAR, date.get(Calendar.YEAR) + 1);

		incomeProcessor.updateBucket(session, incomeBucket, date);
		System.out.println(
				"Current Actual Income: $" + incomeBucket.getAppropAmt().subtract(incomeBucket.getRemainingAmt()));

		date.set(Calendar.MONTH, date.get(Calendar.MONTH) - 1);

		System.out.println(
				"Current Expected Income: $" + incomeProcessor.getMonthTtl(session, BucketCategory.INCOME, date) + " ("
						+ sdf.format(date.getTime()) + ")");

		/*****************************************************************************************
		 *****************************************************************************************/

		// ProcessorFactory processorFactory = new ProcessorFactory();
		// Processor processor = processorFactory.getProcessor(rentBucket);
		// processor.processTransactions(rentBucket,session);

		// processor = processorFactory.getProcessor(foodBucket);
		// processor.processTransactions(foodBucket, session);

		session.close();
		System.exit(0);

	}

	private static boolean doesTransactionDescriptionExist(Session session, BBTransaction transaction) {

		transaction.getDescription().replaceAll("\'", "\\\\\"");
		String queryDesc = transaction.getDescription().replaceAll("\'", "\\\''");

		@SuppressWarnings("unchecked")
		long result = (long) session.getNamedQuery("DescriptorLookupCount").setParameter("queryDesc", queryDesc)
				.setParameter("type", transaction.getType()).getSingleResult();

		if (result > 0)
			return true;
		else
			return false;

	}

}
