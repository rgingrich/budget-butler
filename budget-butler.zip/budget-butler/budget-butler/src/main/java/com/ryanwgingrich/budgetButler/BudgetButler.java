package com.ryanwgingrich.budgetButler;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.opencsv.CSVWriter;
import com.ryanwgingrich.budgetButler.dto.db.Account;
import com.ryanwgingrich.budgetButler.dto.db.Budget;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.db.TransactionDescriptor;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.BudgetStatus;
import com.ryanwgingrich.budgetButler.enums.ParserType;
import com.ryanwgingrich.budgetButler.parser.ParseFactory;
import com.ryanwgingrich.budgetButler.parser.Parser;
import com.ryanwgingrich.budgetButler.processor.BucketProcessor;

public class BudgetButler {

	private static Logger logger = LogManager.getLogger(BudgetButler.class.getName());

	private static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	private static String newLine = System.getProperty("line.separator");// This will retrieve line separator dependent
																			// on OS.

	public static void main(String[] args) throws IOException {

		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		Calendar date = Calendar.getInstance();

		List<BudgetBucket> bucketList = new ArrayList<BudgetBucket>();
		for (BucketCategory bucketCategory : BucketCategory.values()) {
			bucketList.add(new BudgetBucket(bucketCategory, null));
		}

		/*****************************************************************************************
		 * Define the DEFAULT directory where to find .csv transaction files
		 *****************************************************************************************/
		String myDirectoryPath = "/home/rgingrich/BudgetButler Transactions";
		/*****************************************************************************************
		*****************************************************************************************/

		File dir = new File(myDirectoryPath);
		File[] directoryListing = dir.listFiles();

		if (directoryListing.length > 0) {

			Parser parser = null;
			int acctCounter = 0;
			for (File child : directoryListing) {

				// Load list of TransactionDiscriptors to DB
				if (FilenameUtils.getExtension(child.getName()).equalsIgnoreCase("csv")
						&& child.getName().contains("TransactionDescriptor")) {
					System.out.print("Detected a transaction descriptor file: " + child.getName() + newLine);
					parser = new ParseFactory().getParser(ParserType.DESCRIPTOR);
					parser.parseToDB(child.getAbsolutePath(), session);

				} else if (FilenameUtils.getExtension(child.getName()).equalsIgnoreCase("csv")
						&& !child.getName().contains("TransactionDescriptor")) {
					/*****************************************************************************************
					 * I found a .csv file! Let's start processing
					 *****************************************************************************************/

					if (child.getName().contains("Checking")) {
						acctCounter += 1;
						// I am a SCHWAB CHECKING file!
						System.out
								.print("Detected a " + ParserType.SCHWAB_BANK + " file: " + child.getName() + newLine);

						Account account = new Account(ParserType.SCHWAB_BANK.toString() + acctCounter,
								child.getAbsolutePath());

						parser = new ParseFactory().getParser(ParserType.SCHWAB_BANK);
						parser.parseToDB(account, session);

					} else if (child.getName().contains("Transactions")) {
						// I am a AMEX CREDIT file!
						System.out
								.print("Detected a " + ParserType.AMEX_CREDIT + " file: " + child.getName() + newLine);
						parser = new ParseFactory().getParser(ParserType.AMEX_CREDIT);
						parser.parseToDB(child.getAbsolutePath(), session);
					}

				}

			}
			categorizeTransactions(session);

		} else

		{
			System.out.print("I couldnt find anything in (" + myDirectoryPath + ")..." + newLine);
			session.close();
			System.exit(0);
		}

		/*****************************************************************************************
		 * Get Current Cash Amount
		 *****************************************************************************************/

		@SuppressWarnings("unchecked")
		List<Account> accountList = (List<Account>) session.getNamedQuery("Accounts").getResultList();

		BigDecimal startCashBalance = BigDecimal.valueOf(0);
		BigDecimal currentCashBalance = BigDecimal.valueOf(0);
		BigDecimal projectedEndBalance = BigDecimal.valueOf(0);
		for (Account account : accountList) {

			@SuppressWarnings("unchecked")
			List<Transaction> transactionList = (List<Transaction>) session.getNamedQuery("AccountTransactions.byId")
					.setParameter("id", account.getId()).getResultList();

			currentCashBalance = currentCashBalance.add(transactionList.get(0).getRunningBal());

			/*****************************************************************************************
			 *****************************************************************************************/
			/*****************************************************************************************
			 * Get Start Cash Amount
			 *****************************************************************************************/

			date = Calendar.getInstance();

			date.set(Calendar.MONTH, date.get(Calendar.MONTH) - 1);

			int id = 999999;
			Calendar date2 = Calendar.getInstance();
			for (Transaction t : transactionList) {

				date2.setTime(t.getDate());

				if (date2.get(Calendar.MONTH) == date.get(Calendar.MONTH)) {

					if (id > t.getId()) {
						id = t.getId();
					}

				}

			}

			Transaction t = session.get(Transaction.class, id);
			startCashBalance = startCashBalance.add(t.getRunningBal());

		}

		/*****************************************************************************************
		 *****************************************************************************************/
		/*****************************************************************************************
		 * Process Buckets
		 *****************************************************************************************/
		date = Calendar.getInstance();

		BucketProcessor bucketProcessor = new BucketProcessor();

		for (BudgetBucket bucket : bucketList) {

			BigDecimal currentMonthTtl = bucketProcessor.getMonthTtl(session, bucket.getCategory(), date);

			// System.out.println(newLine + "Current Actual " + bucket.getCategory() + ": $"
			// + currentMonthTtl + newLine);
			bucketProcessor.updateBucket(session, bucket, date);

			date.set(Calendar.MONTH, date.get(Calendar.MONTH) - 1);

			// System.out.println(newLine + "Current Expected " + bucket.getCategory() + ":
			// $" + bucket.getAppropAmt());

			date.set(Calendar.MONTH, date.get(Calendar.MONTH) + 1);

			// end loop bucketList loop
		}

		/*****************************************************************************************
		 *****************************************************************************************
		 * 
		 * 
		 * /*****************************************************************************************
		 * Get Projected End Cash Amount
		 *****************************************************************************************/
		projectedEndBalance = projectedEndBalance.add(currentCashBalance);
		for (BucketCategory budgetCategory : BucketCategory.values()) {
			BudgetBucket b = (BudgetBucket) session.get(BudgetBucket.class, budgetCategory);
			if (budgetCategory != BucketCategory.NONE && budgetCategory != BucketCategory.TRANSFER) {
				if (budgetCategory == BucketCategory.INCOME) {
					projectedEndBalance = projectedEndBalance.add(b.getRemainingAmt());
				} else {
					projectedEndBalance = projectedEndBalance.subtract(b.getRemainingAmt());
				}
			}
		}

		/*****************************************************************************************
		 *****************************************************************************************/
		System.out.println("Start Cash Balance: " + startCashBalance + newLine);
		System.out.println("Current Cash Balance: " + currentCashBalance + newLine);
		System.out.println("Projected End Cash Balance: " + projectedEndBalance + newLine);

		/*
		 * Budget budget = new Budget();
		 * 
		 * budget.setBucketList(bucketList);
		 * 
		 * budget.setBudgetStatus(BudgetStatus.GOOD);
		 * 
		 * Account cashAcct1 = new Account("Ryans Checking", "Ryans_Checking"); Account
		 * cashAcct2 = new Account("Kellys Checking", "Kellys_Checking"); Account
		 * cashAcct3 = new Account("Family Checking", "Family Checking"); List<Account>
		 * cashAccountList = new ArrayList<Account>(); cashAccountList.add(cashAcct1);
		 * cashAccountList.add(cashAcct2); cashAccountList.add(cashAcct3);
		 * session.beginTransaction(); session.save(cashAcct1); session.save(cashAcct2);
		 * session.save(cashAcct3); session.getTransaction().commit();
		 * budget.setCashAcctList(cashAccountList);
		 * 
		 * budget.setCashBalance(new BigDecimal(0));
		 * 
		 * Account creditAcct1 = new Account("AmEx","Transactions"); //Account
		 * creditAcct2 = new Account(); List<Account> creditAccountList = new
		 * ArrayList<Account>(); session.beginTransaction(); session.save(creditAcct1);
		 * //session.save(creditAcct2); session.getTransaction().commit();
		 * 
		 * creditAccountList.add(creditAcct1); // creditAccountList.add(creditAcct2);
		 * //budget.setCreditAcctList(creditAccountList);
		 * 
		 * budget.setCreditBalance(new BigDecimal(0));
		 * 
		 * date = Calendar.getInstance(); date.set(Calendar.DAY_OF_MONTH,
		 * date.getActualMaximum(Calendar.DAY_OF_MONTH));
		 * budget.setEndDate(date.getTime());
		 * 
		 * String budgetName = "Gingrich Family Budget"; budget.setName(budgetName);
		 * 
		 * date = Calendar.getInstance(); date.set(Calendar.DAY_OF_MONTH, 1);
		 * budget.setStartDate(date.getTime());
		 * 
		 * session.beginTransaction(); session.save(budget);
		 * session.getTransaction().commit();
		 */
		session.close();
		System.exit(0);

	}

	private static boolean doesTransactionDescriptionExist(Session session, Transaction transaction) {

		transaction.getDescription().replaceAll("\'", "\\\\\"");
		String queryDesc = transaction.getDescription().replaceAll("\'", "\\\''");

		long result = (long) session.getNamedQuery("DescriptorLookupCount").setParameter("queryDesc", queryDesc)
				.setParameter("type", transaction.getType()).getSingleResult();

		if (result > 0)
			return true;
		else
			return false;

	}

	private static void categorizeTransactions(Session session) throws IOException {

		/*****************************************************************************************
		 * Catagorize Transactions
		 *****************************************************************************************/
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String myDirectoryPath = "/home/rgingrich/BudgetButler Transactions";
		@SuppressWarnings("unchecked")
		List<Transaction> transactionList = session.getNamedQuery("Transactions").getResultList();

		@SuppressWarnings("unchecked")
		List<TransactionDescriptor> descriptorList = session.getNamedQuery("TransactionDescriptors").getResultList();

		for (Transaction transaction : transactionList) {

			if (transaction.getCategory() == null) {

				for (TransactionDescriptor transactionDescriptor : descriptorList) {
					if (transactionDescriptor.getdescription().startsWith(transaction.getDescription().substring(0, 10))
							&& transactionDescriptor.getdescription().endsWith(transaction.getType().toString())) {

						transaction.setCategory(transactionDescriptor.getBudgetBucket());

						session.beginTransaction();
						session.update(transaction);
						session.getTransaction().commit();

					}
				}
				if (transaction.getCategory() == null) {
					System.out.println(sdf.format(transaction.getDate()) + " : " + transaction.getDescription() + " : "
							+ transaction.getTransactionAmt());
					System.out.println("Please enter category: ");

					String enteredCategory = br.readLine();
					try {

						transaction.setCategory(BucketCategory.valueOf(enteredCategory));
					} catch (IllegalArgumentException e) {
						enteredCategory = br.readLine();

					}

					session.beginTransaction();
					session.update(transaction);
					session.getTransaction().commit();

					if (!doesTransactionDescriptionExist(session, transaction)) {
						CSVWriter csvWriter = new CSVWriter(
								new FileWriter(myDirectoryPath + "/TransactionDescriptor.csv", true));

						TransactionDescriptor descriptor = new TransactionDescriptor();

						session.beginTransaction();
						descriptor.setBudgetBucket(transaction.getCategory());
						descriptor.setTransactionDescriprion(transaction.getDescription() + transaction.getType());
						session.save(descriptor);
						session.getTransaction().commit();

						descriptorList.add(descriptor);

						String[] record = { descriptor.getdescription(), descriptor.getBudgetBucket().toString() };

						csvWriter.writeNext(record);

						csvWriter.close();

					}

				}
			}
		}
	}
}
