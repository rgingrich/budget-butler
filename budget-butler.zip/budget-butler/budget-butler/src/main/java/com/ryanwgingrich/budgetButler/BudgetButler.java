package com.ryanwgingrich.budgetButler;

import org.apache.logging.log4j.Logger;

//import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.ryanwgingrich.budgetButler.dto.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.BudgetSheet;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;

public class BudgetButler {
    static Logger logger = LogManager.getLogger(BudgetButler.class.getName());

    public static void main(String[] args) {
        
    	SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
    	Session session = sessionFactory.openSession();
    	 
    	
    	
    	
    	
    	
    	BudgetBucket bucket = new BudgetBucket();
    	bucket.setAmt(BigDecimal.valueOf(100));
    	bucket.setCategory("GAS");
    	
    	BudgetBucket bucket2 = new BudgetBucket();
    	bucket2.setAmt(BigDecimal.valueOf(995));
    	bucket2.setCategory("RENT");
    	
    	List bucketList = new ArrayList();
    	bucketList.add(bucket);
    	bucketList.add(bucket2);
    	
    	BudgetSheet budgetSheet = new BudgetSheet();
    	budgetSheet.setEndAmt(BigDecimal.valueOf(100));
    	budgetSheet.setLisOfBudgetBuckets(bucketList);
    	
    	
    	
    	
    	session.beginTransaction();
    	
    	//Create data
    	/*for (int i=0; i<10; i++) {
    		BudgetBucket bucket = new BudgetBucket();
    		bucket.setAmt(BigDecimal.valueOf(100).add(BigDecimal.valueOf(i)));
        	bucket.setCategory("TEST");
        	session.save(bucket);
    	}*/
    	
    	//Read data
    	//BudgetBucket bucket = session.//et(BudgetBucket.class, 9);
    	    	
    	//Delete data
    	//session.delete(bucket);
    	    	
    	//Update data
    	//bucket.setAmt(BigDecimal.valueOf(666.99));
    	
    	
    	session.save(bucket);
    	session.save(bucket2);
    	session.save(budgetSheet);
    	
    	session.getTransaction().commit();
    	
    	//session.update(bucket);
    	
    	
    	//bucket.setCategory("RENT");
    	
    	
    	
    	//Query query = session.createQuery("from BudgetBucket where id > 5");
    	//List buckets = query.list();
    	
    	
    	//Query query = session.getNamedQuery("BudgetSheet.byId");
    	//query.setInteger(0, 1);
    	
    	
    	
    	
    
    	
    	
    	BudgetBucket bucket3 = new BudgetBucket();
    	bucket3 = (BudgetBucket)session.get(BudgetBucket.class, 1);
    	
    	//logger.debug(bucket3.getCategory());
    	System.out.println(bucket3.getCategory());
    	session.close();
    }
}







