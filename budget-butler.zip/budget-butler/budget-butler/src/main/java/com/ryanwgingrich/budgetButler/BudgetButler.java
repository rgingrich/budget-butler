package com.ryanwgingrich.budgetButler;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.io.FileNotFoundException;
import java.io.FileReader;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.opencsv.bean.CsvToBeanBuilder;
import com.ryanwgingrich.budgetButler.dto.cvs.CsvTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BBTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.db.BudgetSheet;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

public class BudgetButler {
	static Logger logger = LogManager.getLogger(BudgetButler.class.getName());

	public static void main(String[] args) throws FileNotFoundException {

		String fileName = "/home/rgingrich/Software Development/eclipse-workspace/budget-butler/budget-butler/Ryans_Checking_Checking_Transactions_20180128-230200.CSV";
		FileReader fileReader = new FileReader(fileName);

		List<CsvTransaction> csvTransactions = new CsvToBeanBuilder<CsvTransaction>(fileReader)
				.withType(CsvTransaction.class).build().parse();

		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		for (CsvTransaction csvTransaction : csvTransactions) {

			session.save(new BBTransaction(csvTransaction.getDate(), csvTransaction.getType(),
					csvTransaction.getDescription(), csvTransaction.getCheckNum(), csvTransaction.getDeposit(),
					csvTransaction.getWithdrawal(), csvTransaction.getRunningBalance()));
		}
		csvTransactions.removeAll(csvTransactions);
		Calendar cal = Calendar.getInstance();

		BudgetBucket rentBucket = new BudgetBucket(BucketCategory.RENT, BigDecimal.valueOf(995));
		session.save(rentBucket);
		// process rent bucket//////////////////////////////////////////////////////////

		String RENT_QUERY = "SELECT withdrawal FROM BBTransaction bbT where YEAR(date) = " + cal.get(Calendar.YEAR)
				+ " and MONTH(date) = " + (cal.get(Calendar.MONTH) + 1) + " and  withdrawal = "
				+ rentBucket.getAppropAmt() + " and type = " + TransactionType.TRANSFER.ordinal();

		Query<BigDecimal> query = session.createQuery(RENT_QUERY);

		// List<BBTransaction> rentTransactions = query.list();
		BigDecimal withdrawal = query.getSingleResult();

		if (withdrawal != null) {
			rentBucket.setRemainingAmt(rentBucket.getRemainingAmt().subtract(withdrawal));
		}

		session.update(rentBucket);
		///////////////////////////////////////////////////////////////////////////////////

		BudgetBucket foodBucket = new BudgetBucket(BucketCategory.FOOD, BigDecimal.valueOf(400));
		session.save(foodBucket);
		// process food bucket//////////////////////////////////////////////////////////
		// Calendar cal = Calendar.getInstance();

		String FOOD_QUERY = "SELECT withdrawal FROM BBTransaction bbT where YEAR(date) = " + cal.get(Calendar.YEAR)
				+ " and MONTH(date) = " + (cal.get(Calendar.MONTH) + 1)
				+ " and  (description like '%DUNKIN%' or description like '%CAFE%' or description like '%STAGECOACH%' or description like '%MCDONALD''S%') and type = "
				+ TransactionType.VISA.ordinal();

		query = session.createQuery(FOOD_QUERY);

		List<BigDecimal> foodExpenderatures = query.list();
		// BigDecimal withdrawal = query.getSingleResult();

		for (BigDecimal foodExpenderature : foodExpenderatures) {

			if (foodExpenderature != null) {
				foodBucket.setRemainingAmt(foodBucket.getRemainingAmt().subtract(foodExpenderature));

			}
		}
		session.update(foodBucket);
		///////////////////////////////////////////////////////////////////////////////////

		BudgetBucket otherBucket = new BudgetBucket(BucketCategory.OTHER, BigDecimal.valueOf(500));
		session.save(otherBucket);
		// process food bucket//////////////////////////////////////////////////////////
		// Calendar cal = Calendar.getInstance();

		String OTHER_QUERY = "SELECT withdrawal FROM BBTransaction bbT where YEAR(date) = " + cal.get(Calendar.YEAR)
				+ " and MONTH(date) = " + (cal.get(Calendar.MONTH) + 1) + " and  (type = "
				+ TransactionType.ATM.ordinal()
				+ " or description like '%CAR WASH%' or description like '%UNDER ARMOUR%' or (description like '%EXXONMOBIL%' and withdrawal < 10.00))";

		query = session.createQuery(OTHER_QUERY);

		List<BigDecimal> otherExpenderatures = query.list();
		// BigDecimal withdrawal = query.getSingleResult();

		for (BigDecimal otherExpenderature : otherExpenderatures) {

			if (otherExpenderature != null) {
				otherBucket.setRemainingAmt(otherBucket.getRemainingAmt().subtract(otherExpenderature));

			}
		}
		session.update(otherBucket);
		///////////////////////////////////////////////////////////////////////////////////

		BudgetBucket phoneBucket = new BudgetBucket(BucketCategory.PHONE, BigDecimal.valueOf(200));
		session.save(phoneBucket);
		// process food bucket//////////////////////////////////////////////////////////
		// Calendar cal = Calendar.getInstance();

		String PHONE_QUERY = "SELECT withdrawal FROM BBTransaction bbT where YEAR(date) = " + cal.get(Calendar.YEAR)
				+ " and MONTH(date) = " + (cal.get(Calendar.MONTH) + 1) + " and  type = "
				+ TransactionType.TRANSFER.ordinal() + "and withdrawal = " + phoneBucket.getAppropAmt();

		query = session.createQuery(PHONE_QUERY);

		List<BigDecimal> phoneExpenderatures = query.list();
		// BigDecimal withdrawal = query.getSingleResult();

		for (BigDecimal phoneExpenderature : phoneExpenderatures) {

			if (phoneExpenderature != null) {
				phoneBucket.setRemainingAmt(phoneBucket.getRemainingAmt().subtract(phoneExpenderature));

			}
		}
		session.update(otherBucket);
		///////////////////////////////////////////////////////////////////////////////////

		BudgetBucket incomeBucket = new BudgetBucket(BucketCategory.INCOME, BigDecimal.valueOf(3684));
		session.save(incomeBucket);
		// process food bucket//////////////////////////////////////////////////////////
		// Calendar cal = Calendar.getInstance();

		String INCOME_QUERY = "SELECT deposit FROM BBTransaction bbT where YEAR(date) = " + cal.get(Calendar.YEAR)
				+ " and MONTH(date) = " + (cal.get(Calendar.MONTH) + 1) + " and  type = "
				+ TransactionType.ACH.ordinal() + " and description like '%NEW YORK STATE%'";

		query = session.createQuery(INCOME_QUERY);

		List<BigDecimal> creditAmts = query.list();
		// BigDecimal withdrawal = query.getSingleResult();

		for (BigDecimal creditAmt : creditAmts) {

			if (creditAmt != null) {
				incomeBucket.setRemainingAmt(incomeBucket.getRemainingAmt().subtract(creditAmt));

			}
		}
		session.update(incomeBucket);
		///////////////////////////////////////////////////////////////////////////////////

		BudgetBucket gasBucket = new BudgetBucket(BucketCategory.GAS, BigDecimal.valueOf(100.00));
		session.save(gasBucket);
		// process food bucket//////////////////////////////////////////////////////////
		// Calendar cal = Calendar.getInstance();

		String GAS_QUERY = "SELECT deposit FROM BBTransaction bbT where YEAR(date) = " + cal.get(Calendar.YEAR)
				+ " and MONTH(date) = " + (cal.get(Calendar.MONTH) + 1) + " and  type = "
				+ TransactionType.VISA.ordinal() + " and description like '%EXXONMOBIL%' and withdrawal >= 10.00";

		query = session.createQuery(GAS_QUERY);

		List<BigDecimal> gasExpenderatures = query.list();
		// BigDecimal withdrawal = query.getSingleResult();

		for (BigDecimal gasExpenderature : gasExpenderatures) {

			if (gasExpenderature != null) {
				gasBucket.setRemainingAmt(gasBucket.getRemainingAmt().subtract(gasExpenderature));

			}
		}
		session.update(gasBucket);
		///////////////////////////////////////////////////////////////////////////////////

		session.getTransaction().commit();
		session.close();

		logger.info("Category: " + rentBucket.getCategory() + " :Remaining Amount: " + rentBucket.getRemainingAmt());
		logger.info("Category: " + foodBucket.getCategory() + " :Remaining Amount: " + foodBucket.getRemainingAmt());
		logger.info("Category: " + otherBucket.getCategory() + " :Remaining Amount: " + otherBucket.getRemainingAmt());
		logger.info("Category: " + phoneBucket.getCategory() + " :Remaining Amount: " + phoneBucket.getRemainingAmt());
		logger.info(
				"Category: " + incomeBucket.getCategory() + " :Remaining Amount: " + incomeBucket.getRemainingAmt());
		logger.info("Category: " + gasBucket.getCategory() + " :Remaining Amount: " + gasBucket.getRemainingAmt());
		System.exit(0);
	}

	/*
	 * 
	 * 
	 * // Read data BudgetBucket bucket = (BudgetBucket)
	 * session.get(BudgetBucket.class, 2); logger.debug(bucket.getCategory());
	 * 
	 * // Delete data // session.delete(bucket);
	 * 
	 * // Update data // bucket.setAmt(BigDecimal.valueOf(666.99));
	 * 
	 * 
	 * // session.update(bucket);
	 * 
	 * 
	 * // Query query = session.createQuery("from BudgetBucket where id > 5"); //
	 * List buckets = query.list();
	 * 
	 * // Query query = session.getNamedQuery("BudgetSheet.byId"); //
	 * query.setInteger(0, 1);
	 * 
	 * // BudgetBucket bucket3 = new BudgetBucket(); // bucket3 =
	 * (BudgetBucket)session.get(BudgetBucket.class, 1);
	 * 
	 */

}
