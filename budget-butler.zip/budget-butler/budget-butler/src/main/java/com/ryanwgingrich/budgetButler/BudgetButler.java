package com.ryanwgingrich.budgetButler;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.opencsv.CSVWriter;
import com.ryanwgingrich.budgetButler.dto.db.Account;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.dto.db.TransactionDescriptor;
import com.ryanwgingrich.budgetButler.enums.AccountType;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;
import com.ryanwgingrich.budgetButler.io.csvToBean.AmexTransaction;
import com.ryanwgingrich.budgetButler.io.csvToBean.ChaseTransaction;
import com.ryanwgingrich.budgetButler.io.csvToBean.CsvTransactionDescriptor;
import com.ryanwgingrich.budgetButler.io.csvToBean.SchwabTransaction;
import com.ryanwgingrich.budgetButler.parser.AmexTransactionParser;
import com.ryanwgingrich.budgetButler.parser.ChaseTransactionParser;
import com.ryanwgingrich.budgetButler.parser.CsvFileParser;
import com.ryanwgingrich.budgetButler.parser.CsvFileParserFactory;
import com.ryanwgingrich.budgetButler.parser.SchwabTransactionParser;
import com.ryanwgingrich.budgetButler.parser.TransactionDescriptorParser;
import com.ryanwgingrich.budgetButler.service.BucketService;

public class BudgetButler {

	private static Logger logger = LogManager.getLogger(BudgetButler.class.getName());
	private static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	private static String newLine = System.getProperty("line.separator");// This will retrieve line separator dependent
																			// on OS.

	public static void main(String[] args) throws IOException {

		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();

		

		/*****************************************************************************************
		 * Define the DEFAULT directory where to find .csv transaction files
		 *****************************************************************************************/
		String appDirectory = "/home/rgingrich/BudgetButler";
		/*****************************************************************************************
		******************************************************************************************
		*****************************************************************************************/

		File dir = new File(appDirectory);
		File[] directoryListing = dir.listFiles();

		if (directoryListing.length > 0) {

			int acctCounter = 0;

			Calendar curDate = Calendar.getInstance();
			
			session.beginTransaction();
			logger.info(session.getNamedQuery("DeleteTransactionDescriptors").executeUpdate());
			logger.info(session.getNamedQuery("DeleteAccounts").executeUpdate());
			logger.info(session.getNamedQuery("DeleteBudgetBuckets").executeUpdate());
			session.getTransaction().commit();

			List<BudgetBucket> bucketList = new ArrayList<BudgetBucket>();
			for (BucketCategory bucketCategory : BucketCategory.values()) {

				BudgetBucket budgetBucket = new BudgetBucket(bucketCategory, null, null);

				session.beginTransaction();
				session.save(budgetBucket);
				session.getTransaction().commit();

				bucketList.add(budgetBucket);

			}
			session.beginTransaction();
			logger.info(session.getNamedQuery("DeleteCurrentTransactions").setParameter("month", curDate.get(Calendar.MONTH))
			.setParameter("year", curDate.get(Calendar.YEAR)).executeUpdate());
			///	session.save(budgetBucket);
				session.getTransaction().commit();
			
			
			// Query query = session.createQuery("delete Stock where stockCode =
			// :stockCode");
			//query.setParameter("stockCode", "7277");
			//int result = query.executeUpdate();

			for (File child : directoryListing) {

				String fileName = child.getAbsolutePath();

				/*****************************************************************************************
				 * FILE PARSER FACTORY
				 *****************************************************************************************/
				CsvFileParser csvFileParser = new CsvFileParserFactory().getFileParser(fileName);

				/*****************************************************************************************
				******************************************************************************************
				*****************************************************************************************/

				/*****************************************************************************************
				 * TRANSACTION DESCRIPTOR FILE
				 *****************************************************************************************/
				session.beginTransaction();
				if (csvFileParser.getClass().equals(TransactionDescriptorParser.class)) {

					logger.info("Detected a transaction descriptor file: " + fileName);

					@SuppressWarnings("unchecked")
					List<CsvTransactionDescriptor> itemList = (List<CsvTransactionDescriptor>) csvFileParser
							.getItems(fileName, CsvTransactionDescriptor.class);

					for (CsvTransactionDescriptor descriptor : itemList) {

						session.save(new TransactionDescriptor(descriptor.getDescriptor(),
								BucketCategory.valueOf(descriptor.getBudgetBucket())));

					}

					/*****************************************************************************************
					******************************************************************************************
					*****************************************************************************************/

				}
				/*****************************************************************************************
				 * CHASE TRANSACTION FILE
				 *****************************************************************************************/
				else if (csvFileParser.getClass().equals(ChaseTransactionParser.class)) {
					logger.info("Detected a CHASE  file: " + fileName);

					acctCounter += 1;
					Account account = new Account(AccountType.CHASE_CREDIT.name() + acctCounter + acctCounter,
							fileName);
					List<Transaction> transactionList = new ArrayList<Transaction>();

					@SuppressWarnings("unchecked")
					List<ChaseTransaction> itemList = (List<ChaseTransaction>) csvFileParser.getItems(fileName,
							ChaseTransaction.class);

					for (ChaseTransaction t : itemList) {
						Calendar c = Calendar.getInstance();
						try {
							c.setTime(sdf.parse(t.getDate()));
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						 if (c.get(Calendar.MONTH) == Calendar.getInstance().get(Calendar.MONTH)
						 && c.get(Calendar.YEAR) == Calendar.getInstance().get(Calendar.YEAR)) {

						Transaction transaction = new Transaction(t.getDate(), t.getType(), t.getDescription(),
								t.getTransactionAmount());

						transaction.setCategory(categorizeTransaction(session, transaction));
						transactionList.add(transaction);

						session.save(transaction);
						 }

					}

					account.setTransactionList(transactionList);
					session.save(account);

					/*****************************************************************************************
					******************************************************************************************
					*****************************************************************************************/

				}
				/*****************************************************************************************
				 * SCHWAB TRANSACTION FILE
				 *****************************************************************************************/
				else if (csvFileParser.getClass().equals(SchwabTransactionParser.class)) {
					logger.info("Detected a SCHWAB  file: " + fileName);

					acctCounter += 1;
					Account account = new Account(AccountType.SCHWAB_BANK.name() + acctCounter, fileName);
					List<Transaction> transactionList = new ArrayList<Transaction>();

					@SuppressWarnings("unchecked")
					List<SchwabTransaction> itemList = (List<SchwabTransaction>) csvFileParser.getItems(fileName,
							SchwabTransaction.class);

					for (SchwabTransaction t : itemList) {
						Calendar c = Calendar.getInstance();
						try {
							c.setTime(sdf.parse(t.getDate()));
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						 if (c.get(Calendar.MONTH) == Calendar.getInstance().get(Calendar.MONTH)
						 && c.get(Calendar.YEAR) == Calendar.getInstance().get(Calendar.YEAR)) {

						String transactionAmt;

						if (t.getDeposit() != null)
							transactionAmt = t.getDeposit();

						else
							transactionAmt = t.getWithdrawal();

						Transaction transaction = new Transaction(t.getDate(), t.getType(), t.getCheckNum(),
								t.getDescription(), t.getRunningBalance(), transactionAmt);

						transaction.setCategory(categorizeTransaction(session, transaction));

						transactionList.add(transaction);

						session.save(transaction);

						 }
					}

					account.setTransactionList(transactionList);

					session.save(account);

					/*****************************************************************************************
					******************************************************************************************
					*****************************************************************************************/

				}
				/*****************************************************************************************
				 * AMEX TRANSACTION FILE
				 *****************************************************************************************/
				else if (csvFileParser.getClass().equals(AmexTransactionParser.class)) {
					logger.info("Detected a AMEX  file: " + fileName);

					acctCounter += 1;
					Account account = new Account(AccountType.AMEX_CREDIT.name() + acctCounter, fileName);
					List<Transaction> transactionList = new ArrayList<Transaction>();

					@SuppressWarnings("unchecked")
					List<AmexTransaction> itemList = (List<AmexTransaction>) csvFileParser.getItems(fileName,
							AmexTransaction.class);

					for (AmexTransaction t : itemList) {
						Calendar c = Calendar.getInstance();
						try {
							c.setTime(sdf.parse(t.getDate()));
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						 if (c.get(Calendar.MONTH) == Calendar.getInstance().get(Calendar.MONTH)
						 && c.get(Calendar.YEAR) == Calendar.getInstance().get(Calendar.YEAR)) {

						Transaction transaction = new Transaction(t.getDate(), "AMEX", t.getDescription(),
								t.getCardHolder(), t.getTransactionAmount());

						transaction.setCategory(categorizeTransaction(session, transaction));

						transactionList.add(transaction);

						session.save(transaction);
						 }
					}

					account.setTransactionList(transactionList);

					session.save(account);

					/*****************************************************************************************
					******************************************************************************************
					*****************************************************************************************/
				}
				session.getTransaction().commit();

			}
	//		System.out.println("Projected End Cash Balance: " + getprojectedEndCashAmt(session) + newLine);

			//System.out.println("Current Cash Balance: " + getCurrentCashAmt(session) + newLine);

			System.out.println(
					"********************************************************************************" + newLine);
			System.out.println(
					"*************************TRANSACTIONS******************************************" + newLine);
			System.out.println(
					"********************************************************************************" + newLine);

			for (BucketCategory bucketCategory : BucketCategory.values()) {

				System.out.println(bucketCategory.name() + newLine);
				// System.out.println("********************************************************************************"
				// + newLine);

				// BucketService bucketService = new BucketService();

				List<Transaction> transactionList = session.getNamedQuery("Transactions.byCategoryYearMonth")
						.setParameter("category", bucketCategory)
						.setParameter("year", Calendar.getInstance().get(Calendar.YEAR))
						.setParameter("month", Calendar.getInstance().get(Calendar.MONTH)).getResultList();

				for (Transaction t : transactionList) {
					
						System.out.println(bucketCategory.name() + " : " + t.getDate() + " : " + t.getDescription() + " : "
								+ t.getTransactionAmt() + newLine);
					

				}
			//	System.out.println(bucketCategory.name()+" : " + getprojectedEndCashAmt(session) + newLine);

			}

			// return (sumTransactionResult == null) ? BigDecimal.valueOf(0) :
			// sumTransactionResult;

			
			session.close();
			System.exit(0);

		} else

		{

			System.out.print("No files found in (" + appDirectory + ")...EXITING." + newLine);

			session.close();
			System.exit(0);
		}
	}

	private static BigDecimal getprojectedEndCashAmt(Session s) {

		// *****************************************************************************************
		// *****************************************************************************************/
		// /*****************************************************************************************
		// * Process Buckets
		// *****************************************************************************************/

		//
		BucketService bucketService = new BucketService();

		@SuppressWarnings("unchecked")
		List<BudgetBucket> bucketList = (List<BudgetBucket>) s.getNamedQuery("BudgetBuckets").getResultList();

		for (BudgetBucket bucket : bucketList) {

			// BigDecimal currentMonthTtl = bucketService.getMonthTtl(s,
			// bucket.getCategory(), date);
			bucketService.updateBucket(s, bucket, Calendar.getInstance(), Calendar.getInstance());

		}

		// projectedEndBalance = projectedEndBalance.add(currentCashBalance);
		BigDecimal projectedEndBalance = BigDecimal.valueOf(0);

		for (BucketCategory budgetCategory : BucketCategory.values()) {
			BudgetBucket b = (BudgetBucket) s.get(BudgetBucket.class, budgetCategory);
			if (budgetCategory == BucketCategory.INCOME) {
				projectedEndBalance = projectedEndBalance.add(b.getRemainingAmt());
			} else {
				projectedEndBalance = projectedEndBalance.subtract(b.getRemainingAmt());
			}
		}

		return projectedEndBalance;
	}

	public static BigDecimal getCurrentCashAmt(Session s) {
		//
		@SuppressWarnings("unchecked")
		List<Account> accountList = (List<Account>) s.getNamedQuery("Accounts").getResultList();
		//
		// // BigDecimal startCashBalance = BigDecimal.valueOf(0);
		BigDecimal currentCashBalance = BigDecimal.valueOf(0);
		// //
		for (Account account : accountList) {
			//
			if (!account.getAcctName().contains("CREDIT")) {
				//
				@SuppressWarnings("unchecked")
				List<Transaction> transactionList = (List<Transaction>) s.getNamedQuery("AccountTransactions.byId")
						.setParameter("id", account.getId()).getResultList();
				//
				if (transactionList.get(0).getRunningBal() != null) {
					currentCashBalance = currentCashBalance.add(transactionList.get(0).getRunningBal());
				}

			}
		}
		return currentCashBalance;

	}

	public static BucketCategory categorizeTransaction(Session session, Transaction t) throws IOException {

		String myDirectoryPath = "/home/rgingrich/BudgetButler";

		String descriptorString = t.getDescription().toUpperCase().replaceAll("[^A-Za-z]", "")
				.replaceAll("PAYPAL *", "").replaceAll("SAMPAY", "").replaceAll("THE", "")
				.replaceAll("SARATOGASPRINY", "").replaceAll("SARATOGASPRINGSNY", "").replaceAll("SARATOGASPGSNY", "")
				.replaceAll("ALBANYNY", "").replaceAll("LATHAMNY", "").replaceAll("MALTA NY", "")
				.replaceAll("CLIFTONPARKNY", "").replaceAll("SCOTIANY", "").replaceAll("GLENMONTNY", "")
				.replaceAll("SCHENECTADYNY", "").replaceAll("BURLINGTON", "").replaceAll("ALBANY", "")
				.replaceAll("MANCHESTERVT", "").replaceAll("MENANDSNY", "").replaceAll("SPRINGFIELDMA", "")
				.replaceAll("BALLSTONLAKENY", "").replaceAll("GLENVILLENY", "").replaceAll("GLENVILLE", "")
				.replaceAll("GREENWICHNY", "").replaceAll("BALLSTONSPANY", "").replaceAll("WILTON", "");

		if (t.getType().equals(TransactionType.TRANSFER)) {
			return BucketCategory.NONE;
		} else if (t.getType().equals(TransactionType.ATM)) {
			return BucketCategory.CASH;
		} else if (t.getType().equals(TransactionType.ATMREBATE) || t.getType().equals(TransactionType.INTADJUST)
				|| t.getType().equals(TransactionType.DEPOSIT) || descriptorString.contains("REGSALARY")
				|| descriptorString.contains("NEWYORKSTATEDIRDEP")) {
			return BucketCategory.INCOME;
		} else if (t.getType().equals(TransactionType.CHECK)
				&& t.getTransactionAmt().compareTo(BigDecimal.valueOf(995.00)) == 0) {
			return BucketCategory.RENT;
		} else if (descriptorString.contains("MCDONALDS") || descriptorString.contains("STARBUCKS")
				|| descriptorString.contains("PRICECHOPPER") || descriptorString.contains("DUNKIN")
				|| descriptorString.contains("MARKETBYPRICE") || descriptorString.contains("DAIRYCIRCUS")
				|| descriptorString.contains("HANNAFORD") || descriptorString.contains("SMASHBURGER")
				|| descriptorString.contains("BURGERKING") || descriptorString.contains("FRESHMARKET")
				|| descriptorString.contains("SHAKESHACK") || descriptorString.contains("SUBWAY")) {
			return BucketCategory.FOOD;
		}
		@SuppressWarnings("unchecked")
		List<BucketCategory> bucketCategoryList = (List<BucketCategory>) session.getNamedQuery("DescriptorBucketLookup")
				.setParameter("descriptor", descriptorString + t.getType()).getResultList();

		if (!bucketCategoryList.isEmpty())
			return bucketCategoryList.get(0);
		else {

			CSVWriter csvWriter = new CSVWriter(new FileWriter(myDirectoryPath + "/TransactionDescriptor.csv", true));

			System.out.println(sdf.format(t.getDate()) + " : " + t.getDescription() + " : " + t.getTransactionAmt()
					+ " : " + t.getType());
			System.out.println("Please enter category: ");

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

			BucketCategory bucketCategory = BucketCategory.valueOf(br.readLine());

			TransactionDescriptor descriptor = new TransactionDescriptor(descriptorString + t.getType(),
					bucketCategory);

			session.save(descriptor);

			String[] record = { descriptor.getDescriptor(), descriptor.getBudgetBucket().toString() };

			csvWriter.writeNext(record);

			csvWriter.close();

			return bucketCategory;
		}

	}

}

//
// /*****************************************************************************************
// *****************************************************************************************/
// /*****************************************************************************************
// * Get Start Cash Amount
// *****************************************************************************************/
//
// date = Calendar.getInstance();
//
// date.set(Calendar.MONTH, date.get(Calendar.MONTH) - 1);
//
// int id = 999999;
// Calendar date2 = Calendar.getInstance();
// for (Transaction t : transactionList) {
//
// date2.setTime(t.getDate());
//
// if (date2.get(Calendar.MONTH) == date.get(Calendar.MONTH)) {
//
// if (id > t.getId()) {
// id = t.getId();
// }
//
// }
//
// }
//
// Transaction t = session.get(Transaction.class, id);
// startCashBalance = startCashBalance.add(t.getRunningBal());
//
// }
// }
//
//
// /*****************************************************************************************
// *****************************************************************************************
// *
// *
// *

//
// /*****************************************************************************************
// *****************************************************************************************/
// System.out.println("Start Cash Balance:
// "+startCashBalance+newLine);System.out.println("Projected End Cash Balance:
// "+projectedEndBalance+newLine);
//
// for(
// Account account:accountList)
// {
//
// @SuppressWarnings("unchecked")
// List<Transaction> transactionList = (List<Transaction>)
// session.getNamedQuery("AccountTransactions.byId")
// .setParameter("id", account.getId()).getResultList();
//
// CSVWriter csvWriter = null;
// try {
// csvWriter = new CSVWriter(new FileWriter(appDirectory +
// "/TransactionReport.csv", true));
// } catch (IOException e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// }
//
// List<String[]> creditRecordList = new ArrayList<String[]>();
// List<String[]> debtRecordList = new ArrayList<String[]>();
//
// String[] reportRecord = null;
//
// for (Transaction t : transactionList) {
//
// if (t.getCategory().equals(BucketCategory.INCOME)) {
// String[] creditRecord = { null, t.getDate().toString(),
// t.getTransactionAmt().toString(),
// t.getDescription(), t.getCategory().toString() };
//
// creditRecordList.add(creditRecord);
//
// } else {
//
// String[] debtRecord = { null, t.getDate().toString(),
// t.getTransactionAmt().toString(),
// t.getDescription(), t.getCategory().toString() };
//
// debtRecordList.add(debtRecord);
// }
//
// }
//
// for (String[] debtRecord : debtRecordList) {
//
// reportRecord = debtRecord;
// csvWriter.writeNext(reportRecord);
//
// }
//
// for (String[] creditRecord : creditRecordList) {
//
// reportRecord = creditRecord;
// csvWriter.writeNext(reportRecord);
//
// }
//
// try {
// csvWriter.close();
// } catch (IOException e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// }
//
// }
//
// }
//
// }
