package com.ryanwgingrich.budgetButler;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.opencsv.bean.CsvToBeanBuilder;
import com.ryanwgingrich.budgetButler.dto.csv.SchwabTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BBTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.FinancialInstitutionCode;
import com.ryanwgingrich.budgetButler.enums.TransactionType;
import com.ryanwgingrich.budgetButler.factory.ParseFactory;
import com.ryanwgingrich.budgetButler.factory.Parser;

public class BudgetButler {

	private static Logger logger = LogManager.getLogger(BudgetButler.class.getName());
	private static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	private static String newLine = System.getProperty("line.separator");// This will retrieve line separator dependent
																			// on OS.

	public static void main(String[] args) throws IOException {

		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

		Calendar cal = Calendar.getInstance();
		Calendar maxDate = Calendar.getInstance();

		// TODO: Create UI to create BudgetBuckets
		BudgetBucket rentBucket = new BudgetBucket(BucketCategory.RENT, BigDecimal.valueOf(995));
		BudgetBucket foodBucket = new BudgetBucket(BucketCategory.FOOD, BigDecimal.valueOf(400));
		BudgetBucket incomeBucket = new BudgetBucket(BucketCategory.INCOME, BigDecimal.valueOf(0));
		
		List<BBTransaction> rentTransactions = null;

		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(rentBucket);
		session.save(foodBucket);
		session.save(foodBucket);
		session.getTransaction().commit();
		session.close();

		String myDirectoryPath = "/home/rgingrich/BudgetButler Transactions";

		File dir = new File(myDirectoryPath);
		File[] directoryListing = dir.listFiles();
		if (directoryListing != null) {

			FinancialInstitutionCode financialInstitutionCode = null;
			for (File child : directoryListing) {

				System.out.print("Found file: " + child.getAbsolutePath() + newLine);
				System.out.print("Please Enter Financial Institution Code: ");

				financialInstitutionCode = getFinancialInstitutionCode();

				Parser parser = new ParseFactory().getParser(financialInstitutionCode);

				session = sessionFactory.openSession();
				session.beginTransaction();

				switch (financialInstitutionCode) {
				case SCHWAB:
					List<SchwabTransaction> schwabTransactions = (List<SchwabTransaction>) parser
							.getTransactionList(child.getAbsolutePath());

					for (SchwabTransaction schwabTransaction : schwabTransactions) {

						session.save(new BBTransaction(schwabTransaction.getDate(), schwabTransaction.getType(),
								schwabTransaction.getDescription(), schwabTransaction.getCheckNum(),
								schwabTransaction.getDeposit(), schwabTransaction.getWithdrawal(),
								schwabTransaction.getRunningBalance()));
					}
					schwabTransactions.removeAll(schwabTransactions);

					break;
				case CHASE:

					break;
				case AMEX:

					break;
				case UFIRST:

					break;
				case CITI:

					break;
				default:

					break;
				}

				String MAX_DATE_QUERY = "select max(date) FROM BBTransaction";
				Query<Date> currentDateQuery = session.createQuery(MAX_DATE_QUERY);

				maxDate.setTime(currentDateQuery.getSingleResult());
				Integer month = maxDate.get(Calendar.MONTH);
				if (month == 0) {
					month = 12;
				}

				Integer year = maxDate.get(Calendar.YEAR);
				if (maxDate.get(Calendar.MONTH) == 0) {
					year = year - 1;
				}
				// process rent bucket//////////////////////////////////////////////////////////

				String RENT_QUERY = "FROM BBTransaction bbT where YEAR(date) = " + maxDate.get(Calendar.YEAR)
						+ " and MONTH(date) = " + (maxDate.get(Calendar.MONTH) + 1) + " and  withdrawal = "
						+ rentBucket.getAppropAmt() + " and type = " + TransactionType.CHECK.ordinal();

				Query<BBTransaction> rentTransactionQuery = session.createQuery(RENT_QUERY);

				rentTransactions = rentTransactionQuery.list();
				for (BBTransaction rentTransaction : rentTransactions) {

					Calendar cal2 = Calendar.getInstance();
					cal2.setTime(rentTransaction.getDate());

					if (rentTransaction.getType() == TransactionType.CHECK) {
						rentBucket.setRemainingAmt(rentBucket.getAppropAmt().subtract(rentTransaction.getWithdrawal()));
						if (rentBucket.getRemainingAmt()
								.equals(rentBucket.getAppropAmt().subtract(rentTransaction.getWithdrawal()))) {
							rentBucket.setBillPaid(true);
						}
					}

				}

				session.update(rentBucket);

				// logger.info("*********************************************************");

				// process rent bucket//////////////////////////////////////////////////////////
				/*
				 * List<String> foodDescList = new ArrayList(); foodDescList.add("DUNKIN");
				 * foodDescList.add("MCDONALD''S"); foodDescList.add("STAGECOACH");
				 * foodDescList.add("CAFE"); foodDescList.add("STEWARTS SHOP");
				 * foodDescList.add("CHIPOTLE"); foodDescList.add("PRIMAL");
				 * foodDescList.add("STEWARTS SHOP"); foodDescList.add("FARM");
				 * foodDescList.add("SUBWAY"); foodDescList.add("HANNAFORD");
				 * foodDescList.add("BREAD"); foodDescList.add("BURRITO");
				 * foodDescList.add("PIZZA");
				 * 
				 * for (String foodDesc : foodDescList) {
				 * 
				 * String FOOD_QUERY = "FROM BBTransaction bbT where YEAR(date) = " +
				 * maxDate.get(Calendar.YEAR) + " and MONTH(date) = " +
				 * (maxDate.get(Calendar.MONTH) + 1) + " and description like '%" + foodDesc +
				 * "%'" + " and type = " + TransactionType.VISA.ordinal();
				 * 
				 * Query foodQuery = session.createQuery(FOOD_QUERY); foodQuery =
				 * session.createQuery(FOOD_QUERY);
				 * 
				 * List<BBTransaction> foodTransactions = foodQuery.list();
				 * 
				 * String transactionMessage;
				 * 
				 * for (BBTransaction foodTransaction : foodTransactions) {
				 * 
				 * foodBucket.setRemainingAmt(
				 * foodBucket.getRemainingAmt().subtract(foodTransaction.getWithdrawal()));
				 * 
				 * // String billPaidMsg = " BILL DUE "; // if (foodBucket.getRemainingAmt()) {
				 * transactionMessage = sdf.format(foodTransaction.getDate()) + " * " +
				 * foodTransaction.getDescription() + " * " + "$" +
				 * foodTransaction.getWithdrawal(); // } logger.info("* " + transactionMessage +
				 * " *");
				 * 
				 * }
				 * 
				 * } logger.info("*********************************************************");
				 * logger.info("*                    " + foodBucket.getCategory() + " BUCKET $"
				 * + foodBucket.getRemainingAmt());
				 * logger.info("*********************************************************");
				 * logger.info("*********************************************************");
				 * logger.info("*********************************************************");
				 * session.update(foodBucket);
				 * 
				 * // process income //
				 * bucket//////////////////////////////////////////////////////////
				 * 
				 * String INCOME_QUERY = "FROM BBTransaction bbT where YEAR(date) = " +
				 * maxDate.get(Calendar.YEAR) + " and MONTH(date) = " +
				 * (maxDate.get(Calendar.MONTH) + 1) + " and deposit > 0 and type !=" +
				 * TransactionType.TRANSFER.ordinal();
				 * 
				 * Query incomeQuery = session.createQuery(INCOME_QUERY); incomeQuery =
				 * session.createQuery(INCOME_QUERY);
				 * 
				 * List<BBTransaction> incomeTransactions = incomeQuery.list();
				 * 
				 * String transactionMessage;
				 * 
				 * for (BBTransaction incomeTransaction : incomeTransactions) {
				 * 
				 * incomeBucket.setRemainingAmt(incomeBucket.getRemainingAmt().add(
				 * incomeTransaction.getDeposit()));
				 * 
				 * // String billPaidMsg = " BILL DUE "; // if (foodBucket.getRemainingAmt()) {
				 * transactionMessage = sdf.format(incomeTransaction.getDate()) + " * " +
				 * incomeTransaction.getDescription() + " * " + "$" +
				 * incomeTransaction.getDeposit(); // } logger.info("* " + transactionMessage +
				 * " *");
				 * 
				 * }
				 * 
				 * logger.info("*********************************************************");
				 * logger.info("*                    " + incomeBucket.getCategory() +
				 * " BUCKET $" + incomeBucket.getRemainingAmt());
				 * logger.info("*********************************************************");
				 * logger.info("*********************************************************");
				 * logger.info("*********************************************************");
				 * session.update(foodBucket);
				 * 
				 * /////////////////////////////////////////////////////////////////////////////
				 * ////// /* BudgetBucket otherBucket = new BudgetBucket(BucketCategory.OTHER,
				 * BigDecimal.valueOf(500)); session.save(otherBucket); // process food
				 * bucket////////////////////////////////////////////////////////// // Calendar
				 * cal = Calendar.getInstance();
				 * 
				 * String OTHER_QUERY =
				 * "SELECT withdrawal FROM BBTransaction bbT where YEAR(date) = " +
				 * cal.get(Calendar.YEAR) + " and MONTH(date) = " + (cal.get(Calendar.MONTH) +
				 * 1) + " and  (type = " + TransactionType.ATM.ordinal() +
				 * " or description like '%CAR WASH%' or description like '%UNDER ARMOUR%' or (description like '%EXXONMOBIL%' and withdrawal < 10.00))"
				 * ;
				 * 
				 * query = session.createQuery(OTHER_QUERY);
				 * 
				 * List<BigDecimal> otherExpenderatures = query.list(); // BigDecimal withdrawal
				 * = query.getSingleResult();
				 * 
				 * for (BigDecimal otherExpenderature : otherExpenderatures) {
				 * 
				 * if (otherExpenderature != null) {
				 * otherBucket.setRemainingAmt(otherBucket.getRemainingAmt().subtract(
				 * otherExpenderature));
				 * 
				 * } } session.update(otherBucket);
				 * /////////////////////////////////////////////////////////////////////////////
				 * //////
				 * 
				 * BudgetBucket phoneBucket = new BudgetBucket(BucketCategory.PHONE,
				 * BigDecimal.valueOf(200)); session.save(phoneBucket); // process food
				 * bucket////////////////////////////////////////////////////////// // Calendar
				 * cal = Calendar.getInstance();
				 * 
				 * String PHONE_QUERY =
				 * "SELECT withdrawal FROM BBTransaction bbT where YEAR(date) = " +
				 * cal.get(Calendar.YEAR) + " and MONTH(date) = " + (cal.get(Calendar.MONTH) +
				 * 1) + " and  type = " + TransactionType.TRANSFER.ordinal() +
				 * "and withdrawal = " + phoneBucket.getAppropAmt();
				 * 
				 * query = session.createQuery(PHONE_QUERY);
				 * 
				 * List<BigDecimal> phoneExpenderatures = query.list(); // BigDecimal withdrawal
				 * = query.getSingleResult();
				 * 
				 * for (BigDecimal phoneExpenderature : phoneExpenderatures) {
				 * 
				 * if (phoneExpenderature != null) {
				 * phoneBucket.setRemainingAmt(phoneBucket.getRemainingAmt().subtract(
				 * phoneExpenderature));
				 * 
				 * } } session.update(otherBucket);
				 * /////////////////////////////////////////////////////////////////////////////
				 * //////
				 * 
				 * BudgetBucket incomeBucket = new BudgetBucket(BucketCategory.INCOME,
				 * BigDecimal.valueOf(3684)); session.save(incomeBucket); // process food
				 * bucket////////////////////////////////////////////////////////// // Calendar
				 * cal = Calendar.getInstance();
				 * 
				 * String INCOME_QUERY =
				 * "SELECT deposit FROM BBTransaction bbT where YEAR(date) = " +
				 * cal.get(Calendar.YEAR) + " and MONTH(date) = " + (cal.get(Calendar.MONTH) +
				 * 1) + " and  type = " + TransactionType.ACH.ordinal() +
				 * " and description like '%NEW YORK STATE%'";
				 * 
				 * query = session.createQuery(INCOME_QUERY);
				 * 
				 * List<BigDecimal> creditAmts = query.list(); // BigDecimal withdrawal =
				 * query.getSingleResult();
				 * 
				 * for (BigDecimal creditAmt : creditAmts) {
				 * 
				 * if (creditAmt != null) {
				 * incomeBucket.setRemainingAmt(incomeBucket.getRemainingAmt().subtract(
				 * creditAmt));
				 * 
				 * } } session.update(incomeBucket);
				 * /////////////////////////////////////////////////////////////////////////////
				 * //////
				 * 
				 * BudgetBucket gasBucket = new BudgetBucket(BucketCategory.GAS,
				 * BigDecimal.valueOf(100.00)); session.save(gasBucket); // process food
				 * bucket////////////////////////////////////////////////////////// // Calendar
				 * cal = Calendar.getInstance();
				 * 
				 * String GAS_QUERY =
				 * "SELECT deposit FROM BBTransaction bbT where YEAR(date) = " +
				 * cal.get(Calendar.YEAR) + " and MONTH(date) = " + (cal.get(Calendar.MONTH) +
				 * 1) + " and  type = " + TransactionType.VISA.ordinal() +
				 * " and description like '%EXXONMOBIL%' and withdrawal >= 10.00";
				 * 
				 * query = session.createQuery(GAS_QUERY);
				 * 
				 * List<BigDecimal> gasExpenderatures = query.list(); // BigDecimal withdrawal =
				 * query.getSingleResult();
				 * 
				 * for (BigDecimal gasExpenderature : gasExpenderatures) {
				 * 
				 * if (gasExpenderature != null) {
				 * gasBucket.setRemainingAmt(gasBucket.getRemainingAmt().subtract(
				 * gasExpenderature));
				 * 
				 * } } session.update(gasBucket);
				 * /////////////////////////////////////////////////////////////////////////////
				 * //////
				 */
				session.getTransaction().commit();
				session.close();

				// logger.info("*****Bucket Category: " + rentBucket.getCategory() + "*****");
				// ::::Is Bill Paid?: " + rentBucket.isBillPaid());

				// logger.info("Category: " + foodBucket.getCategory() + " :Remaining Amount: "
				// + foodBucket.getRemainingAmt());
				// logger.info("Category: " + otherBucket.getCategory() + " :Remaining Amount: "
				// + otherBucket.getRemainingAmt());
				// logger.info("Category: " + phoneBucket.getCategory() + " :Remaining Amount: "
				// + phoneBucket.getRemainingAmt());
				// logger.info("Category: " + incomeBucket.getCategory() + " :Remaining Amount:
				// " + incomeBucket.getRemainingAmt());
				// logger.info("Category: " + gasBucket.getCategory() + " :Remaining Amount: " +
				// gasBucket.getRemainingAmt());
				// } catch (IllegalArgumentException badFinancialInstitutionCodeException) {
				// System.out.print("INVALID Financial Institution Code"+newLine);
				// System.out.print("Please Enter one of the following Financial Institution
				// Codes: "+newLine);
				// for(FinancialInstitutionCode fiCode : FinancialInstitutionCode.values()) {
				// System.out.print(fiCode.toString()+newLine);
				// }
				//
				// System.exit(0);
				// System.out.print("Please Enter Financial Institution Code: ");

				// financialInstitutionCode = FinancialInstitutionCode.valueOf(br.readLine());

				// }
			}
			String billPaidMsg = "                  " + rentBucket.getCategory() + " BILL DUE                         ";
			if (rentBucket.isBillPaid()) {
				billPaidMsg = sdf.format(rentTransactions.get(0).getDate()) + " * "
						+ rentTransactions.get(0).getDescription() + "                        * $"
						+ rentTransactions.get(0).getWithdrawal();
			}
			logger.info("* " + billPaidMsg + " *");
			logger.info("*********************************************************");
			logger.info(
					"*                    " + rentBucket.getCategory() + " BUCKET $" + rentBucket.getRemainingAmt());
			logger.info("*********************************************************");
			logger.info("*********************************************************");
		} else {
			// Handle the case where dir is not really a directory.
			// Checking dir.isDirectory() above would not be sufficient
			// to avoid race conditions with another process that deletes
			// directories.
			System.exit(0);
		}

		System.exit(0);

	}

	/*
	 * 
	 * 
	 * // Read data BudgetBucket bucket = (BudgetBucket)
	 * session.get(BudgetBucket.class, 2); logger.debug(bucket.getCategory());
	 * 
	 * // Delete data // session.delete(bucket);
	 * 
	 * // Update data // bucket.setAmt(BigDecimal.valueOf(666.99));
	 * 
	 * 
	 * // session.update(bucket);
	 * 
	 * 
	 * // Query query = session.createQuery("from BudgetBucket where id > 5"); //
	 * List buckets = query.list();
	 * 
	 * // Query query = session.getNamedQuery("BudgetSheet.byId"); //
	 * query.setInteger(0, 1);
	 * 
	 * // BudgetBucket bucket3 = new BudgetBucket(); // bucket3 =
	 * (BudgetBucket)session.get(BudgetBucket.class, 1);
	 * 
	 */

	private static FinancialInstitutionCode getFinancialInstitutionCode() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		try {
			return FinancialInstitutionCode.valueOf(br.readLine());
		} catch (IllegalArgumentException badFinancialInstitutionCodeExceptione) {
			System.out.print("INVALID Financial Institution Code" + newLine);

			for (FinancialInstitutionCode fiCode : FinancialInstitutionCode.values()) {
				System.out.print(fiCode.toString() + newLine);
			}
			// badFinancialInstitutionCodeExceptione.printStackTrace();
			System.out.print("Please Enter one of the listed Financial Institution Codes: " + newLine);
			return getFinancialInstitutionCode();

		}

	}

}
