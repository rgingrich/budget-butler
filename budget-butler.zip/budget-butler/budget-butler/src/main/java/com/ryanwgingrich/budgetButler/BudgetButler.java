package com.ryanwgingrich.budgetButler;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.io.FileNotFoundException;
import java.io.FileReader;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.opencsv.bean.CsvToBeanBuilder;
import com.ryanwgingrich.budgetButler.dto.csv.CSVTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BBTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

public class BudgetButler {

	// TODO: create Factory design pattern to get appropiate FileReader i.e.
	// SchwabFileReader, AmexFileREader, etc...

	private static Logger logger = LogManager.getLogger(BudgetButler.class.getName());

	private static String csvFileName = "/home/rgingrich/Software Development/eclipse-workspace/budget-butler/budget-butler/Ryans_Checking_Checking_Transactions_20180131-215803.CSV";
	private static String DATE_FORMAT = "MM/dd/yyyy";
	private static SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);

	public static void main(String[] args) throws FileNotFoundException {

		// String fileName = "/home/rgingrich/Software
		// Development/eclipse-workspace/budget-butler/budget-butler/Ryans_Checking_Checking_Transactions_20180131-124749.CSV";
		FileReader fileReader = new FileReader(csvFileName);

		List<CSVTransaction> csvTransactions = new CsvToBeanBuilder<CSVTransaction>(fileReader)
				.withType(CSVTransaction.class).build().parse();

		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		for (CSVTransaction csvTransaction : csvTransactions) {

			session.save(new BBTransaction(csvTransaction.getDate(), csvTransaction.getType(),
					csvTransaction.getDescription(), csvTransaction.getCheckNum(), csvTransaction.getDeposit(),
					csvTransaction.getWithdrawal(), csvTransaction.getRunningBalance()));
		}
		csvTransactions.removeAll(csvTransactions);

		Calendar cal = Calendar.getInstance();

		BudgetBucket rentBucket = new BudgetBucket(BucketCategory.RENT, BigDecimal.valueOf(995));
		session.save(rentBucket);

		BudgetBucket foodBucket = new BudgetBucket(BucketCategory.FOOD, BigDecimal.valueOf(400));
		session.save(foodBucket);
		
		BudgetBucket incomeBucket = new BudgetBucket(BucketCategory.INCOME, BigDecimal.valueOf(0));
		session.save(foodBucket);

		Calendar maxDate = Calendar.getInstance();

		String MAX_DATE_QUERY = "select max(date) FROM BBTransaction";
		Query<Date> currentDateQuery = session.createQuery(MAX_DATE_QUERY);

		maxDate.setTime(currentDateQuery.getSingleResult());
		Integer month = maxDate.get(Calendar.MONTH);
		if (month == 0) {
			month = 12;
		}

		Integer year = maxDate.get(Calendar.YEAR);
		if (maxDate.get(Calendar.MONTH) == 0) {
			year = year - 1;
		}
		// process rent bucket//////////////////////////////////////////////////////////

		String RENT_QUERY = "FROM BBTransaction bbT where YEAR(date) = " + maxDate.get(Calendar.YEAR)
				+ " and MONTH(date) = " + (maxDate.get(Calendar.MONTH) + 1) + " and  withdrawal = "
				+ rentBucket.getAppropAmt() + " and type = " + TransactionType.CHECK.ordinal();

		

		Query<BBTransaction> rentTransactionQuery = session.createQuery(RENT_QUERY);
		
		List<BBTransaction> rentTransactions = rentTransactionQuery.list();
		for (BBTransaction rentTransaction : rentTransactions) {

			Calendar cal2 = Calendar.getInstance();
			cal2.setTime(rentTransaction.getDate());

			if (rentTransaction.getType() == TransactionType.CHECK) {
				rentBucket.setRemainingAmt(rentBucket.getAppropAmt().subtract(rentTransaction.getWithdrawal()));
				if (rentBucket.getRemainingAmt()
						.equals(rentBucket.getAppropAmt().subtract(rentTransaction.getWithdrawal()))) {
					rentBucket.setBillPaid(true);
				}
			}

		}

		session.update(rentBucket);
		String billPaidMsg = "                    BILL DUE                         ";
		if (rentBucket.isBillPaid()) {
			billPaidMsg = sdf.format(rentTransactions.get(0).getDate()) + " * "
					+ rentTransactions.get(0).getDescription() + "                        * $"
					+ rentTransactions.get(0).getWithdrawal();
		}
		logger.info("* " + billPaidMsg + " *");
		logger.info("*********************************************************");
		logger.info("*                    " + rentBucket.getCategory() + " BUCKET $" + rentBucket.getRemainingAmt());
		logger.info("*********************************************************");

		logger.info("*********************************************************");
		logger.info("*********************************************************");

		// process rent bucket//////////////////////////////////////////////////////////

		List<String> foodDescList = new ArrayList();
		foodDescList.add("DUNKIN");
		foodDescList.add("MCDONALD''S");
		foodDescList.add("STAGECOACH");
		foodDescList.add("CAFE");
		foodDescList.add("STEWARTS SHOP");
		foodDescList.add("CHIPOTLE");
		foodDescList.add("PRIMAL");
		foodDescList.add("STEWARTS SHOP");
		foodDescList.add("FARM");
		foodDescList.add("SUBWAY");
		foodDescList.add("HANNAFORD");
		foodDescList.add("BREAD");
		foodDescList.add("BURRITO");
		foodDescList.add("PIZZA");

		for (String foodDesc : foodDescList) {

			String FOOD_QUERY = "FROM BBTransaction bbT where YEAR(date) = " + maxDate.get(Calendar.YEAR)
					+ " and MONTH(date) = " + (maxDate.get(Calendar.MONTH) + 1) + " and description like '%" + foodDesc
					+ "%'" + " and type = " + TransactionType.VISA.ordinal();

			Query foodQuery = session.createQuery(FOOD_QUERY);
			foodQuery = session.createQuery(FOOD_QUERY);

			List<BBTransaction> foodTransactions = foodQuery.list();

			String transactionMessage;

			for (BBTransaction foodTransaction : foodTransactions) {

				foodBucket.setRemainingAmt(foodBucket.getRemainingAmt().subtract(foodTransaction.getWithdrawal()));

				// String billPaidMsg = " BILL DUE ";
				// if (foodBucket.getRemainingAmt()) {
				transactionMessage = sdf.format(foodTransaction.getDate()) + " * " + foodTransaction.getDescription()
						+ " * " + "$" + foodTransaction.getWithdrawal();
				// }
				logger.info("* " + transactionMessage + " *");

			}

		}
		logger.info("*********************************************************");
		logger.info("*                    " + foodBucket.getCategory() + " BUCKET $" + foodBucket.getRemainingAmt());
		logger.info("*********************************************************");
		logger.info("*********************************************************");
		logger.info("*********************************************************");
		session.update(foodBucket);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		// process income bucket//////////////////////////////////////////////////////////

		String INCOME_QUERY = "FROM BBTransaction bbT where YEAR(date) = " + maxDate.get(Calendar.YEAR)
							+ " and MONTH(date) = " + (maxDate.get(Calendar.MONTH) + 1) + " and deposit > 0 and type !=" +TransactionType.TRANSFER.ordinal();

					Query incomeQuery = session.createQuery(INCOME_QUERY);
					incomeQuery = session.createQuery(INCOME_QUERY);

					List<BBTransaction> incomeTransactions = incomeQuery.list();

					String transactionMessage;

					for (BBTransaction incomeTransaction : incomeTransactions) {

						incomeBucket.setRemainingAmt(incomeBucket.getRemainingAmt().add(incomeTransaction.getDeposit()));

						// String billPaidMsg = " BILL DUE ";
						// if (foodBucket.getRemainingAmt()) {
						transactionMessage = sdf.format(incomeTransaction.getDate()) + " * " + incomeTransaction.getDescription()
								+ " * " + "$" + incomeTransaction.getDeposit();
						// }
						logger.info("* " + transactionMessage + " *");

					}

				logger.info("*********************************************************");
				logger.info("*                    " + incomeBucket.getCategory() + " BUCKET $" + incomeBucket.getRemainingAmt());
				logger.info("*********************************************************");
				logger.info("*********************************************************");
				logger.info("*********************************************************");
				session.update(foodBucket);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

		/////////////////////////////////////////////////////////////////////////////
		//////
		/*
		 * BudgetBucket otherBucket = new BudgetBucket(BucketCategory.OTHER,
		 * BigDecimal.valueOf(500)); session.save(otherBucket); // process food
		 * bucket////////////////////////////////////////////////////////// // Calendar
		 * cal = Calendar.getInstance();
		 * 
		 * String OTHER_QUERY =
		 * "SELECT withdrawal FROM BBTransaction bbT where YEAR(date) = " +
		 * cal.get(Calendar.YEAR) + " and MONTH(date) = " + (cal.get(Calendar.MONTH) +
		 * 1) + " and  (type = " + TransactionType.ATM.ordinal() +
		 * " or description like '%CAR WASH%' or description like '%UNDER ARMOUR%' or (description like '%EXXONMOBIL%' and withdrawal < 10.00))"
		 * ;
		 * 
		 * query = session.createQuery(OTHER_QUERY);
		 * 
		 * List<BigDecimal> otherExpenderatures = query.list(); // BigDecimal withdrawal
		 * = query.getSingleResult();
		 * 
		 * for (BigDecimal otherExpenderature : otherExpenderatures) {
		 * 
		 * if (otherExpenderature != null) {
		 * otherBucket.setRemainingAmt(otherBucket.getRemainingAmt().subtract(
		 * otherExpenderature));
		 * 
		 * } } session.update(otherBucket);
		 * /////////////////////////////////////////////////////////////////////////////
		 * //////
		 * 
		 * BudgetBucket phoneBucket = new BudgetBucket(BucketCategory.PHONE,
		 * BigDecimal.valueOf(200)); session.save(phoneBucket); // process food
		 * bucket////////////////////////////////////////////////////////// // Calendar
		 * cal = Calendar.getInstance();
		 * 
		 * String PHONE_QUERY =
		 * "SELECT withdrawal FROM BBTransaction bbT where YEAR(date) = " +
		 * cal.get(Calendar.YEAR) + " and MONTH(date) = " + (cal.get(Calendar.MONTH) +
		 * 1) + " and  type = " + TransactionType.TRANSFER.ordinal() +
		 * "and withdrawal = " + phoneBucket.getAppropAmt();
		 * 
		 * query = session.createQuery(PHONE_QUERY);
		 * 
		 * List<BigDecimal> phoneExpenderatures = query.list(); // BigDecimal withdrawal
		 * = query.getSingleResult();
		 * 
		 * for (BigDecimal phoneExpenderature : phoneExpenderatures) {
		 * 
		 * if (phoneExpenderature != null) {
		 * phoneBucket.setRemainingAmt(phoneBucket.getRemainingAmt().subtract(
		 * phoneExpenderature));
		 * 
		 * } } session.update(otherBucket);
		 * /////////////////////////////////////////////////////////////////////////////
		 * //////
		 * 
		 * BudgetBucket incomeBucket = new BudgetBucket(BucketCategory.INCOME,
		 * BigDecimal.valueOf(3684)); session.save(incomeBucket); // process food
		 * bucket////////////////////////////////////////////////////////// // Calendar
		 * cal = Calendar.getInstance();
		 * 
		 * String INCOME_QUERY =
		 * "SELECT deposit FROM BBTransaction bbT where YEAR(date) = " +
		 * cal.get(Calendar.YEAR) + " and MONTH(date) = " + (cal.get(Calendar.MONTH) +
		 * 1) + " and  type = " + TransactionType.ACH.ordinal() +
		 * " and description like '%NEW YORK STATE%'";
		 * 
		 * query = session.createQuery(INCOME_QUERY);
		 * 
		 * List<BigDecimal> creditAmts = query.list(); // BigDecimal withdrawal =
		 * query.getSingleResult();
		 * 
		 * for (BigDecimal creditAmt : creditAmts) {
		 * 
		 * if (creditAmt != null) {
		 * incomeBucket.setRemainingAmt(incomeBucket.getRemainingAmt().subtract(
		 * creditAmt));
		 * 
		 * } } session.update(incomeBucket);
		 * /////////////////////////////////////////////////////////////////////////////
		 * //////
		 * 
		 * BudgetBucket gasBucket = new BudgetBucket(BucketCategory.GAS,
		 * BigDecimal.valueOf(100.00)); session.save(gasBucket); // process food
		 * bucket////////////////////////////////////////////////////////// // Calendar
		 * cal = Calendar.getInstance();
		 * 
		 * String GAS_QUERY =
		 * "SELECT deposit FROM BBTransaction bbT where YEAR(date) = " +
		 * cal.get(Calendar.YEAR) + " and MONTH(date) = " + (cal.get(Calendar.MONTH) +
		 * 1) + " and  type = " + TransactionType.VISA.ordinal() +
		 * " and description like '%EXXONMOBIL%' and withdrawal >= 10.00";
		 * 
		 * query = session.createQuery(GAS_QUERY);
		 * 
		 * List<BigDecimal> gasExpenderatures = query.list(); // BigDecimal withdrawal =
		 * query.getSingleResult();
		 * 
		 * for (BigDecimal gasExpenderature : gasExpenderatures) {
		 * 
		 * if (gasExpenderature != null) {
		 * gasBucket.setRemainingAmt(gasBucket.getRemainingAmt().subtract(
		 * gasExpenderature));
		 * 
		 * } } session.update(gasBucket);
		 * /////////////////////////////////////////////////////////////////////////////
		 * //////
		 */
		session.getTransaction().commit();
		session.close();

		// logger.info("*****Bucket Category: " + rentBucket.getCategory() + "*****");
		// ::::Is Bill Paid?: " + rentBucket.isBillPaid());

		// logger.info("Category: " + foodBucket.getCategory() + " :Remaining Amount: "
		// + foodBucket.getRemainingAmt());
		// logger.info("Category: " + otherBucket.getCategory() + " :Remaining Amount: "
		// + otherBucket.getRemainingAmt());
		// logger.info("Category: " + phoneBucket.getCategory() + " :Remaining Amount: "
		// + phoneBucket.getRemainingAmt());
		// logger.info("Category: " + incomeBucket.getCategory() + " :Remaining Amount:
		// " + incomeBucket.getRemainingAmt());
		// logger.info("Category: " + gasBucket.getCategory() + " :Remaining Amount: " +
		// gasBucket.getRemainingAmt());
		System.exit(0);
	}

	/*
	 * 
	 * 
	 * // Read data BudgetBucket bucket = (BudgetBucket)
	 * session.get(BudgetBucket.class, 2); logger.debug(bucket.getCategory());
	 * 
	 * // Delete data // session.delete(bucket);
	 * 
	 * // Update data // bucket.setAmt(BigDecimal.valueOf(666.99));
	 * 
	 * 
	 * // session.update(bucket);
	 * 
	 * 
	 * // Query query = session.createQuery("from BudgetBucket where id > 5"); //
	 * List buckets = query.list();
	 * 
	 * // Query query = session.getNamedQuery("BudgetSheet.byId"); //
	 * query.setInteger(0, 1);
	 * 
	 * // BudgetBucket bucket3 = new BudgetBucket(); // bucket3 =
	 * (BudgetBucket)session.get(BudgetBucket.class, 1);
	 * 
	 */

}
