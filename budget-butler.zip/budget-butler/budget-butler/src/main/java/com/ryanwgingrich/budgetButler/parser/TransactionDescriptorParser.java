package com.ryanwgingrich.budgetButler.parser;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import org.hibernate.Session;

import com.opencsv.bean.CsvToBeanBuilder;
import com.ryanwgingrich.budgetButler.dto.db.Account;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.enums.TransactionType;
import com.ryanwgingrich.budgetButler.io.csvToBean.CsvTransactionDescriptor;
import com.ryanwgingrich.budgetButler.io.csvToBean.SchwabTransaction;

public class TransactionDescriptorParser extends CsvFileParser {

	///@Override
	//public List<CsvTransactionDescriptor> getItems(String fileName, String itemClass) throws FileNotFoundException {

		//
		// FileReader fileReader = new FileReader(fileName);
		//
		// CsvToBeanBuilder<itemClass> csvToBeanBuilder = new
		// CsvToBeanBuilder<SchwabTransaction>(fileReader)
		// .withType(SchwabTransaction.class).withSkipLines(1);
		//
		// List<SchwabTransaction> schwabTransactions = (List<SchwabTransaction>)
		// csvToBeanBuilder.build().parse();
		//
		// ListIterator<SchwabTransaction> schwabIterator =
		// schwabTransactions.listIterator();
		//
		// SchwabTransaction schwabTransaction;
		// while (schwabIterator.hasNext()) {
		// schwabTransaction = (SchwabTransaction) schwabIterator.next();
		// if (schwabTransaction.getDate().equalsIgnoreCase("Posted Transactions")) {
		// schwabIterator.remove();
		// } else if (schwabTransaction.getDate().equalsIgnoreCase("Pending
		// Transactions")) {
		// schwabIterator.remove();
		// } else if (schwabTransaction.getDate().equalsIgnoreCase("Total Pending Check
		// and other Credit(s)")) {
		// schwabIterator.remove();
		// }
		//
		// if (schwabTransaction.getType() == null) {
		// schwabTransaction.setType(TransactionType.PENDING.toString());
		//
		// }
		// }
		//
		// return schwabTransactions;
		// }

	//}

	@Override
	public List<CsvTransactionDescriptor> getItems(String fileName, Class itemClass) throws FileNotFoundException {

		
		
		FileReader fileReader = new FileReader(fileName);
		
				CsvToBeanBuilder<CsvTransactionDescriptor> csvToBeanBuilder = new CsvToBeanBuilder<CsvTransactionDescriptor>(fileReader).withType(itemClass);
		
				List<CsvTransactionDescriptor> itemList = csvToBeanBuilder.build().parse();
		
				
				
				return itemList;
	}

	

}
