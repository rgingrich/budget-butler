package com.ryanwgingrich.budgetButler.dto.db;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.CollectionTable;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.NamedQuery;

@Entity
//@NamedQuery(name="BudgetSheet.byId", query="from BudgetSheet where id = ?")
public class BudgetSheet {
	
	@Id @GeneratedValue
	private int id;
	
	
	@ElementCollection
    private Collection<BudgetBucket> lisOfBudgetBuckets = new ArrayList<BudgetBucket>();
	//private List<BudgetBucket> budgetBucketList;
	private Date startDate;
	private Date endDate;
	private BigDecimal startAmt;
	private BigDecimal endAmt;
	private BigDecimal ttlFixedAmt;
	private BigDecimal ttlVariableAmt;
	private BigDecimal ttlIncomeAmt;
	private BigDecimal ttlAvailAmt;
	

	public BudgetSheet() {
		// TODO Auto-generated constructor stub
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Collection<BudgetBucket> getLisOfBudgetBuckets() {
		return lisOfBudgetBuckets;
	}

	public void setLisOfBudgetBuckets(Collection<BudgetBucket> lisOfBudgetBuckets) {
		this.lisOfBudgetBuckets = lisOfBudgetBuckets;
	}


	public Date getStartDate() {
		return startDate;
	}


	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}


	public Date getEndDate() {
		return endDate;
	}


	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}


	public BigDecimal getStartAmt() {
		return startAmt;
	}


	public void setStartAmt(BigDecimal startAmt) {
		this.startAmt = startAmt;
	}


	public BigDecimal getEndAmt() {
		return endAmt;
	}


	public void setEndAmt(BigDecimal endAmt) {
		this.endAmt = endAmt;
	}


	public BigDecimal getTtlFixedAmt() {
		return ttlFixedAmt;
	}


	public void setTtlFixedAmt(BigDecimal ttlFixedAmt) {
		this.ttlFixedAmt = ttlFixedAmt;
	}


	public BigDecimal getTtlVariableAmt() {
		return ttlVariableAmt;
	}


	public void setTtlVariableAmt(BigDecimal ttlVariableAmt) {
		this.ttlVariableAmt = ttlVariableAmt;
	}


	public BigDecimal getTtlIncomeAmt() {
		return ttlIncomeAmt;
	}


	public void setTtlIncomeAmt(BigDecimal ttlIncomeAmt) {
		this.ttlIncomeAmt = ttlIncomeAmt;
	}


	public BigDecimal getTtlAvailAmt() {
		return ttlAvailAmt;
	}


	public void setTtlAvailAmt(BigDecimal ttlAvailAmt) {
		this.ttlAvailAmt = ttlAvailAmt;
	}
	

}
