package com.ryanwgingrich.budgetButler.dto.cvs;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.opencsv.bean.CsvBindByName;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

public class CsvTransaction {

	public CsvTransaction() {
	}

	@CsvBindByName(column = "Date", required = true)
	private String date;

	@CsvBindByName(column = "Type", required = true)
	private String type;

	@CsvBindByName(column = "Check #", required = false)
	private int checkNum;

	@CsvBindByName(column = "Description", required = true)
	private String Description;

	@CsvBindByName(column = "Withdrawal (-)", required = false)
	private String withdrawal;

	@CsvBindByName(column = "Deposit (+)", required = false)
	private String deposit;

	@CsvBindByName(column = "RunningBalance", required = true)
	private String runningBalance;

	public String getDate() {
		return date;
	}

	public String getType() {
		return type;
	}

	public int getCheckNum() {
		return checkNum;
	}

	public String getDescription() {
		return Description;
	}

	public String getWithdrawal() {
		return withdrawal;
	}

	public String getDeposit() {
		return deposit;
	}

	public String getRunningBalance() {
		return runningBalance;
	}

	public void setDate(String date) {
		this.date = date;
	}
	//public void setDate(String date) throws ParseException {
	//	DateFormat format = new SimpleDateFormat("mm/dd/yyyy", Locale.ENGLISH);
	//	this.date = format.parse(date);
	//}

	public void setType(String type) {
		//for (TransactionType tType : TransactionType.values()) {
		    //System.out.println(tType);
		//	if (type == tType.name()) {
				this.type = type;				
			//}
		//}
		
		
	}
	//public void setType(TransactionType type) {
	//	this.type = type;
	//}

	public void setCheckNum(int checkNum) {
		this.checkNum = checkNum;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public void setWithdrawal(String withdrawal) {
		this.withdrawal = withdrawal;
	}

	public void setDeposit(String deposit) {
		this.deposit = deposit;
	}

	public void setRunningBalance(String runningBalance) {
		this.runningBalance = runningBalance;
	}
	
	

}
