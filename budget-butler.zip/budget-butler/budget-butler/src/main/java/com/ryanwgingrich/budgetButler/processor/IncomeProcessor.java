package com.ryanwgingrich.budgetButler.processor;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Calendar;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.query.Query;

import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

public class IncomeProcessor implements Processor {

	@Override
	public void processTransactions(BudgetBucket rentBucket, Session session) {
		// TODO Auto-generated method stub

	}

	@Override
	public BigDecimal getCurrentMonthTtl(BudgetBucket rentBucket, Session session) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BigDecimal getPrevYearMonthlyTtl(BudgetBucket rentBucket, Session session) {

		Calendar maxDate = getMaxDate(session);
		int maxMonth = maxDate.get(Calendar.MONTH);
		int maxYear = maxDate.get(Calendar.YEAR);

		BigDecimal prevYearMonthlytotalIncome = new BigDecimal(0);

		Query<BigDecimal> prevYearMonthlyTtlQuery = session
				.createQuery("SELECT SUM(case when type in (" + TransactionType.AMEX.ordinal() + ") "
						+ "and transactionAmt < 0 then abs(transactionAmt) else transactionAmt end) "
						+ "FROM BBTransaction where category = " + BucketCategory.INCOME.ordinal()
						+ " and YEAR(date) = " + (maxYear - 1) + " and MONTH(date) = " + (maxMonth + 1));
		// add 1 to the Calendar.get(MONTH) to compare to DB date

		prevYearMonthlytotalIncome = (BigDecimal) prevYearMonthlyTtlQuery.getSingleResult();

		BigDecimal prevYearTotalIncome = new BigDecimal(0);

		Query<BigDecimal> prevYearTtlQuery = session
				.createQuery("SELECT SUM(case when type in (" + TransactionType.AMEX.ordinal() + ") "
						+ "and transactionAmt < 0 then abs(transactionAmt) else transactionAmt end) "
						+ "FROM BBTransaction where category = " + BucketCategory.INCOME.ordinal()
						+ " and YEAR(date) = " + (maxYear - 1));
		// add 1 to the Calendar.get(MONTH) to compare to DB date

		prevYearTotalIncome = (BigDecimal) prevYearTtlQuery.getSingleResult();

		BigDecimal prevYearAvgMonthlyTtl = BigDecimal.valueOf(0);

		//MathContext mc = null;
		//mc.UNLIMITED;
		prevYearAvgMonthlyTtl = prevYearTotalIncome.divide(BigDecimal.valueOf(12.00),2,RoundingMode.HALF_UP);

		if (prevYearMonthlytotalIncome.compareTo(prevYearAvgMonthlyTtl) >= 0) {

			return prevYearMonthlytotalIncome;

		} else {
			return prevYearAvgMonthlyTtl;
		}

	}

	private Calendar getMinDate(Session session) {
		Calendar minDate = Calendar.getInstance();
		String MIN_DATE_QUERY = "select min(date) FROM BBTransaction";
		Query<Date> query = session.createQuery(MIN_DATE_QUERY);
		minDate.setTime(query.getSingleResult());

		return minDate;

	}

	private Calendar getMaxDate(Session session) {

		Calendar maxDate = Calendar.getInstance();
		String MAX_DATE_QUERY = "select max(date) FROM BBTransaction";
		Query<Date> query = session.createQuery(MAX_DATE_QUERY);
		maxDate.setTime(query.getSingleResult());

		return maxDate;
	}

}
