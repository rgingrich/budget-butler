package com.ryanwgingrich.budgetButler.processor;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Calendar;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.query.Query;

import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

public class IncomeProcessor implements Processor {

	@Override
	public BigDecimal getMonthTtl(Session session, BucketCategory category, Calendar date) {

		int month = date.get(Calendar.MONTH);
		int year = date.get(Calendar.YEAR);

		return (BigDecimal) session.getNamedQuery("SumTransactions.byCategoryYearMonth")
				.setParameter("category", category)
				.setParameter("year", year)
				.setParameter("month", month)
				.getSingleResult();

	}

	@Override
	public BigDecimal getYearTtl(Session session, BucketCategory category, Calendar date) {

		int year = date.get(Calendar.YEAR);

		return (BigDecimal) session.getNamedQuery("SumTransactions.byCategoryYear")
				.setParameter("category", category).setParameter("year", year).getSingleResult();

	}

	@Override
	public void updateBucket(Session session, BudgetBucket bucket, Calendar date) {

		BigDecimal totalAmt = getMonthTtl(session, bucket.getCategory(), date);

		bucket.setRemainingAmt(bucket.getAppropAmt().subtract(totalAmt));

	}

}
