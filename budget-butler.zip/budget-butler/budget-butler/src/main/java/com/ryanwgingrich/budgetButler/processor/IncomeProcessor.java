package com.ryanwgingrich.budgetButler.processor;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Calendar;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.query.Query;

import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

public class IncomeProcessor implements Processor {

	@Override
	public BigDecimal getMonthTtl(BudgetBucket rentBucket, Session session, Calendar date) {
		//Calendar maxDate = getMaxDate(session);
		int month = date.get(Calendar.MONTH);
		int year = date.get(Calendar.YEAR);

		
		Query<BigDecimal> query = session
				.createQuery("SELECT SUM(case when type in (" + TransactionType.AMEX.ordinal() + ") "
						+ "and transactionAmt < 0 then abs(transactionAmt) else transactionAmt end) "
						+ "FROM BBTransaction where category = " + BucketCategory.INCOME.ordinal()
						+ " and YEAR(date) = " + year + " and MONTH(date) = " + (month + 1));
		// add 1 to the Calendar.get(MONTH) to compare to DB date

		BigDecimal currentMonthTtl = (BigDecimal) query.getSingleResult();

		return currentMonthTtl;

	}

	@Override
	public BigDecimal getYearTtl(BudgetBucket rentBucket, Session session, Calendar date) {
		//Calendar maxDate = getMaxDate(session);
				int year = date.get(Calendar.YEAR);

				
				Query<BigDecimal> query = session
						.createQuery("SELECT SUM(case when type in (" + TransactionType.AMEX.ordinal() + ") "
								+ "and transactionAmt < 0 then abs(transactionAmt) else transactionAmt end) "
								+ "FROM BBTransaction where category = " + BucketCategory.INCOME.ordinal()
								+ " and YEAR(date) = " + year);
				// add 1 to the Calendar.get(MONTH) to compare to DB date

				BigDecimal currentMonthTtl = (BigDecimal) query.getSingleResult();

				return currentMonthTtl;
	}

	@Override
	public void updateBucket(Session session, BudgetBucket bucket, Calendar date) {
		
		
		
		
		
		Query<BigDecimal> query = session
				.createQuery("SELECT SUM(case when type in (" + TransactionType.AMEX.ordinal() + ") "
						+ "and transactionAmt < 0 then abs(transactionAmt) else transactionAmt end) "
						+ "FROM BBTransaction where category = " + BucketCategory.INCOME.ordinal()
						+ " and YEAR(date) = " + date.get(Calendar.YEAR) + " and MONTH(date) = " + (date.get(Calendar.MONTH) + 1));
		// add 1 to the Calendar.get(MONTH) to compare to DB date

		BigDecimal totalAmt = (BigDecimal) query.getSingleResult();
		
		
	
		bucket.setRemainingAmt(bucket.getAppropAmt().subtract(totalAmt));
		
		
		

		
		
		
		
		
		
	}

	


}
