package com.ryanwgingrich.budgetButler.dto.db;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.annotations.NamedQuery;

import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

@Entity
// @NamedQuery(name = "SumTransactions.byCategoryYearMonth", query = "SELECT
// SUM(" + "case "
// + "when type in (9) and transactionAmt < 0 "// TransactionType.AMEX(9)
// + "then abs(transactionAmt) " + "else transactionAmt end) " + "FROM
// BBTransaction "
// + "where category = :category and YEAR(date) = :year and MONTH(date) = :month
// +1")
//
// @NamedQuery(name = "SumTransactions.byCategoryYear", query = "SELECT SUM(" +
// "case "
// + "when type in (9) and transactionAmt < 0 "// TransactionType.AMEX(9)
// + "then abs(transactionAmt) " + "else transactionAmt end) " + "FROM
// BBTransaction "
// + "where category = :category and YEAR(date) = :year")
//
// @NamedQuery(name = "Transactions.byCategoryYearMonth", query = "FROM
// BBTransaction "
// + "where category = :category and YEAR(date) = :year and MONTH(date) = :month
// +1")
//
// @NamedQuery(name = "Transactions.byYearMonth", query = "FROM BBTransaction "
// + "where YEAR(date) = :year and MONTH(date) = :month +1")
//
// @NamedQuery(name = "Transactions", query = "FROM BBTransaction")

@Embeddable
public class BBBudget {
	static Logger logger = LogManager.getLogger(BBBudget.class.getName());

	// DateFormat format = new SimpleDateFormat("mm/dd/yyyy", Locale.ENGLISH);
	String DATE_FORMAT = "MM/dd/yyyy";
	SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);

	@Id
	@GeneratedValue
	private int id;
	private Calendar date;
	@ElementCollection
	private Collection<BudgetBucket> bucketList = new ArrayList<BudgetBucket>();
	private BigDecimal totalIncomeAmt;
	private BigDecimal totalAmtSpent;
	private BigDecimal availableAmt;
	private BigDecimal bufferAmt;
	private BigDecimal startCashAmt;
	private BigDecimal endCashAmt;

	public BBBudget() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Calendar getDate() {
		return date;
	}

	public Collection<BudgetBucket> getBucketList() {
		return bucketList;
	}

	public BigDecimal getTotalIncomeAmt() {
		return totalIncomeAmt;
	}

	public BigDecimal getTotalAmtSpent() {
		return totalAmtSpent;
	}

	public BigDecimal getAvailableAmt() {
		return availableAmt;
	}

	public BigDecimal getBufferAmt() {
		return bufferAmt;
	}

	public BigDecimal getStartCashAmt() {
		return startCashAmt;
	}

	public BigDecimal getEndCashAmt() {
		return endCashAmt;
	}

	public void setDate(Calendar date2) {
		this.date = date2;
	}

	public void setBucketList(Collection<BudgetBucket> bucketList) {
		this.bucketList = bucketList;
	}

	public void setTotalIncomeAmt(BigDecimal totalIncomeAmt) {
		this.totalIncomeAmt = totalIncomeAmt;
	}

	public void setTotalAmtSpent(BigDecimal totalAmtSpent) {
		this.totalAmtSpent = totalAmtSpent;
	}

	public void setAvailableAmt(BigDecimal availableAmt) {
		this.availableAmt = availableAmt;
	}

	public void setBufferAmt(BigDecimal bufferAmt) {
		this.bufferAmt = bufferAmt;
	}

	public void setStartCashAmt(BigDecimal startCashAmt) {
		this.startCashAmt = startCashAmt;
	}

	public void setEndCashAmt(BigDecimal endCashAmt) {
		this.endCashAmt = endCashAmt;
	}
	

}
