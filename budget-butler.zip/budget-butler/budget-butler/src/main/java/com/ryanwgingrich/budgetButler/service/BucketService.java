package com.ryanwgingrich.budgetButler.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.hibernate.Session;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.AccountType;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;

public final class BucketService {

	private static final BucketService INSTANCE = new BucketService();

	private BucketService() {
	}

	public static BucketService getInstance() {
		return INSTANCE;
	}

	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	static DBService dbS = DBService.getInstance();

	public BigDecimal getYearTtl(Session session, BucketCategory category, Calendar date) {
		int year = date.get(Calendar.YEAR);

		return (BigDecimal) session.getNamedQuery("SumTransactions.byCategoryYear").setParameter("category", category)
				.setParameter("year", year).getSingleResult();
	}

	public static BigDecimal appropiate(BudgetBucket budgetBucket) {

		BucketCategory bucketCategory = budgetBucket.getCategory();

		int budgetMonth = Integer.valueOf(String.valueOf(budgetBucket.getId()).substring(4, 6));
		int budgetYear = Integer.valueOf(String.valueOf(budgetBucket.getId()).substring(0, 4));

		int nonZeroMonthCounter = 0;
		BigDecimal totalAmt = BigDecimal.valueOf(0);
		BigDecimal prevMonthTotalAmt = BigDecimal.valueOf(0);
		BigDecimal prevYearTotalAmt = BigDecimal.valueOf(0);
		BigDecimal avgAmt = BigDecimal.valueOf(0);

		prevYearTotalAmt = getMonthTtlAmt(bucketCategory, budgetMonth, budgetYear - 1);

		if (!prevYearTotalAmt.equals(BigDecimal.valueOf(0))) {
			nonZeroMonthCounter += 1;
			totalAmt = totalAmt.add(prevYearTotalAmt);
		}

		budgetYear = (budgetMonth - 1 == 0 ? budgetYear - 1 : budgetYear);
		budgetMonth = (budgetMonth - 1 == 0 ? 12 : budgetMonth - 1);

		prevMonthTotalAmt = getMonthTtlAmt(bucketCategory, budgetMonth, budgetYear);

		if (!prevMonthTotalAmt.equals(BigDecimal.valueOf(0))) {
			nonZeroMonthCounter += 1;
			totalAmt = totalAmt.add(prevMonthTotalAmt);
		}

		if (nonZeroMonthCounter > 0) {
			avgAmt = totalAmt.divide(BigDecimal.valueOf(nonZeroMonthCounter), RoundingMode.HALF_UP);
		}

		return avgAmt;

	}

	public static BigDecimal getCreditMonthTtlAmt(BucketCategory category, int month, int year) {
		BigDecimal sumTransactionResult = (BigDecimal) dbS.getSession()
				.getNamedQuery("SumCreditTransactions.byCategoryYearMonth").setParameter("category", category)
				.setParameter("year", year).setParameter("month", month)
				.setParameter("accountType", AccountType.SCHWAB_CASH).getSingleResult();

		return (sumTransactionResult == null) ? BigDecimal.valueOf(0) : sumTransactionResult;
	}

	public static BigDecimal getCashMonthTtlAmt(BucketCategory category, int month, int year) {

		BigDecimal sumTransactionResult = (BigDecimal) dbS.getSession()
				.getNamedQuery("SumCashTransactions.byCategoryYearMonth").setParameter("category", category)
				.setParameter("year", year).setParameter("month", month)
				.setParameter("accountType", AccountType.SCHWAB_CASH).getSingleResult();

		return (sumTransactionResult == null) ? BigDecimal.valueOf(0) : sumTransactionResult;

	}

	public static BigDecimal getMonthTtlAmt(BucketCategory category, int month, int year) {

		BigDecimal sumTransactionResult = (BigDecimal) dbS.getSession()
				.getNamedQuery("SumTransactions.byCategoryYearMonth").setParameter("category", category)
				.setParameter("year", year).setParameter("month", month).getSingleResult();

		return (sumTransactionResult == null) ? BigDecimal.valueOf(0) : sumTransactionResult;

	}

	public static BigDecimal getRemainingAmt(BudgetBucket bucket) {

		BigDecimal appropiationAmt = bucket.getAppropiationAmt();
		BigDecimal monthTtlAmt = getMonthTtlAmt(bucket.getCategory(),
				Integer.valueOf(String.valueOf(bucket.getId()).substring(4, 6)),
				Integer.valueOf(String.valueOf(bucket.getId()).substring(0, 4)));

		return appropiationAmt.subtract(monthTtlAmt);
	}

}
