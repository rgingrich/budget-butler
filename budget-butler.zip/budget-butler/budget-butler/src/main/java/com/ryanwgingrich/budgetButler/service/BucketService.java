package com.ryanwgingrich.budgetButler.service;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.cfgxml.spi.CfgXmlAccessService;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.dto.db.Account;
import com.ryanwgingrich.budgetButler.dto.db.Budget;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.AccountType;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

public final class BucketService {

	private static final BucketService INSTANCE = new BucketService();

	private BucketService() {
	}

	public static BucketService getInstance() {
		return INSTANCE;
	}

	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	static DBService dbS = DBService.getInstance();
	private static String newLine = System.getProperty("line.separator");// This will retrieve line separator dependent
//
//	public void processBuckets(int month, int year) {
//
//		BudgetBucket budgetBucket = null;
//		BigDecimal prevYearmonthTotalAmt = null;
//
//		for (BucketCategory c : BucketCategory.values()) {
//			budgetBucket = dbS.getSession().get(BudgetBucket.class, c);
//
//			prevYearmonthTotalAmt = getMonthTtl(c, Calendar.getInstance().get(Calendar.MONTH),
//					(Calendar.getInstance().get(Calendar.YEAR) - 1));
//
//			int monthCounter = 0;
//			int nonZeroMonthCounter = 0;
//			BigDecimal totalAmt = BigDecimal.valueOf(0);
//			BigDecimal monthTotalAmt = BigDecimal.valueOf(0);
//			BigDecimal avgAmt = BigDecimal.valueOf(0);
//
//			if (c == BucketCategory.BUFFER) {
//
//				monthTotalAmt = getMonthTtl(BucketCategory.INCOME, (Calendar.getInstance().get(Calendar.MONTH) - 1),
//						Calendar.getInstance().get(Calendar.YEAR));
//				totalAmt = (monthTotalAmt == null) ? BigDecimal.valueOf(0) : monthTotalAmt;
//				budgetBucket.setAppropiationAmt(totalAmt);
//
//				// BigDecimal remainingAmt =
//				// budgetBucket.getAppropAmt().subtract(getCurrentCashAmt(s));
//				budgetBucket.setRemainingAmt(
//						budgetBucket.getAppropiationAmt().subtract(getCurrentCashAmt()).compareTo(BigDecimal.valueOf(0)) < 0
//								? BigDecimal.valueOf(0)
//								: budgetBucket.getAppropiationAmt().subtract(getCurrentCashAmt()));
//
//			} else {
//
//				while (monthCounter < 18) {
//					monthCounter += 1;
//
//					monthTotalAmt = getMonthTtl(c, ((Calendar.getInstance().get(Calendar.MONTH) - monthCounter)),
//							Calendar.getInstance().get(Calendar.YEAR));
//
//					if (monthTotalAmt == null || monthTotalAmt.equals(BigDecimal.valueOf(0))) {
//						monthTotalAmt = BigDecimal.valueOf(0);
//
//					} else {
//
//						nonZeroMonthCounter += 1;
//						totalAmt = totalAmt.add(monthTotalAmt);
//
//						System.out.println(c.name() + ": " + (Calendar.getInstance().get(Calendar.MONTH) - monthCounter)
//								+ " Ttl Amt:" + monthTotalAmt + newLine);
//					}
//
//				}
//
//				if (nonZeroMonthCounter > 0) {
//					avgAmt = totalAmt.divide(BigDecimal.valueOf(nonZeroMonthCounter), RoundingMode.HALF_UP);
//				}
//
//				// Determine Appropiation Amt:
//
//				// if (prevYearmonthTotalAmt.compareTo(avgAmt) > 0) {
//				// budgetBucket.setAppropAmt(prevYearmonthTotalAmt);
//				// } else
//				budgetBucket.setAppropiationAmt(avgAmt);
//
//				monthTotalAmt = getMonthTtl(c, Calendar.getInstance().get(Calendar.MONTH),
//						Calendar.getInstance().get(Calendar.YEAR));
//				totalAmt = (monthTotalAmt == null) ? BigDecimal.valueOf(0) : monthTotalAmt;
//
//				budgetBucket.setRemainingAmt(budgetBucket.getAppropiationAmt().subtract(totalAmt));
//			}
//			@SuppressWarnings("unchecked")
//			List<Transaction> transactionList = (List<Transaction>) dbS.getSession()
//					.getNamedQuery("Transactions.byCategoryYearMonth")
//					.setParameter("category", budgetBucket.getCategory())
//					.setParameter("year", Calendar.getInstance().get(Calendar.YEAR))
//					.setParameter("month", Calendar.getInstance().get(Calendar.MONTH)).getResultList();
//
//			budgetBucket.setTransactionList(transactionList);
//
//			dbS.save(budgetBucket);
//
//		}
//
//	}
//
//	public void updateBucket(Session s, BudgetBucket bucket, Calendar curDate) {
//
//		BigDecimal prevYearmonthTotalAmt = getMonthTtl(bucket.getCategory(), curDate.get(Calendar.MONTH),
//				(curDate.get(Calendar.YEAR) - 1));
//
//		int monthCounter = 0;
//		int nonZeroMonthCounter = 0;
//		BigDecimal totalAmt = BigDecimal.valueOf(0);
//		BigDecimal monthTotalAmt = BigDecimal.valueOf(0);
//		BigDecimal avgAmt = BigDecimal.valueOf(0);
//
//		if (bucket.getCategory() == BucketCategory.BUFFER) {
//
//			monthTotalAmt = getMonthTtl(BucketCategory.INCOME, (curDate.get(Calendar.MONTH) - 1),
//					curDate.get(Calendar.YEAR));
//			totalAmt = (monthTotalAmt == null) ? BigDecimal.valueOf(0) : monthTotalAmt;
//			bucket.setAppropiationAmt(totalAmt);
//
//			// BigDecimal remainingAmt =
//			// bucket.getAppropAmt().subtract(getCurrentCashAmt(s));
//			bucket.setRemainingAmt(
//					bucket.getAppropiationAmt().subtract(getCurrentCashAmt()).compareTo(BigDecimal.valueOf(0)) < 0
//							? BigDecimal.valueOf(0)
//							: bucket.getAppropiationAmt().subtract(getCurrentCashAmt()));
//
//		} else {
//
//			while (monthCounter < 3) {
//				monthCounter += 1;
//
//				monthTotalAmt = getMonthTtl(bucket.getCategory(), ((curDate.get(Calendar.MONTH) - monthCounter)),
//						Calendar.getInstance().get(Calendar.YEAR));
//
//				if (monthTotalAmt == null || monthTotalAmt.equals(BigDecimal.valueOf(0))) {
//					monthTotalAmt = BigDecimal.valueOf(0);
//
//				} else {
//
//					nonZeroMonthCounter += 1;
//					totalAmt = totalAmt.add(monthTotalAmt);
//				}
//
//			}
//
//			if (nonZeroMonthCounter > 0) {
//				avgAmt = totalAmt.divide(BigDecimal.valueOf(nonZeroMonthCounter), RoundingMode.HALF_UP);
//			}
//
//			// Determine Appropiation Amt:
//
//			if (prevYearmonthTotalAmt.compareTo(avgAmt) > 0) {
//				bucket.setAppropiationAmt(prevYearmonthTotalAmt);
//			} else
//				bucket.setAppropiationAmt(avgAmt);
//
//			monthTotalAmt = getMonthTtl(bucket.getCategory(), curDate.get(Calendar.MONTH),
//					Calendar.getInstance().get(Calendar.YEAR));
//			totalAmt = (monthTotalAmt == null) ? BigDecimal.valueOf(0) : monthTotalAmt;
//
//			bucket.setRemainingAmt(bucket.getAppropiationAmt().subtract(totalAmt));
//		}
//		@SuppressWarnings("unchecked")
//		List<Transaction> transactionList = (List<Transaction>) s.getNamedQuery("Transactions.byCategoryYearMonth")
//				.setParameter("category", bucket.getCategory()).setParameter("year", curDate.get(Calendar.YEAR))
//				.setParameter("month", curDate.get(Calendar.MONTH)).getResultList();
//
//		bucket.setTransactionList(transactionList);
//
//		s.beginTransaction();
//		s.save("BudgetBucket", bucket);
//		s.getTransaction().commit();
//	}

	public BigDecimal getYearTtl(Session session, BucketCategory category, Calendar date) {
		int year = date.get(Calendar.YEAR);

		return (BigDecimal) session.getNamedQuery("SumTransactions.byCategoryYear").setParameter("category", category)
				.setParameter("year", year).getSingleResult();
	}

	public static BigDecimal appropiate(BudgetBucket budgetBucket) {

		BucketCategory bucketCategory = budgetBucket.getCategory();

		// System.out.println(String.valueOf(budgetBucket.getId()).substring(4, 6) +
		// newLine);

		int budgetMonth = Integer.valueOf(String.valueOf(budgetBucket.getId()).substring(4, 6));
		int budgetYear = Integer.valueOf(String.valueOf(budgetBucket.getId()).substring(0, 4));

		// BigDecimal prevYearmonthTotalAmt = getMonthTtl(bucketCategory, budgetMonth,
		// budgetYear);

		int nonZeroMonthCounter = 0;
		BigDecimal totalAmt = BigDecimal.valueOf(0);
		BigDecimal prevMonthTotalAmt = BigDecimal.valueOf(0);
		BigDecimal prevYearTotalAmt = BigDecimal.valueOf(0);
		BigDecimal avgAmt = BigDecimal.valueOf(0);

		// for (int monthCounter = 1; monthCounter < 12; monthCounter++) {

		prevYearTotalAmt = getMonthTtlAmt(bucketCategory, budgetMonth, budgetYear - 1);

		if (!prevYearTotalAmt.equals(BigDecimal.valueOf(0))) {
			nonZeroMonthCounter += 1;
			totalAmt = totalAmt.add(prevYearTotalAmt);
		}

		budgetYear = (budgetMonth - 1 == 0 ? budgetYear - 1 : budgetYear);
		budgetMonth = (budgetMonth - 1 == 0 ? 12 : budgetMonth - 1);

		prevMonthTotalAmt = getMonthTtlAmt(bucketCategory, budgetMonth, budgetYear);

		if (!prevMonthTotalAmt.equals(BigDecimal.valueOf(0))) {
			nonZeroMonthCounter += 1;
			totalAmt = totalAmt.add(prevMonthTotalAmt);
		}

		if (nonZeroMonthCounter > 0) {
			avgAmt = totalAmt.divide(BigDecimal.valueOf(nonZeroMonthCounter), RoundingMode.HALF_UP);
		}

		return avgAmt;

	}

	public static BigDecimal getCreditMonthTtlAmt(BucketCategory category, int month, int year) {
		BigDecimal sumTransactionResult = (BigDecimal) dbS.getSession()
				.getNamedQuery("SumCreditTransactions.byCategoryYearMonth").setParameter("category", category)
				.setParameter("year", year).setParameter("month", month)
				.setParameter("accountType", AccountType.SCHWAB_CASH).getSingleResult();

		return (sumTransactionResult == null) ? BigDecimal.valueOf(0) : sumTransactionResult;
	}

	public static BigDecimal getCashMonthTtlAmt(BucketCategory category, int month, int year) {

		BigDecimal sumTransactionResult = (BigDecimal) dbS.getSession()
				.getNamedQuery("SumCashTransactions.byCategoryYearMonth").setParameter("category", category)
				.setParameter("year", year).setParameter("month", month)
				.setParameter("accountType", AccountType.SCHWAB_CASH).getSingleResult();

		return (sumTransactionResult == null) ? BigDecimal.valueOf(0) : sumTransactionResult;

	}
	
	@SuppressWarnings("unchecked")
	public static BigDecimal getprojectedEndCashAmt(int month, int year) {
		BigDecimal projectedEndBalance = getCurrentCashAmt(Calendar.getInstance().get(Calendar.MONTH) + 1,
				Calendar.getInstance().get(Calendar.YEAR));

		for (BudgetBucket b : (List<BudgetBucket>) DBService.getInstance().getSession().getNamedQuery("BudgetBuckets")
				.getResultList()) {

			if (!(b.getCategory() == BucketCategory.NONE || b.getCategory() == BucketCategory.BUFFER
					|| b.getRemainingAmt().compareTo(BigDecimal.valueOf(0)) < 0)) {

				if (b.getCategory() == BucketCategory.INCOME) {
					projectedEndBalance = projectedEndBalance.add(b.getRemainingAmt());
				} else {
					projectedEndBalance = projectedEndBalance.subtract(b.getRemainingAmt());

				}
			}
		}

		return projectedEndBalance;
	}

	public static BigDecimal getMonthTtlAmt(BucketCategory category, int month, int year) {

		BigDecimal sumTransactionResult = (BigDecimal) dbS.getSession()
				.getNamedQuery("SumTransactions.byCategoryYearMonth").setParameter("category", category)
				.setParameter("year", year).setParameter("month", month).getSingleResult();

		return (sumTransactionResult == null) ? BigDecimal.valueOf(0) : sumTransactionResult;

	}

	public static BigDecimal getRemainingAmt(BudgetBucket bucket) {

		BigDecimal appropiationAmt = bucket.getAppropiationAmt();
		BigDecimal monthTtlAmt = getMonthTtlAmt(bucket.getCategory(),
				Integer.valueOf(String.valueOf(bucket.getId()).substring(4, 6)),
				Integer.valueOf(String.valueOf(bucket.getId()).substring(0, 4)));

		return appropiationAmt.subtract(monthTtlAmt);
	}

}
