package com.ryanwgingrich.budgetButler.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

public class BucketService {

	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

	public BigDecimal getMonthTtl(Session s, BucketCategory category, int month, int year) {
		// int month = date.get(Calendar.MONTH);
		// int year = date.get(Calendar.YEAR);

		BigDecimal sumTransactionResult = (BigDecimal) s.getNamedQuery("SumTransactions.byCategoryYearMonth")
				.setParameter("category", category).setParameter("year", year).setParameter("month", month)
				.getSingleResult();

		return (sumTransactionResult == null) ? BigDecimal.valueOf(0) : sumTransactionResult;

	}

	public void updateBucket(Session s, BudgetBucket bucket, Calendar startDate, Calendar endDate) {

		
		
		// prevYearmonthTotalAmt = BigDecimal.valueOf(0);

		// startDate.set(Calendar.YEAR, (startDate.get(Calendar.YEAR) - 1));
		BigDecimal prevYearmonthTotalAmt = getMonthTtl(s, bucket.getCategory(), endDate.get(Calendar.MONTH),
				endDate.get(Calendar.YEAR) - 1);

		// date.set(Calendar.MONTH, (date.get(Calendar.YEAR) + 1));

		int monthCounter = 0;
		int nonZeroMonthCounter = 0;
		BigDecimal totalAmt = BigDecimal.valueOf(0);
		BigDecimal monthTotalAmt = BigDecimal.valueOf(0);
		BigDecimal avgAmt = BigDecimal.valueOf(0);
		
		while (monthCounter < 3) {
			monthCounter += 1;

			// date.set(Calendar.MONTH, (date.get(Calendar.MONTH) - 1));

			monthTotalAmt = getMonthTtl(s, bucket.getCategory(), endDate.get(Calendar.MONTH),
					endDate.get(Calendar.YEAR));

			if (monthTotalAmt == null || monthTotalAmt.equals(BigDecimal.valueOf(0))) {
				monthTotalAmt = BigDecimal.valueOf(0);

			} else {

				nonZeroMonthCounter += 1;
				totalAmt = totalAmt.add(monthTotalAmt);
			}

		}

		if (nonZeroMonthCounter > 0) {
			avgAmt = totalAmt.divide(BigDecimal.valueOf(nonZeroMonthCounter));
		}

		// Determine Appropiation Amt:
		// - Get last 3 months average bucket approp amt (non zero)
		// - Get last year's current month

		// if last year current month = 0 use, 0
		// otherwise, use larger of the 2 values

		if (prevYearmonthTotalAmt.compareTo(BigDecimal.valueOf(0)) == 0 || prevYearmonthTotalAmt.compareTo(avgAmt) > 0    ) {
			bucket.setAppropAmt(prevYearmonthTotalAmt);
		} else
			bucket.setAppropAmt(avgAmt);
		
		
		//

//		if (bucket.getCategory().equals(BucketCategory.INCOME) || bucket.getLimitAmt().compareTo(totalAmt) > 0)
//			bucket.setAppropAmt(totalAmt);
//		else
//			bucket.setAppropAmt(bucket.getLimitAmt());

		//date.set(Calendar.MONTH, date.get(Calendar.MONTH) + 1);
		monthTotalAmt = getMonthTtl(s, bucket.getCategory(), endDate.get(Calendar.MONTH),
				endDate.get(Calendar.YEAR));
	//	if (totalAmt == null) {
		//	totalAmt = BigDecimal.valueOf(0);
			totalAmt = (totalAmt == null) ? BigDecimal.valueOf(0) : totalAmt;


		//}
		bucket.setRemainingAmt(bucket.getAppropAmt().subtract(totalAmt));
		
		
		if (bucket.getRemainingAmt().negate().compareTo(BigDecimal.valueOf(0)) > 0) {
			bucket.setRemainingAmt(BigDecimal.valueOf(0));
		}

		@SuppressWarnings("unchecked")
		List<Transaction> transactionList = (List<Transaction>) s
				.getNamedQuery("Transactions.byCategoryYearMonth").setParameter("category", bucket.getCategory())
				.setParameter("year", endDate.get(Calendar.YEAR)).setParameter("month", endDate.get(Calendar.MONTH))
				.getResultList();

		bucket.setTransactionList(transactionList);

		s.beginTransaction();
		s.save("BudgetBucket", bucket);
		s.getTransaction().commit();
	}

	public BigDecimal getYearTtl(Session session, BucketCategory category, Calendar date) {
		int year = date.get(Calendar.YEAR);

		return (BigDecimal) session.getNamedQuery("SumTransactions.byCategoryYear").setParameter("category", category)
				.setParameter("year", year).getSingleResult();
	}

}
