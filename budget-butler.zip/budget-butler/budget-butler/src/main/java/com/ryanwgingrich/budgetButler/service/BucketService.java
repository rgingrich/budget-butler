package com.ryanwgingrich.budgetButler.service;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.dto.db.Account;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

public class BucketService {

	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	DBService dbS = DBService.getInstance();

	public BigDecimal getMonthTtl(Session s, BucketCategory category, int month, int year) {

		BigDecimal sumTransactionResult = (BigDecimal) s.getNamedQuery("SumTransactions.byCategoryYearMonth")
				.setParameter("category", category).setParameter("year", year).setParameter("month", month)
				.getSingleResult();

		return (sumTransactionResult == null) ? BigDecimal.valueOf(0) : sumTransactionResult;

	}

	public void updateBucket(Session s, BudgetBucket bucket, Calendar curDate) {

		BigDecimal prevYearmonthTotalAmt = getMonthTtl(s, bucket.getCategory(), curDate.get(Calendar.MONTH),
				(curDate.get(Calendar.YEAR) - 1));

		int monthCounter = 0;
		int nonZeroMonthCounter = 0;
		BigDecimal totalAmt = BigDecimal.valueOf(0);
		BigDecimal monthTotalAmt = BigDecimal.valueOf(0);
		BigDecimal avgAmt = BigDecimal.valueOf(0);

		if (bucket.getCategory() == BucketCategory.BUFFER) {

			monthTotalAmt = getMonthTtl(s, BucketCategory.INCOME, (curDate.get(Calendar.MONTH) - 1),
					curDate.get(Calendar.YEAR));
			totalAmt = (monthTotalAmt == null) ? BigDecimal.valueOf(0) : monthTotalAmt;
			bucket.setAppropAmt(totalAmt);

			// BigDecimal remainingAmt =
			// bucket.getAppropAmt().subtract(getCurrentCashAmt(s));
			bucket.setRemainingAmt(
					bucket.getAppropAmt().subtract(getCurrentCashAmt(s)).compareTo(BigDecimal.valueOf(0)) < 0
							? BigDecimal.valueOf(0)
							: bucket.getAppropAmt().subtract(getCurrentCashAmt(s)));

		} else {

			while (monthCounter < 3) {
				monthCounter += 1;

				monthTotalAmt = getMonthTtl(s, bucket.getCategory(), ((curDate.get(Calendar.MONTH) - monthCounter)),
						Calendar.getInstance().get(Calendar.YEAR));

				if (monthTotalAmt == null || monthTotalAmt.equals(BigDecimal.valueOf(0))) {
					monthTotalAmt = BigDecimal.valueOf(0);

				} else {

					nonZeroMonthCounter += 1;
					totalAmt = totalAmt.add(monthTotalAmt);
				}

			}

			if (nonZeroMonthCounter > 0) {
				avgAmt = totalAmt.divide(BigDecimal.valueOf(nonZeroMonthCounter), RoundingMode.HALF_UP);
			}

			// Determine Appropiation Amt:

			if (prevYearmonthTotalAmt.compareTo(avgAmt) > 0) {
				bucket.setAppropAmt(prevYearmonthTotalAmt);
			} else
				bucket.setAppropAmt(avgAmt);

			monthTotalAmt = getMonthTtl(s, bucket.getCategory(), curDate.get(Calendar.MONTH),
					Calendar.getInstance().get(Calendar.YEAR));
			totalAmt = (monthTotalAmt == null) ? BigDecimal.valueOf(0) : monthTotalAmt;

			bucket.setRemainingAmt(bucket.getAppropAmt().subtract(totalAmt));
		}
		@SuppressWarnings("unchecked")
		List<Transaction> transactionList = (List<Transaction>) s.getNamedQuery("Transactions.byCategoryYearMonth")
				.setParameter("category", bucket.getCategory()).setParameter("year", curDate.get(Calendar.YEAR))
				.setParameter("month", curDate.get(Calendar.MONTH)).getResultList();

		bucket.setTransactionList(transactionList);

		s.beginTransaction();
		s.save("BudgetBucket", bucket);
		s.getTransaction().commit();
	}

	public BigDecimal getYearTtl(Session session, BucketCategory category, Calendar date) {
		int year = date.get(Calendar.YEAR);

		return (BigDecimal) session.getNamedQuery("SumTransactions.byCategoryYear").setParameter("category", category)
				.setParameter("year", year).getSingleResult();
	}

	public static BigDecimal getCurrentCashAmt(Session s) {
		//
		@SuppressWarnings("unchecked")
		List<Account> accountList = (List<Account>) s.getNamedQuery("Accounts").getResultList();
		//
		// // BigDecimal startCashBalance = BigDecimal.valueOf(0);
		BigDecimal currentCashBalance = BigDecimal.valueOf(0);
		// //
		for (Account account : accountList) {
			//
			if (!account.getAcctName().contains("CREDIT")) {
				//
				@SuppressWarnings("unchecked")
				List<Transaction> transactionList = (List<Transaction>) s.getNamedQuery("AccountTransactions.byId")
						.setParameter("id", account.getId()).getResultList();
				//
				if (transactionList.size() > 0) {
					currentCashBalance = currentCashBalance.add(transactionList.get(0).getRunningBal());
				}

			}
		}
		return currentCashBalance;

	}

	public void initialize() {

		for (BucketCategory bucketCategory : BucketCategory.values()) {

			BudgetBucket budgetBucket = new BudgetBucket(bucketCategory, null, null);

			dbS.save(budgetBucket);

		}

	}

}
