package com.ryanwgingrich.budgetButler.enums;

public enum FinancialInstitutionCode {
	SCHWAB,
	CHASE,
	AMEX,
	UFIRST,
	CITI
}
