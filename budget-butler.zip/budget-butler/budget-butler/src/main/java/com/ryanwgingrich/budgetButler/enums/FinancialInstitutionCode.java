package com.ryanwgingrich.budgetButler.enums;

public enum FinancialInstitutionCode {
	CHARLES_SCHWAB_BANK,
	CHASE_BANK,
	AMERICAN_EXPRESS_CREDIT,
	U_FIRST,
	CITI_BANK
}
