package com.ryanwgingrich.budgetButler.enums;

public enum BudgetStatus {
	GOOD,
	CAUTTION,
	BAD

}
