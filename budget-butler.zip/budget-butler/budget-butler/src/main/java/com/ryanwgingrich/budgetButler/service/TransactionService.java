package com.ryanwgingrich.budgetButler.service;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;

import org.hibernate.Session;

import com.opencsv.CSVWriter;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.dto.db.TransactionDescriptor;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.EnumLookupUtil;
import com.ryanwgingrich.budgetButler.enums.TransactionType;
import com.ryanwgingrich.budgetButler.io.csvToBean.AmexTransaction;
import com.ryanwgingrich.budgetButler.io.csvToBean.ChaseTransaction;
import com.ryanwgingrich.budgetButler.io.csvToBean.SchwabTransaction;
import com.ryanwgingrich.budgetButler.parser.AmexTransactionParser;
import com.ryanwgingrich.budgetButler.parser.ChaseTransactionParser;
import com.ryanwgingrich.budgetButler.parser.CsvFileParser;
import com.ryanwgingrich.budgetButler.parser.SchwabTransactionParser;

public final class TransactionService {
	private static final TransactionService INSTANCE = new TransactionService();

	private TransactionService() {
	}

	public static TransactionService getInstance() {
		return INSTANCE;
	}

	private static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	private static SimpleDateFormat sdfAmex = new SimpleDateFormat("yyyy-MM-dd");
	// private dbS.BService

	public List<Transaction> parse(CsvFileParser csvFileParser, String fileName) throws ParseException, IOException {

		List<Transaction> transactionList = new ArrayList<Transaction>();

		if (csvFileParser.getClass().equals(ChaseTransactionParser.class)) {
			/*****************************************************************************************
			 * CHASE TRANSACTION FILE
			 *****************************************************************************************/

			@SuppressWarnings("unchecked")
			List<ChaseTransaction> itemList = (List<ChaseTransaction>) csvFileParser.getItems(fileName,
					ChaseTransaction.class);

			for (ChaseTransaction t : itemList) {
				Calendar transactionDate = Calendar.getInstance();

				transactionDate.setTime(sdf.parse(t.getDate()));

				Transaction transaction = new Transaction(t.getDate(), t.getType(), t.getDescription(),
						t.getTransactionAmount());

				transaction.setCategory(categorizeTransaction(transaction));

				transactionList.add(transaction);

				DBService.save(transaction);
			}

		} else if (csvFileParser.getClass().equals(SchwabTransactionParser.class)) {
			/*****************************************************************************************
			 * SCHWAB TRANSACTION FILE
			 *****************************************************************************************/
			@SuppressWarnings("unchecked")
			List<SchwabTransaction> itemList = (List<SchwabTransaction>) csvFileParser.getItems(fileName,
					SchwabTransaction.class);

			for (SchwabTransaction t : itemList) {
				Calendar transactionDate = Calendar.getInstance();
				String transactionAmt;

				try {
					transactionDate.setTime(sdf.parse(t.getDate()));
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				if (t.getDeposit() != null)
					transactionAmt = t.getDeposit();

				else
					transactionAmt = t.getWithdrawal();

				Transaction transaction = new Transaction(t.getDate(), t.getType(), t.getCheckNum(), t.getDescription(),
						t.getRunningBalance(), transactionAmt);

				transaction.setCategory(categorizeTransaction(transaction));

				transactionList.add(transaction);

				DBService.save(transaction);

			}

		} else if (csvFileParser.getClass().equals(AmexTransactionParser.class)) {
			@SuppressWarnings("unchecked")
			List<AmexTransaction> itemList = (List<AmexTransaction>) csvFileParser.getItems(fileName,
					AmexTransaction.class);

			for (AmexTransaction t : itemList) {
				Calendar transactionDate = Calendar.getInstance();

				transactionDate.setTime(sdfAmex.parse(t.getDate()));

				Transaction transaction = new Transaction(t.getDate(), "AMEX", t.getDescription(), t.getCardHolder(),
						t.getTransactionAmount());

				transaction.setCategory(categorizeTransaction(transaction));

				transactionList.add(transaction);

				DBService.save(transaction);
			}

		}
		return transactionList;
	}

	public static BucketCategory categorizeTransaction(Transaction t) throws IOException {

		String descriptorString = t.getDescription().toUpperCase().replaceAll("[^A-Za-z]", "")
				.replaceAll("PAYPAL *", "").replaceAll("SAMPAY", "").replaceAll("THE", "")
				.replaceAll("SARATOGASPRI", "").replaceAll("SARATOGASPRINGS", "").replaceAll("SARATOGASPGS", "")
				.replaceAll("ALBANY", "").replaceAll("LATHAM", "").replaceAll("LATHAM", "").replaceAll("MALTA", "")
				.replaceAll("CLIFTONPARK", "").replaceAll("SCOTIA", "").replaceAll("GLENMONT", "")
				.replaceAll("GLENMONT", "").replaceAll("SCHENECTADY", "").replaceAll("BURLINGTON", "")
				.replaceAll("ALBANY", "").replaceAll("MANCHESTER", "").replaceAll("MENANDS", "")
				.replaceAll("SPRINGFIELDMA", "").replaceAll("BALLSTONLAKE", "").replaceAll("GLENVILLE", "")
				.replaceAll("GLENVILLE", "").replaceAll("SCOTIA", "").replaceAll("GREENWICH", "")
				.replaceAll("BALLSTONSPA", "").replaceAll("WILTON", "").replaceAll("LOUDONVILLE", "")
				.replaceAll("HALFMOON", "").replaceAll("PLATTSBURGH", "").replaceAll("GANSEVOORT", "")
				.replaceAll("LAKEGEORGE", "").replaceAll("NY", "").replaceAll("NEWYORK", "").replaceAll("VT", "")
				.replaceAll("COLUMBUS", "").replaceAll("MENANDS", "").replaceAll("CASTLETON", "");

		if (t.getType().equals(TransactionType.TRANSFER)) {
			return BucketCategory.NONE;
		} else if (t.getType().equals(TransactionType.ATM)) {
			return BucketCategory.CASH;
		} else if (t.getType().equals(TransactionType.RETURN) || t.getType().equals(TransactionType.ATMREBATE)
				|| t.getType().equals(TransactionType.INTADJUST) || t.getType().equals(TransactionType.DEPOSIT)
				|| descriptorString.contains("REGSALARY") || descriptorString.contains("NEWYORKSTATEDIRDEP")) {
			return BucketCategory.INCOME;
		} else if (t.getType().equals(TransactionType.CHECK)
				&& (t.getTransactionAmt().compareTo(BigDecimal.valueOf(1000.00)) == 0
						|| t.getTransactionAmt().compareTo(BigDecimal.valueOf(1010.00)) == 0
						|| t.getTransactionAmt().compareTo(BigDecimal.valueOf(995.00)) == 0)) {
			return BucketCategory.RENT;
		} else if (descriptorString.contains("MCDONALDS") || descriptorString.contains("STARBUCKS")
				|| descriptorString.contains("PRICECHOPPER") || descriptorString.contains("DUNKIN")
				|| descriptorString.contains("MARKETBYPRICE") || descriptorString.contains("DAIRYCIRCUS")
				|| descriptorString.contains("HANNAFORD") || descriptorString.contains("SMASHBURGER")
				|| descriptorString.contains("BURGERKING") || descriptorString.contains("FRESHMARKET")
				|| descriptorString.contains("SHAKESHACK") || descriptorString.contains("SUBWAY")
				|| descriptorString.contains("BURGERFI") || descriptorString.contains("REDROBIN")
				|| descriptorString.contains("TIPSYMOOSE") || descriptorString.contains("GREATTANG")
				|| descriptorString.contains("ESPRESSO") || descriptorString.contains("COFFEE")
				|| descriptorString.contains("MEXICANCONNECTION") || descriptorString.contains("THIRSTYOWL")
				|| descriptorString.contains("BUTCHER") || descriptorString.contains("BEVERAGE")) {
			return BucketCategory.FOOD;
		} else if (descriptorString.contains("AMAZON") || descriptorString.contains("WOOT")) {
			return BucketCategory.AMAZON;
		} else if (descriptorString.contains("ULTA") || descriptorString.contains("SEPHORACOM")
				|| descriptorString.contains("SEPHORA") || descriptorString.contains("SEPHORAUSA")
				|| descriptorString.contains("KELLEYKINDL")) {
			return BucketCategory.BEAUTY;
		} else if (descriptorString.contains("PET") || descriptorString.contains("VETERINARY")) {
			return BucketCategory.PET;
		} else if (descriptorString.contains("HULUCOM") || descriptorString.contains("NETFLIXCOM")
				|| descriptorString.contains("HBO") || descriptorString.contains("SLINGTV")) {
			return BucketCategory.SUBSCRIPTIONS;
		} else if (descriptorString.contains("MOHRS") || descriptorString.contains("PARKING")
				|| descriptorString.contains("SUNOCOPUMP") || descriptorString.contains("CARWASH")) {
			return BucketCategory.CAR;
		} else if (descriptorString.contains("TIMEWARNERCABLE")) {
			return BucketCategory.INTERNET;
		} else if (descriptorString.contains("TAX")) {
			return BucketCategory.TAX;
		}
		@SuppressWarnings("unchecked")
		List<BucketCategory> bucketCategoryList = (List<BucketCategory>) DBService.getInstance().getSession()
				.getNamedQuery("DescriptorBucketLookup").setParameter("descriptor", descriptorString + t.getType())
				.getResultList();

		if (!bucketCategoryList.isEmpty())
			return bucketCategoryList.get(0);
		else {

			CSVWriter csvWriter = new CSVWriter(
					new FileWriter("/home/ryan/BudgetButler" + "/TransactionDescriptor.csv", true));

			System.out.println(sdf.format(t.getDate().getTime()) + " : " + t.getDescription() + " : "
					+ t.getTransactionAmt() + " : " + t.getType());
			System.out.println("Please enter category: ");

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

			BucketCategory bucketCategory = null;
			while (bucketCategory == null) {

				bucketCategory = EnumLookupUtil.lookup(BucketCategory.class, br.readLine());

			}

			TransactionDescriptor descriptor = new TransactionDescriptor(descriptorString + t.getType(),
					bucketCategory);

			DBService.save(descriptor);
			TransactionService.getInstance();
			String[] record = { descriptor.getDescriptor(), descriptor.getBudgetBucket().toString() };

			csvWriter.writeNext(record);

			csvWriter.close();

			return bucketCategory;
		}
	}

	public static void deleteTransactions() {
		Session dbSession = DBService.getInstance().getSession();

		// Criteria API (JPA 2.1 and above)
		dbSession.beginTransaction();

		CriteriaBuilder builder = dbSession.getCriteriaBuilder();
		CriteriaDelete<Transaction> query = builder.createCriteriaDelete(Transaction.class);
		query.from(Transaction.class);
		dbSession.createQuery(query).executeUpdate();

		dbSession.getTransaction().commit();
		dbSession.clear();

	}

	public static Calendar getMinDate() {

		Session dbSession = DBService.getInstance().getSession();
		// dbSession.beginTransaction();
		// s.getNamedQuery("DeleteTransactionDescriptors").executeUpdate();
		// s.getNamedQuery("DeleteAccounts").executeUpdate();
		// s.getNamedQuery("DeleteBudgetBuckets").executeUpdate();
		// System.out.println(dbSession.getNamedQuery("Transactions.minDate").getSingleResult());
		Calendar minDate = (Calendar) dbSession.getNamedQuery("Transactions.minDate").getSingleResult();
		return minDate;

		// s.getTransaction().commit();
		// s.clear();

		// return null;
	}

	public static List<Transaction> getTransactionsByYearMonthCategory(int year, int month, BucketCategory category) {

//		Transactions.byYearMonth

		// DBService.
		Session dbSession = DBService.getInstance().getSession();
		// dbSession.beginTransaction();
		// s.getNamedQuery("DeleteTransactionDescriptors").executeUpdate();
		// s.getNamedQuery("DeleteAccounts").executeUpdate();
		// s.getNamedQuery("DeleteBudgetBuckets").executeUpdate();
		// System.out.println(dbSession.getNamedQuery("Transactions.minDate").getSingleResult());
		@SuppressWarnings("unchecked")
		List<Transaction> transactionList = (List<Transaction>) dbSession
				.getNamedQuery("Transactions.byYearMonthCategory").setParameter("year", year)
				.setParameter("month", month).setParameter("category", category).getResultList();

		return transactionList;

		// s.getTransaction().commit();
		// s.clear();

		// return null;
	}

	public static Calendar getMaxDate() {

		Session dbSession = DBService.getInstance().getSession();

		Calendar maxDate = (Calendar) dbSession.getNamedQuery("Transactions.maxDate").getSingleResult();
		return maxDate;

	}
}
