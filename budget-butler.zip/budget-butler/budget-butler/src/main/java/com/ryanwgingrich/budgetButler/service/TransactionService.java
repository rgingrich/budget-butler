package com.ryanwgingrich.budgetButler.service;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.opencsv.CSVWriter;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.dto.db.TransactionDescriptor;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.EnumLookupUtil;
import com.ryanwgingrich.budgetButler.enums.TransactionType;
import com.ryanwgingrich.budgetButler.io.csvToBean.AmexTransaction;
import com.ryanwgingrich.budgetButler.io.csvToBean.ChaseTransaction;
import com.ryanwgingrich.budgetButler.io.csvToBean.SchwabTransaction;
import com.ryanwgingrich.budgetButler.parser.AmexTransactionParser;
import com.ryanwgingrich.budgetButler.parser.ChaseTransactionParser;
import com.ryanwgingrich.budgetButler.parser.CsvFileParser;
import com.ryanwgingrich.budgetButler.parser.SchwabTransactionParser;

public class TransactionService {

	private static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	// private dbS.BService

	public TransactionService() {

	}

	public List<Transaction> parse(CsvFileParser csvFileParser, String fileName) throws ParseException, IOException {

		List<Transaction> transactionList = new ArrayList<Transaction>();

		if (csvFileParser.getClass().equals(ChaseTransactionParser.class)) {
			/*****************************************************************************************
			 * CHASE TRANSACTION FILE
			 *****************************************************************************************/

			@SuppressWarnings("unchecked")
			List<ChaseTransaction> itemList = (List<ChaseTransaction>) csvFileParser.getItems(fileName,
					ChaseTransaction.class);

			for (ChaseTransaction t : itemList) {
				Calendar transactionDate = Calendar.getInstance();

				transactionDate.setTime(sdf.parse(t.getDate()));

				Transaction transaction = new Transaction(t.getDate(), t.getType(), t.getDescription(),
						t.getTransactionAmount());

				transaction.setCategory(categorizeTransaction(transaction));

				transactionList.add(transaction);
				DBService.getInstance().save(transaction);
			}

		} else if (csvFileParser.getClass().equals(SchwabTransactionParser.class)) {
			/*****************************************************************************************
			 * SCHWAB TRANSACTION FILE
			 *****************************************************************************************/
			@SuppressWarnings("unchecked")
			List<SchwabTransaction> itemList = (List<SchwabTransaction>) csvFileParser.getItems(fileName,
					SchwabTransaction.class);

			for (SchwabTransaction t : itemList) {
				Calendar transactionDate = Calendar.getInstance();
				String transactionAmt;

				try {
					transactionDate.setTime(sdf.parse(t.getDate()));
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				if (t.getDeposit() != null)
					transactionAmt = t.getDeposit();

				else
					transactionAmt = t.getWithdrawal();

				Transaction transaction = new Transaction(t.getDate(), t.getType(), t.getCheckNum(), t.getDescription(),
						t.getRunningBalance(), transactionAmt);

				transaction.setCategory(categorizeTransaction(transaction));

				transactionList.add(transaction);
				DBService.getInstance().save(transaction);

			}

		} else if (csvFileParser.getClass().equals(AmexTransactionParser.class)) {
			@SuppressWarnings("unchecked")
			List<AmexTransaction> itemList = (List<AmexTransaction>) csvFileParser.getItems(fileName,
					AmexTransaction.class);

			for (AmexTransaction t : itemList) {
				Calendar transactionDate = Calendar.getInstance();

				transactionDate.setTime(sdf.parse(t.getDate()));

				Transaction transaction = new Transaction(t.getDate(), "AMEX", t.getDescription(), t.getCardHolder(),
						t.getTransactionAmount());

				transaction.setCategory(categorizeTransaction(transaction));

				transactionList.add(transaction);
				DBService.getInstance().save(transaction);
			}

		}
		return transactionList;
	}

	public BucketCategory categorizeTransaction(Transaction t) throws IOException {

		String descriptorString = t.getDescription().toUpperCase().replaceAll("[^A-Za-z]", "")
				.replaceAll("PAYPAL *", "").replaceAll("SAMPAY", "").replaceAll("THE", "")
				.replaceAll("SARATOGASPRINY", "").replaceAll("SARATOGASPRINGSNY", "").replaceAll("SARATOGASPGSNY", "")
				.replaceAll("ALBANYNY", "").replaceAll("LATHAMNY", "").replaceAll("MALTA NY", "")
				.replaceAll("CLIFTONPARKNY", "").replaceAll("SCOTIANY", "").replaceAll("GLENMONTNY", "")
				.replaceAll("SCHENECTADYNY", "").replaceAll("BURLINGTON", "").replaceAll("ALBANY", "")
				.replaceAll("MANCHESTERVT", "").replaceAll("MENANDSNY", "").replaceAll("SPRINGFIELDMA", "")
				.replaceAll("BALLSTONLAKENY", "").replaceAll("GLENVILLENY", "").replaceAll("GLENVILLE", "")
				.replaceAll("GREENWICHNY", "").replaceAll("BALLSTONSPANY", "").replaceAll("WILTON", "");

		if (t.getType().equals(TransactionType.TRANSFER)) {
			return BucketCategory.NONE;
		} else if (t.getType().equals(TransactionType.ATM)) {
			return BucketCategory.CASH;
		} else if (t.getType().equals(TransactionType.RETURN) || t.getType().equals(TransactionType.ATMREBATE)
				|| t.getType().equals(TransactionType.INTADJUST) || t.getType().equals(TransactionType.DEPOSIT)
				|| descriptorString.contains("REGSALARY") || descriptorString.contains("NEWYORKSTATEDIRDEP")) {
			return BucketCategory.INCOME;
		} else if (t.getType().equals(TransactionType.CHECK)
				&& t.getTransactionAmt().compareTo(BigDecimal.valueOf(1000.00)) == 0) {
			return BucketCategory.RENT;
		} else if (descriptorString.contains("MCDONALDS") || descriptorString.contains("STARBUCKS")
				|| descriptorString.contains("PRICECHOPPER") || descriptorString.contains("DUNKIN")
				|| descriptorString.contains("MARKETBYPRICE") || descriptorString.contains("DAIRYCIRCUS")
				|| descriptorString.contains("HANNAFORD") || descriptorString.contains("SMASHBURGER")
				|| descriptorString.contains("BURGERKING") || descriptorString.contains("FRESHMARKET")
				|| descriptorString.contains("SHAKESHACK") || descriptorString.contains("SUBWAY")) {
			return BucketCategory.FOOD;
		}
		@SuppressWarnings("unchecked")
		List<BucketCategory> bucketCategoryList = (List<BucketCategory>) DBService.getInstance().getSession()
				.getNamedQuery("DescriptorBucketLookup").setParameter("descriptor", descriptorString + t.getType())
				.getResultList();

		if (!bucketCategoryList.isEmpty())
			return bucketCategoryList.get(0);
		else {

			CSVWriter csvWriter = new CSVWriter(
					new FileWriter("/home/ryan/BudgetButler" + "/TransactionDescriptor.csv", true));

			System.out.println(sdf.format(t.getDate().getTime()) + " : " + t.getDescription() + " : "
					+ t.getTransactionAmt() + " : " + t.getType());
			System.out.println("Please enter category: ");

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

			BucketCategory bucketCategory = null;
			while (bucketCategory == null) {

				bucketCategory = EnumLookupUtil.lookup(BucketCategory.class, br.readLine());

			}

			TransactionDescriptor descriptor = new TransactionDescriptor(descriptorString + t.getType(),
					bucketCategory);

			DBService.getInstance().save(descriptor);

			String[] record = { descriptor.getDescriptor(), descriptor.getBudgetBucket().toString() };

			csvWriter.writeNext(record);

			csvWriter.close();

			return bucketCategory;
		}
	}

	
}
