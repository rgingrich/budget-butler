package com.ryanwgingrich.budgetButler.service;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;

import org.hibernate.Session;

import com.opencsv.CSVWriter;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.dto.db.TransactionDescriptor;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.EnumLookupUtil;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

public final class TransactionService {
	private static final TransactionService INSTANCE = new TransactionService();

	private TransactionService() {
	}

	public static TransactionService getInstance() {
		return INSTANCE;
	}

	private static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	// private static SimpleDateFormat sdfAmex = new SimpleDateFormat("yyyy-MM-dd");

	public static BucketCategory categorizeTransaction(Transaction t) throws IOException {

		String descriptorString = t.getDescription().toUpperCase().replaceAll("[^A-Za-z]", "")
				.replaceAll("PAYPAL *", "").replaceAll("SAMPAY", "").replaceAll("THE", "")
				.replaceAll("SARATOGASPRI", "").replaceAll("SARATOGASPRINGS", "").replaceAll("SARATOGASPGS", "")
				.replaceAll("ALBANY", "").replaceAll("LATHAM", "").replaceAll("LATHAM", "").replaceAll("MALTA", "")
				.replaceAll("CLIFTONPARK", "").replaceAll("SCOTIA", "").replaceAll("GLENMONT", "")
				.replaceAll("GLENMONT", "").replaceAll("SCHENECTADY", "").replaceAll("BURLINGTON", "")
				.replaceAll("ALBANY", "").replaceAll("MANCHESTER", "").replaceAll("MENANDS", "")
				.replaceAll("SPRINGFIELDMA", "").replaceAll("BALLSTONLAKE", "").replaceAll("GLENVILLE", "")
				.replaceAll("GLENVILLE", "").replaceAll("SCOTIA", "").replaceAll("GREENWICH", "")
				.replaceAll("BALLSTONSPA", "").replaceAll("WILTON", "").replaceAll("LOUDONVILLE", "")
				.replaceAll("HALFMOON", "").replaceAll("PLATTSBURGH", "").replaceAll("GANSEVOORT", "")
				.replaceAll("LAKEGEORGE", "").replaceAll("NY", "").replaceAll("NEWYORK", "").replaceAll("VT", "")
				.replaceAll("COLUMBUS", "").replaceAll("MENANDS", "").replaceAll("CASTLETON", "");

		if (t.getType().equals(TransactionType.TRANSFER)) {
			return BucketCategory.NONE;
		} else if (t.getType().equals(TransactionType.ATM)) {
			return BucketCategory.CASH;
		} else if (t.getType().equals(TransactionType.RETURN) || t.getType().equals(TransactionType.ATMREBATE)
				|| t.getType().equals(TransactionType.INTADJUST) || t.getType().equals(TransactionType.DEPOSIT)
				|| descriptorString.contains("REGSALARY") || descriptorString.contains("NEWYORKSTATEDIRDEP")) {
			return BucketCategory.INCOME;
		} else if (t.getType().equals(TransactionType.CHECK)
				&& (t.getTransactionAmt().compareTo(BigDecimal.valueOf(1000.00)) == 0
						|| t.getTransactionAmt().compareTo(BigDecimal.valueOf(1010.00)) == 0
						|| t.getTransactionAmt().compareTo(BigDecimal.valueOf(995.00)) == 0)) {
			return BucketCategory.RENT;
		} else if (descriptorString.contains("MCDONALDS") || descriptorString.contains("STARBUCKS")
				|| descriptorString.contains("PRICECHOPPER") || descriptorString.contains("DUNKIN")
				|| descriptorString.contains("MARKETBYPRICE") || descriptorString.contains("DAIRYCIRCUS")
				|| descriptorString.contains("HANNAFORD") || descriptorString.contains("SMASHBURGER")
				|| descriptorString.contains("BURGERKING") || descriptorString.contains("FRESHMARKET")
				|| descriptorString.contains("SHAKESHACK") || descriptorString.contains("SUBWAY")
				|| descriptorString.contains("BURGERFI") || descriptorString.contains("REDROBIN")
				|| descriptorString.contains("TIPSYMOOSE") || descriptorString.contains("GREATTANG")
				|| descriptorString.contains("ESPRESSO") || descriptorString.contains("COFFEE")
				|| descriptorString.contains("MEXICANCONNECTION") || descriptorString.contains("THIRSTYOWL")
				|| descriptorString.contains("BUTCHER") || descriptorString.contains("BEVERAGE")) {
			return BucketCategory.FOOD;
		} else if (descriptorString.contains("AMAZON") || descriptorString.contains("WOOT")) {
			return BucketCategory.AMAZON;
		} else if (descriptorString.contains("ULTA") || descriptorString.contains("SEPHORACOM")
				|| descriptorString.contains("SEPHORA") || descriptorString.contains("SEPHORAUSA")
				|| descriptorString.contains("KELLEYKINDL")) {
			return BucketCategory.BEAUTY;
		} else if (descriptorString.contains("PET") || descriptorString.contains("VETERINARY")) {
			return BucketCategory.PET;
		} else if (descriptorString.contains("HULUCOM") || descriptorString.contains("NETFLIXCOM")
				|| descriptorString.contains("HBO") || descriptorString.contains("SLINGTV")) {
			return BucketCategory.SUBSCRIPTIONS;
		} else if (descriptorString.contains("MOHRS") || descriptorString.contains("PARKING")
				|| descriptorString.contains("SUNOCOPUMP") || descriptorString.contains("CARWASH")) {
			return BucketCategory.CAR;
		} else if (descriptorString.contains("TIMEWARNERCABLE")) {
			return BucketCategory.INTERNET;
		} else if (descriptorString.contains("TAX")) {
			return BucketCategory.TAX;
		}
		@SuppressWarnings("unchecked")
		List<BucketCategory> bucketCategoryList = (List<BucketCategory>) DBService.getInstance().getSession()
				.getNamedQuery("DescriptorBucketLookup").setParameter("descriptor", descriptorString + t.getType())
				.getResultList();

		if (!bucketCategoryList.isEmpty())
			return bucketCategoryList.get(0);
		else {

			CSVWriter csvWriter = new CSVWriter(
					new FileWriter("/home/ryan/BudgetButler" + "/TransactionDescriptor.csv", true));

			System.out.println(sdf.format(t.getDate().getTime()) + " : " + t.getDescription() + " : "
					+ t.getTransactionAmt() + " : " + t.getType());
			System.out.println("Please enter category: ");

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

			BucketCategory bucketCategory = null;
			while (bucketCategory == null) {

				bucketCategory = EnumLookupUtil.lookup(BucketCategory.class, br.readLine());

			}

			TransactionDescriptor descriptor = new TransactionDescriptor(descriptorString + t.getType(),
					bucketCategory);

			DBService.save(descriptor);
			TransactionService.getInstance();
			String[] record = { descriptor.getDescriptor(), descriptor.getBudgetBucket().toString() };

			csvWriter.writeNext(record);

			csvWriter.close();

			return bucketCategory;
		}
	}

	public static void deleteTransactions() {
		Session dbSession = DBService.getInstance().getSession();

		// Criteria API (JPA 2.1 and above)
		dbSession.beginTransaction();

		CriteriaBuilder builder = dbSession.getCriteriaBuilder();
		CriteriaDelete<Transaction> query = builder.createCriteriaDelete(Transaction.class);
		query.from(Transaction.class);
		dbSession.createQuery(query).executeUpdate();

		dbSession.getTransaction().commit();
		dbSession.clear();

	}

	public static Calendar getMinDate() {

		Session dbSession = DBService.getInstance().getSession();

		Calendar minDate = (Calendar) dbSession.getNamedQuery("Transactions.minDate").getSingleResult();
		return minDate;

	}

	public static Calendar getMaxDate() {

		Session dbSession = DBService.getInstance().getSession();

		Calendar maxDate = (Calendar) dbSession.getNamedQuery("Transactions.maxDate").getSingleResult();
		return maxDate;

	}

	public static List<Transaction> getTransactionsByYearMonthCategory(int year, int month, BucketCategory category) {

		Session dbSession = DBService.getInstance().getSession();

		@SuppressWarnings("unchecked")
		List<Transaction> transactionList = (List<Transaction>) dbSession
				.getNamedQuery("Transactions.byYearMonthCategory").setParameter("year", year)
				.setParameter("month", month).setParameter("category", category).getResultList();

		return transactionList;

	}
}
