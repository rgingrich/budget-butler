package com.ryanwgingrich.budgetButler.parser;

import java.io.FileNotFoundException;
import java.util.List;

import org.hibernate.Session;

import com.ryanwgingrich.budgetButler.dto.csv.SchwabTransaction;


public interface Parser {
	
	List<?> getRecordList(String fileName) throws FileNotFoundException;
	
	//void parseToDB(String fileName) throws FileNotFoundException;

	void parseToDB(String fileName, Session session) throws FileNotFoundException;
		
		
}