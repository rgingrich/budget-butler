package com.ryanwgingrich.budgetButler.parser;

import java.io.FileNotFoundException;
import java.util.List;

import org.hibernate.Session;


public interface Parser {
	
	List<?> getTransactionList(String fileName) throws FileNotFoundException;
	
	//void parseToDB(String fileName) throws FileNotFoundException;

	void parseToDB(String fileName, Session session) throws FileNotFoundException;
		
		
}