package com.ryanwgingrich.budgetButler.parser;

import java.io.FileNotFoundException;
import java.util.List;


public interface Parser {
	
	List<?> getTransactionList(String fileName) throws FileNotFoundException;
		
		
}