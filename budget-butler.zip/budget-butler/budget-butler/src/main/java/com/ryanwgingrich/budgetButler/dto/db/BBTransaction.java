package com.ryanwgingrich.budgetButler.dto.db;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.opencsv.bean.CsvBindByName;
import com.ryanwgingrich.budgetButler.BudgetButler;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

@Entity
@Embeddable
public class BBTransaction {
	static Logger logger = LogManager.getLogger(BBTransaction.class.getName());
	
	//DateFormat format = new SimpleDateFormat("mm/dd/yyyy", Locale.ENGLISH);
	String DATE_FORMAT = "MM/dd/yyyy";
    SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);

	public BBTransaction() {
	}

	public BBTransaction(String date2, String type2, String description2, int checkNum2, String deposit2,
			String withdrawal2, String runningBalance2) {
		
		try {
			this.date = sdf.parse(date2);
			//System.out.println(sdf.parse(date2));
			
			//System.exit(0);
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.type = TransactionType.valueOf(type2);
		this.description = description2;
		this.checkNum = checkNum2;
		
		this.deposit = new BigDecimal((deposit2 == null) ? "0.00":deposit2.replaceAll("[^\\d.]+", ""));
		
		
		this.withdrawal = new BigDecimal((withdrawal2 == null) ? "0.00":withdrawal2.replaceAll("[^\\d.]+", ""));
		this.runningBalance = new BigDecimal((runningBalance2 == null) ? "0.00":runningBalance2.replaceAll("[^\\d.]+", ""));		
	}
	
	

	@Id
	@GeneratedValue
	private int id;
	private Date date;
	private TransactionType type;
	private int checkNum;
	private String description;
	private BigDecimal withdrawal;
	private BigDecimal deposit;
	private BigDecimal runningBalance;
	
	

	public int getId() {
		
		return id;
	}

	public Date getDate() {
		return date;
	}

	public TransactionType getType() {
		return type;
	}

	public int getCheckNum() {
		return checkNum;
	}

	public String getDescription() {
		return description;
	}

	public BigDecimal getWithdrawal() {
		return withdrawal;
	}

	public BigDecimal getDeposit() {
		return deposit;
	}

	public BigDecimal getRunningBalance() {
		return runningBalance;
	}

	public void setId(int id) {
		this.id = id;
	}
	
public void setDate(String date) throws ParseException {
		
		this.date = sdf.parse(date);
	}
public void setDate(Date date) {
		this.date = date;
	}

	

	public void setType(TransactionType type) {
		this.type = type;
	}

	public void setType(String type) {
		this.type = TransactionType.valueOf(type);
	}

	public void setCheckNum(int checkNum) {
		this.checkNum = checkNum;
	}

	public void setCheckNum(String checkNum) {
		this.checkNum = Integer.valueOf(checkNum);
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setWithdrawal(BigDecimal withdrawal) {
		this.withdrawal = withdrawal;
	}

	public void setWithdrawal(String withdrawal) {
		this.withdrawal = new BigDecimal(withdrawal);
	}

	public void setDeposit(BigDecimal deposit) {
		this.deposit = deposit;
	}

	public void setDeposit(String deposit) {
		this.deposit = new BigDecimal(deposit);
	}

	public void setRunningBalance(BigDecimal runningBalance) {
		this.runningBalance = runningBalance;
	}

	public void setRunningBalance(String runningBalance) {
		this.runningBalance = new BigDecimal(runningBalance);
	}
}
