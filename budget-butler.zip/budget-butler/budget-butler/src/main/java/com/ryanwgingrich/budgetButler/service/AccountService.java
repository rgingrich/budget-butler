package com.ryanwgingrich.budgetButler.service;

import java.util.List;

import com.ryanwgingrich.budgetButler.dto.db.Account;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;

public class AccountService {
	
	//private Account account;
	//private DBService dbService;
	
	
	public AccountService() {
		
	}

	public Account add(String accountType, String fileName) {

		Account account = new Account(accountType, fileName);
		DBService.getInstance().save(account);
		return account;

		
	}

	public void setTransactionList(Account account, List<Transaction> transactionList) {
		account.setTransactionList(transactionList);
		DBService.getInstance().save(account);
		
	}
	
	

}
