package com.ryanwgingrich.budgetButler.service;

public class AccountService {

	public AccountService() {

	}

}
