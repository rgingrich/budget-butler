package com.ryanwgingrich.budgetButler.io.csvToBean;

import com.opencsv.bean.CsvBindByName;

public class AmexTransaction {

	public AmexTransaction() {
	}

	@CsvBindByName(column = "Date", required = true)
	private String date;

	@CsvBindByName(column = "Description", required = true)
	private String description;

	@CsvBindByName(column = "Card Member", required = true)
	private String cardHolder;

	@CsvBindByName(column = "Amount", required = true)
	private String transactionAmount;

	public String getDate() {
		return date;
	}

	public String getDescription() {
		return description;
	}

	public String getCardHolder() {
		return cardHolder;
	}

	public String getTransactionAmount() {
		return transactionAmount;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setCardHolder(String cardHolder) {
		this.cardHolder = cardHolder;
	}

	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

}
