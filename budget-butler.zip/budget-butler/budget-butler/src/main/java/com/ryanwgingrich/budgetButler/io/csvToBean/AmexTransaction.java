package com.ryanwgingrich.budgetButler.io.csvToBean;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByPosition;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

public class AmexTransaction {

	public AmexTransaction() {
	}

	@CsvBindByName(column = "Date", required = true)
	private String date;

	@CsvBindByName(column = "Description", required = true)
	private String description;

	@CsvBindByName(column = "Card Member", required = true)
	private String cardHolder;

	@CsvBindByName(column = "Amount", required = true)
	private String transactionAmount;
	
	private String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDate() {
		return date;
	}

	public String getDescription() {
		return description;
	}

	public String getCardHolder() {
		return cardHolder;
	}

	public String getTransactionAmount() {
		return transactionAmount;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setCardHolder(String cardHolder) {
		this.cardHolder = cardHolder;
	}

	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

}
