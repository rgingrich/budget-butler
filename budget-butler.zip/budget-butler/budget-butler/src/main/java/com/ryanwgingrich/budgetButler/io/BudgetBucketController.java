package com.ryanwgingrich.budgetButler.io;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.enums.AccountType;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.service.DBService;

public class BudgetBucketController {

	public BudgetBucketController() {

	}

	public void initialize(int budgetMonth, int budgetYear) {

		for (BucketCategory category : BucketCategory.values()) {

			BudgetBucket budgetBucket = new BudgetBucket(budgetYear, budgetMonth, category);

			@SuppressWarnings("unchecked")
			List<Transaction> transactionList = (List<Transaction>) DBService.getInstance().getSession()
					.getNamedQuery("Transactions.byYearMonthCategory").setParameter("year", budgetYear)
					.setParameter("month", budgetMonth).setParameter("category", category).getResultList();
			budgetBucket.setTransactionList(transactionList);

			appropiate(budgetBucket);

			BigDecimal sumTransactionResult = (BigDecimal) DBService.getInstance().getSession()
					.getNamedQuery("SumCashTransactions.byCategoryYearMonth").setParameter("category", category)
					.setParameter("year", budgetYear).setParameter("month", budgetMonth)
					.setParameter("accountType", AccountType.SCHWAB_CASH).getSingleResult();

			BigDecimal cashMonthTotalAmt = sumTransactionResult == null ? BigDecimal.valueOf(0) : sumTransactionResult;

			if (category == BucketCategory.INCOME) {
				budgetBucket.setCashCreditAmt(cashMonthTotalAmt);
			} else {
				budgetBucket.setCashExpenditureAmt(cashMonthTotalAmt);
			}

			sumTransactionResult = (BigDecimal) DBService.getInstance().getSession()
					.getNamedQuery("SumCreditTransactions.byCategoryYearMonth").setParameter("category", category)
					.setParameter("year", budgetYear).setParameter("month", budgetMonth)
					.setParameter("accountType", AccountType.SCHWAB_CASH).getSingleResult();

			BigDecimal creditMonthTotalAmt = sumTransactionResult == null ? BigDecimal.valueOf(0)
					: sumTransactionResult;
			budgetBucket.setCreditExpenditureAmt(creditMonthTotalAmt);

			DBService.getInstance().save(budgetBucket);
		}

	}

	public void appropiate(BudgetBucket budgetBucket) {

		BucketCategory bucketCategory = budgetBucket.getCategory();

		int budgetMonth = Integer.valueOf(String.valueOf(budgetBucket.getId()).substring(4, 6));
		int budgetYear = Integer.valueOf(String.valueOf(budgetBucket.getId()).substring(0, 4));

		int nonZeroMonthCounter = 0;
		BigDecimal totalAmt = BigDecimal.valueOf(0);
		BigDecimal prevMonthTotalAmt = BigDecimal.valueOf(0);
		BigDecimal prevYearTotalAmt = BigDecimal.valueOf(0);
		BigDecimal avgAmt = BigDecimal.valueOf(0);

		prevYearTotalAmt = getMonthTtlAmt(bucketCategory, budgetMonth, budgetYear - 1);

		if (!prevYearTotalAmt.equals(BigDecimal.valueOf(0))) {
			nonZeroMonthCounter += 1;
			totalAmt = totalAmt.add(prevYearTotalAmt);
		}

		budgetYear = (budgetMonth - 1 == 0 ? budgetYear - 1 : budgetYear);
		budgetMonth = (budgetMonth - 1 == 0 ? 12 : budgetMonth - 1);

		prevMonthTotalAmt = getMonthTtlAmt(bucketCategory, budgetMonth, budgetYear);

		if (!prevMonthTotalAmt.equals(BigDecimal.valueOf(0))) {
			nonZeroMonthCounter += 1;
			totalAmt = totalAmt.add(prevMonthTotalAmt);
		}

		if (nonZeroMonthCounter > 0) {
			avgAmt = totalAmt.divide(BigDecimal.valueOf(nonZeroMonthCounter), RoundingMode.HALF_UP);
		}

		budgetBucket.setAppropiationAmt(avgAmt);

	}

	public BigDecimal getMonthTtlAmt(BucketCategory category, int month, int year) {

		BigDecimal sumTransactionResult = (BigDecimal) DBService.getInstance().getSession()
				.getNamedQuery("SumTransactions.byCategoryYearMonth").setParameter("category", category)
				.setParameter("year", year).setParameter("month", month).getSingleResult();

		return (sumTransactionResult == null) ? BigDecimal.valueOf(0) : sumTransactionResult;

	}

}
