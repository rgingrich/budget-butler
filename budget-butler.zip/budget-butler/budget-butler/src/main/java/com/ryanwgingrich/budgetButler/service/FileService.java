package com.ryanwgingrich.budgetButler.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.ryanwgingrich.budgetButler.dto.db.Transaction;
import com.ryanwgingrich.budgetButler.dto.db.TransactionDescriptor;
import com.opencsv.CSVWriter;
import com.ryanwgingrich.budgetButler.BudgetButler;
import com.ryanwgingrich.budgetButler.dto.db.Account;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.AccountType;
import com.ryanwgingrich.budgetButler.enums.BucketCategory;
import com.ryanwgingrich.budgetButler.enums.TransactionType;
import com.ryanwgingrich.budgetButler.io.BudgetButlerController;
import com.ryanwgingrich.budgetButler.io.csvToBean.AmexTransaction;
import com.ryanwgingrich.budgetButler.io.csvToBean.ChaseTransaction;
import com.ryanwgingrich.budgetButler.io.csvToBean.CsvTransactionDescriptor;
import com.ryanwgingrich.budgetButler.io.csvToBean.SchwabTransaction;
import com.ryanwgingrich.budgetButler.parser.AmexTransactionParser;
import com.ryanwgingrich.budgetButler.parser.ChaseTransactionParser;
import com.ryanwgingrich.budgetButler.parser.CsvFileParser;
import com.ryanwgingrich.budgetButler.parser.CsvFileParserFactory;
import com.ryanwgingrich.budgetButler.parser.SchwabTransactionParser;
import com.ryanwgingrich.budgetButler.parser.TransactionDescriptorParser;

public final class FileService {
	private static final FileService INSTANCE = new FileService();

	private FileService() {
	}

	public static FileService getInstance() {
		return INSTANCE;
	}

	private static Logger logger = LogManager.getLogger(BudgetButler.class.getName());
	private static SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

	// private Session s = new
	// Configuration().configure().buildSessionFactory().openSession();
	private DBService dbS = DBService.getInstance();
	// private BudgetButlerController bbController;

	private String transactionFileDir;
	private AccountService accountS = new AccountService();
	private TransactionService transactionS = TransactionService.getInstance();

	public FileService(String transactionFileDir) {
		this.transactionFileDir = transactionFileDir;

	}

	public void removeFile(String fileName) {
		File[] directoryListing = new File(transactionFileDir).listFiles();

		for (File file : directoryListing) {

			if (file.getName().equals(fileName)) {
				file.delete();

			}
		}
	}

	@SuppressWarnings("unchecked")
	public static List<Transaction> parseFile(String fileName) throws FileNotFoundException {

		CsvFileParser csvFileParser = new CsvFileParserFactory().getFileParser(fileName);

		if (csvFileParser != null) {

			/*****************************************************************************************
			 * CHASE TRANSACTION FILE
			 *****************************************************************************************/
			if (csvFileParser.getClass().equals(ChaseTransactionParser.class)) {
				logger.info("Detected a CHASE  file: " + fileName);

				@SuppressWarnings("unchecked")
				List<ChaseTransaction> itemList = (List<ChaseTransaction>) csvFileParser.getItems(fileName,
						ChaseTransaction.class);

				List<Transaction> transactionList = new ArrayList<Transaction>();
				for (ChaseTransaction csvTransaction : itemList) {

					Transaction transaction = new Transaction(csvTransaction.getDate(), csvTransaction.getType(),
							csvTransaction.getDescription(), csvTransaction.getTransactionAmount());

					transactionList.add(transaction);

				}
				return transactionList;

			}
			/*****************************************************************************************
			 * SCHWAB TRANSACTION FILE
			 *****************************************************************************************/
			else if (csvFileParser.getClass().equals(SchwabTransactionParser.class)) {
				logger.info("Detected a SCHWAB  file: " + fileName);

				@SuppressWarnings("unchecked")
				List<SchwabTransaction> itemList = (List<SchwabTransaction>) csvFileParser.getItems(fileName,
						SchwabTransaction.class);

				List<Transaction> transactionList = new ArrayList<Transaction>();
				for (SchwabTransaction t : itemList) {

					String transactionAmt = t.getDeposit() == null ? t.getWithdrawal() : t.getDeposit();

					Transaction transaction = new Transaction(t.getDate(), t.getType(), t.getCheckNum(),
							t.getDescription(), t.getRunningBalance(), transactionAmt);

					transactionList.add(transaction);

				}

				return transactionList;
			}

			/*****************************************************************************************
			 * AMEX TRANSACTION FILE
			 *****************************************************************************************/
			else if (csvFileParser.getClass().equals(AmexTransactionParser.class)) {
				logger.info("Detected a AMEX  file: " + fileName);

				List<AmexTransaction> itemList = (List<AmexTransaction>) csvFileParser.getItems(fileName,
						AmexTransaction.class);

				List<Transaction> transactionList = new ArrayList<Transaction>();
				for (AmexTransaction t : itemList) {

					Transaction transaction = new Transaction(t.getDate(), "AMEX", t.getDescription(),
							t.getCardHolder(), t.getTransactionAmount());

					transactionList.add(transaction);

				}
				return transactionList;

			}

		}
		return null;
	}

//	public void processFiles() throws NumberFormatException, IOException, ParseException {
//
//		File[] directoryListing = new File(transactionFileDir).listFiles();
//
//		int acctCounter = 0;
//
//		for (File file : directoryListing) {
//
//			String fileName = file.getAbsolutePath();
//
//			/*****************************************************************************************
//			 * FILE PARSER FACTORY
//			 *****************************************************************************************/
//			CsvFileParser csvFileParser = new CsvFileParserFactory().getFileParser(fileName);
//
//			if (csvFileParser != null) {
//				/*****************************************************************************************
//				 * TRANSACTION DESCRIPTOR FILE
//				 *****************************************************************************************/
//				if (csvFileParser.getClass().equals(TransactionDescriptorParser.class)) {
//
//					logger.info("Detected a transaction descriptor file: " + fileName);
//
//					@SuppressWarnings("unchecked")
//					List<CsvTransactionDescriptor> itemList = (List<CsvTransactionDescriptor>) csvFileParser
//							.getItems(fileName, CsvTransactionDescriptor.class);
//
//					for (CsvTransactionDescriptor descriptor : itemList) {
//						DBService.save(new TransactionDescriptor(descriptor.getDescriptor(),
//								BucketCategory.valueOf(descriptor.getBudgetBucket())));
//					}
//				}
//				/*****************************************************************************************
//				 * CHASE TRANSACTION FILE
//				 *****************************************************************************************/
//				else if (csvFileParser.getClass().equals(ChaseTransactionParser.class)) {
//					logger.info("Detected a CHASE  file: " + fileName);
//
//					acctCounter += 1;
//					Account account = accountS.add(AccountType.CHASE_CREDIT.name() + acctCounter, fileName);
//
//					account.setTransactionList(transactionS.parse(csvFileParser, fileName));
//					// DBService.getInstance();
//					DBService.save(account);
//				}
//				/*****************************************************************************************
//				 * SCHWAB TRANSACTION FILE
//				 *****************************************************************************************/
//				else if (csvFileParser.getClass().equals(SchwabTransactionParser.class)) {
//					logger.info("Detected a SCHWAB  file: " + fileName);
//
//					acctCounter += 1;
//					Account account = accountS.add(AccountType.SCHWAB_BANK.name() + acctCounter, fileName);
//
//					account.setTransactionList(transactionS.parse(csvFileParser, fileName));
//					// DBService.getInstance();
//					DBService.save(account);
//				}
//
//				/*****************************************************************************************
//				 * AMEX TRANSACTION FILE
//				 *****************************************************************************************/
//				else if (csvFileParser.getClass().equals(AmexTransactionParser.class)) {
//					logger.info("Detected a AMEX  file: " + fileName);
//
//					acctCounter += 1;
//					Account account = accountS.add(AccountType.AMEX_CREDIT.name() + acctCounter, fileName);
//
//					account.setTransactionList(transactionS.parse(csvFileParser, fileName));
//					// DBService.getInstance();
//					DBService.save(account);
//				}
//			}
//
//		}
//	}
//
//	public void processFiles(int month){
//		File[] directoryListing = new File(transactionFileDir).listFiles();
//
//		int acctCounter = 0;
//
//		for (File file : directoryListing) {
//
//			String fileName = file.getAbsolutePath();
//
//			/*****************************************************************************************
//			 * FILE PARSER FACTORY
//			 *****************************************************************************************/
//			CsvFileParser csvFileParser = new CsvFileParserFactory().getFileParser(fileName);
//
//			if (csvFileParser != null) {
//				/*****************************************************************************************
//				 * CHASE TRANSACTION FILE
//				 *****************************************************************************************/
//				else if (csvFileParser.getClass().equals(ChaseTransactionParser.class)) {
//					logger.info("Detected a CHASE  file: " + fileName);
//
//					acctCounter += 1;
//					Account account = accountS.add(AccountType.CHASE_CREDIT.name() + acctCounter, fileName);
//
//					account.setTransactionList(transactionS.parse(csvFileParser, fileName));
//					DBService.getInstance();
//					DBService.save(account);
//				}
//				/*****************************************************************************************
//				 * SCHWAB TRANSACTION FILE
//				 *****************************************************************************************/
//				else if (csvFileParser.getClass().equals(SchwabTransactionParser.class)) {
//					logger.info("Detected a SCHWAB  file: " + fileName);
//
//					acctCounter += 1;
//					Account account = accountS.add(AccountType.SCHWAB_BANK.name() + acctCounter, fileName);
//
//					account.setTransactionList(transactionS.parse(csvFileParser, fileName));
//					DBService.getInstance();
//					DBService.save(account);
//				}
//
//				/*****************************************************************************************
//				 * AMEX TRANSACTION FILE
//				 *****************************************************************************************/
//				else if (csvFileParser.getClass().equals(AmexTransactionParser.class)) {
//					logger.info("Detected a AMEX  file: " + fileName);
//
//					acctCounter += 1;
//					Account account = accountS.add(AccountType.AMEX_CREDIT.name() + acctCounter, fileName);
//
//					account.setTransactionList(transactionS.parse(csvFileParser, fileName));
//					DBService.getInstance();
//					DBService.save(account);
//				}
//			}
	// Calendar curDate = Calendar.getInstance();
	// curDate.set(Calendar.MONTH, bbController.getBudgetMonth());

	// File[] directoryListing = new File(transactionFileDir).listFiles();
	// s.beginTransaction();
//		int acctCounter = 0;
//		for (File file : directoryListing) {

	// String fileName = file.getAbsolutePath();

	/*****************************************************************************************
	 * FILE PARSER FACTORY
	 *****************************************************************************************
	 * CsvFileParser csvFileParser = new
	 * CsvFileParserFactory().getFileParser(fileName);
	 * 
	 * if (csvFileParser != null) {
	 * 
	 * /*****************************************************************************************
	 ******************************************************************************************
	 *****************************************************************************************/

	/*****************************************************************************************
	 * TRANSACTION DESCRIPTOR FILE
	 *****************************************************************************************
	 * if (csvFileParser.getClass().equals(TransactionDescriptorParser.class)) {
	 * 
	 * logger.info("Detected a transaction descriptor file: " + fileName);
	 * 
	 * @SuppressWarnings("unchecked") List<CsvTransactionDescriptor> itemList =
	 * (List<CsvTransactionDescriptor>) csvFileParser .getItems(fileName,
	 * CsvTransactionDescriptor.class);
	 * 
	 * for (CsvTransactionDescriptor descriptor : itemList) {
	 * 
	 * dbS.save(new TransactionDescriptor(descriptor.getDescriptor(),
	 * BucketCategory.valueOf(descriptor.getBudgetBucket())));
	 * 
	 * } }
	 * /*****************************************************************************************
	 * CHASE TRANSACTION FILE
	 *****************************************************************************************
	 * else if (csvFileParser.getClass().equals(ChaseTransactionParser.class)) {
	 * logger.info("Detected a CHASE file: " + fileName);
	 * 
	 * // increment account counter and create Account object acctCounter += 1;
	 * Account account = accountS.add(AccountType.CHASE_CREDIT.name() + acctCounter,
	 * fileName);
	 * 
	 * List<Transaction> transactionList = new
	 * ArrayList<Transaction>(); @SuppressWarnings("unchecked")
	 * List<ChaseTransaction> itemList = (List<ChaseTransaction>)
	 * csvFileParser.getItems(fileName, ChaseTransaction.class);
	 * 
	 * for (ChaseTransaction t : itemList) { Calendar transactionDate =
	 * Calendar.getInstance();
	 * 
	 * transactionDate.setTime(sdf.parse(t.getDate()));
	 * 
	 * if (transactionDate.get(Calendar.MONTH) == budgetDate.get(Calendar.MONTH) &&
	 * transactionDate.get(Calendar.YEAR) == budgetDate.get(Calendar.YEAR)) {
	 * 
	 * Transaction transaction = new Transaction(t.getDate(), t.getType(),
	 * t.getDescription(), t.getTransactionAmount());
	 * 
	 * transaction.setCategory(categorizeTransaction(transactionFileDir,
	 * transaction)); transactionList.add(transaction);
	 * 
	 * dbS.save(transaction); }
	 * 
	 * }
	 * 
	 * account.setTransactionList(transactionList); dbS.save(account);
	 * 
	 * /*****************************************************************************************
	 ******************************************************************************************
	 *****************************************************************************************
	 * 
	 * }
	 * /*****************************************************************************************
	 * SCHWAB TRANSACTION FILE
	 *****************************************************************************************
	 * else if (csvFileParser.getClass().equals(SchwabTransactionParser.class)) {
	 * logger.info("Detected a SCHWAB file: " + fileName);
	 * 
	 * acctCounter += 1; Account account =
	 * accountS.add(AccountType.SCHWAB_BANK.name() + acctCounter, fileName);
	 * 
	 * // transactionS.parse(csvFileParser, fileName);
	 * 
	 * List<Transaction> accountTransactionList = new ArrayList<Transaction>();
	 * 
	 * @SuppressWarnings("unchecked") List<SchwabTransaction> itemList =
	 * (List<SchwabTransaction>) csvFileParser.getItems(fileName,
	 * SchwabTransaction.class);
	 * 
	 * for (SchwabTransaction t : itemList) { Calendar transactionDate =
	 * Calendar.getInstance(); String transactionAmt;
	 * 
	 * try { transactionDate.setTime(sdf.parse(t.getDate())); } catch
	 * (ParseException e) { // TODO Auto-generated catch block e.printStackTrace();
	 * } if (transactionDate.get(Calendar.MONTH) == budgetDate.get(Calendar.MONTH)
	 * && transactionDate.get(Calendar.YEAR) == budgetDate.get(Calendar.YEAR)) {
	 * 
	 * if (t.getDeposit() != null) transactionAmt = t.getDeposit();
	 * 
	 * else transactionAmt = t.getWithdrawal();
	 * 
	 * Transaction transaction = transactionS.add(t.getDate(), t.getType(),
	 * t.getCheckNum(), t.getDescription(), t.getRunningBalance(), transactionAmt);
	 * 
	 * // Transaction transaction = new Transaction(t.getDate(), t.getType(), //
	 * t.getCheckNum(), // t.getDescription(), t.getRunningBalance(),
	 * transactionAmt);
	 * 
	 * transaction.setCategory(categorizeTransaction(s, transactionFileDir,
	 * transaction));
	 * 
	 * accountTransactionList.add(transaction);
	 * 
	 * s.save(transaction);
	 * 
	 * } }
	 * 
	 * accountS.setTransactionList(account, accountTransactionList);
	 * 
	 * /*****************************************************************************************
	 ******************************************************************************************
	 *****************************************************************************************
	 * 
	 * }
	 * /*****************************************************************************************
	 * AMEX TRANSACTION FILE
	 *****************************************************************************************
	 * else if (csvFileParser.getClass().equals(AmexTransactionParser.class)) {
	 * logger.info("Detected a AMEX file: " + fileName);
	 * 
	 * acctCounter += 1; Account account = new
	 * Account(AccountType.AMEX_CREDIT.name() + acctCounter, fileName);
	 * List<Transaction> transactionList = new ArrayList<Transaction>();
	 * 
	 * @SuppressWarnings("unchecked") List<AmexTransaction> itemList =
	 * (List<AmexTransaction>) csvFileParser.getItems(fileName,
	 * AmexTransaction.class);
	 * 
	 * for (AmexTransaction t : itemList) { Calendar transactionDate =
	 * Calendar.getInstance(); try {
	 * transactionDate.setTime(sdf.parse(t.getDate())); } catch (ParseException e) {
	 * // TODO Auto-generated catch block e.printStackTrace(); } if
	 * (transactionDate.get(Calendar.MONTH) == budgetDate.get(Calendar.MONTH) &&
	 * transactionDate.get(Calendar.YEAR) == budgetDate.get(Calendar.YEAR)) {
	 * 
	 * Transaction transaction = new Transaction(t.getDate(), "AMEX",
	 * t.getDescription(), t.getCardHolder(), t.getTransactionAmount());
	 * 
	 * transaction.setCategory(categorizeTransaction(s, transactionFileDir,
	 * transaction));
	 * 
	 * transactionList.add(transaction);
	 * 
	 * s.save(transaction); } }
	 * 
	 * account.setTransactionList(transactionList);
	 * 
	 * s.save(account);
	 * 
	 * /*****************************************************************************************
	 ******************************************************************************************
	 *****************************************************************************************
	 * }
	 * 
	 * }
	 * 
	 * } s.getTransaction().commit();
	 */
}
