package com.ryanwgingrich.budgetButler.processor;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.ryanwgingrich.budgetButler.dto.db.BBTransaction;
import com.ryanwgingrich.budgetButler.dto.db.BudgetBucket;
import com.ryanwgingrich.budgetButler.enums.TransactionType;

public class FoodProcessor implements Processor {

	@Override
	public void processTransactions(BudgetBucket foodBucket) {

		Calendar cal = Calendar.getInstance();
		Calendar maxDate = Calendar.getInstance();
		
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

		Session session = sessionFactory.openSession();
		//Session session = sessionFactory.openSession();
		session.beginTransaction();
		

		List<BBTransaction> foodTransactions = null;

		String MAX_DATE_QUERY = "select max(date) FROM BBTransaction";
		Query<Date> currentDateQuery = session.createQuery(MAX_DATE_QUERY);

		maxDate.setTime(currentDateQuery.getSingleResult());

		Integer month = maxDate.get(Calendar.MONTH);
		
		Integer year = maxDate.get(Calendar.YEAR);
		
		
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		String newLine = System.getProperty("line.separator");// This will retrieve line separator dependent


		List<String> foodDescList = new ArrayList<String>();
		foodDescList.add("DUNKIN");
		foodDescList.add("MCDONALD''S");
		foodDescList.add("STAGECOACH");
		foodDescList.add("CAFE");
		foodDescList.add("STEWARTS SHOP");
		foodDescList.add("CHIPOTLE");
		foodDescList.add("PRIMAL");
		foodDescList.add("STEWARTS SHOP");
		foodDescList.add("FARM");
		foodDescList.add("SUBWAY");
		foodDescList.add("HANNAFORD");
		foodDescList.add("BREAD");
		foodDescList.add("BURRITO");
		foodDescList.add("PIZZA");

		for (String foodDesc : foodDescList) {

			String FOOD_QUERY = "FROM BBTransaction where"
					+" YEAR(date)  = " + year
					+ " AND MONTH(date) = " + month
					+ " and description like '%" + foodDesc	+ "%'" 
					+ " and type = " + TransactionType.VISA.ordinal();

			Query<BBTransaction> foodQuery = session.createQuery(FOOD_QUERY);
			//foodQuery = session.createQuery(FOOD_QUERY);

			foodTransactions = (List<BBTransaction>) foodQuery.list();

			//String transactionMessage;
			
			session.update(foodBucket);
			
			
			
			
		}

		session.getTransaction().commit();
		session.close();
		System.out.println(
				"**********************************************************************************" + newLine);
		for (BBTransaction foodTransaction : foodTransactions) {

			//String transactionMessage = null;// " " + rentBucket.getCategory() + " BILL DUE ";
			String transactionMessage = sdf.format(foodTransaction.getDate()) + " " + foodTransaction.getDescription() + " " + "$"
					+ foodTransaction.getWithdrawal();
			System.out.println(transactionMessage);

		}
		System.out.println(newLine + foodBucket.getCategory() + " Amt Remaining: $" + foodBucket.getRemainingAmt());
		System.out.println(newLine
				+ "**********************************************************************************" + newLine);

	}



}
